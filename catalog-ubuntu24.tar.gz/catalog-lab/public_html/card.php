<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/catalog_security/site/bootstrap.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD');
    jsonResponse(['message' => 'Используйте GET.'], 405);
}
$cards = db()->query('SELECT id, name, disc, tag, place, img FROM card ORDER BY id');
jsonResponse($cards->fetchAll(PDO::FETCH_ASSOC));
