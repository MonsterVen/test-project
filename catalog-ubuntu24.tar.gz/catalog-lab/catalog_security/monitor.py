"""Local scheduler, persistent audit history and synthetic exercises."""

import argparse
import json
import logging
import os
import sqlite3
import threading
import time
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from audit import MAX_FINDINGS, finding, health, inventory, runtime_events
from catalog_db import DEFAULT_STATE, ROOT
from expert_system import RULES_PATH, evaluate, load_rules


LOG = logging.getLogger("catalog-security")
WEB = Path(__file__).resolve().with_name("web")
SIMULATIONS = {
    "sql": ("sql_injection", "Учебный сигнал SQL-инъекции."),
    "web": ("xss", "Учебный сигнал веб-атаки XSS."),
    "xml": ("xxe", "Учебный сигнал небезопасного разбора XML."),
    "access": ("access_control", "Учебный сигнал обхода контроля доступа."),
}
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK(id = 1), project TEXT NOT NULL, interval INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
    project TEXT NOT NULL, kind TEXT NOT NULL, report TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS reports_by_project ON reports(project, id DESC) WHERE kind <> 'simulation';
CREATE TABLE IF NOT EXISTS baselines (project TEXT PRIMARY KEY, hashes TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS progress (id INTEGER PRIMARY KEY CHECK(id = 1), event_id INTEGER NOT NULL);
INSERT OR IGNORE INTO progress VALUES (1, 0);
"""


def utc(timestamp=None):
    clock = time.time() if timestamp is None else timestamp
    return datetime.fromtimestamp(clock, timezone.utc).isoformat(timespec="seconds")


class Store:
    def __init__(self, state):
        state.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = state / "monitor.sqlite3"
        with self.open() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(SCHEMA)
            db.execute("INSERT OR IGNORE INTO settings VALUES (1, ?, 60)", (str(ROOT),))

    @contextmanager
    def open(self):
        with closing(sqlite3.connect(self.path, timeout=5)) as db, db:
            db.row_factory = sqlite3.Row
            yield db

    def settings(self):
        with self.open() as db:
            return dict(db.execute("SELECT project, interval FROM settings").fetchone())

    def configure(self, project, interval):
        with self.open() as db:
            db.execute("UPDATE settings SET project = ?, interval = ?", (str(project), interval))

    def previous(self, project):
        with self.open() as db:
            row = db.execute("SELECT hashes FROM baselines WHERE project = ?", (str(project),)).fetchone()
            cursor = db.execute("SELECT event_id FROM progress").fetchone()[0]
            return json.loads(row[0]) if row else None, cursor

    def save(self, project, kind, report, hashes=None, cursor=None):
        with self.open() as db:
            row = db.execute("INSERT INTO reports(created_at, project, kind, report) VALUES (?, ?, ?, ?)",
                             (utc(), str(project), kind, json.dumps(report)))
            if hashes is not None:
                db.execute("INSERT INTO baselines VALUES (?, ?) ON CONFLICT(project) DO UPDATE SET hashes=excluded.hashes",
                           (str(project), json.dumps(hashes)))
            if cursor is not None:
                db.execute("UPDATE progress SET event_id = ? WHERE id = 1", (cursor,))
            return row.lastrowid

    def history(self, before=None):
        query = "SELECT * FROM reports"
        args = ()
        if before is not None:
            query += " WHERE id < ?"
            args = (before,)
        with self.open() as db:
            rows = db.execute(query + " ORDER BY id DESC LIMIT 25", args).fetchall()
        return [{"id": row["id"], "created_at": row["created_at"], "project": row["project"],
                 "kind": row["kind"], **json.loads(row["report"])} for row in rows]

    def last_audit(self, project):
        with self.open() as db:
            row = db.execute("SELECT created_at, report FROM reports WHERE project = ? AND kind <> 'simulation' "
                             "ORDER BY id DESC LIMIT 1", (project,)).fetchone()
        if row is None:
            return None
        report = json.loads(row["report"])
        return {"created_at": row["created_at"], "health": report["health"], "error": report["error"]}


def validate(value, interval):
    if not isinstance(value, str) or not value.strip() or len(value) > 4096:
        raise ValueError("Укажите путь к папке проекта.")
    if type(interval) is not int or not 5 <= interval <= 86400:
        raise ValueError("Интервал должен быть целым числом от 5 до 86400 секунд.")
    try:
        path = Path(value).expanduser().resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise ValueError("Папка проекта недоступна.") from error
    if not path.is_dir() or path == path.parent:
        raise ValueError("Укажите папку проекта.")
    return path, interval


def directory_choices(value):
    base = Path(value).expanduser().resolve(strict=True)
    if not base.is_dir():
        raise ValueError("Укажите папку проекта.")
    folders = []
    with os.scandir(base) as entries:
        for item in entries:
            if not item.name.startswith(".") and item.is_dir(follow_symlinks=False):
                folders.append(item.name)
                if len(folders) == 200:
                    break
    return {"folder": str(base), "parent": str(base.parent) if base != base.parent else None,
            "children": [{"name": name, "path": str(base / name)} for name in sorted(folders)]}


def report_for(findings, *, files=None, site=None, error=None):
    sorted_findings = sorted(findings, key=lambda item: {
        "critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4,
    }[item["severity"]])
    shown = sorted_findings[:MAX_FINDINGS]
    incident = evaluate(shown, load_rules(RULES_PATH))
    return {"inventory": files, "health": site, "findings": shown, "finding_count": len(findings),
            "incident": incident, "error": error}


class Monitor:
    def __init__(self, state, port, store):
        self.state = state
        self.site_port = port
        self.store = store
        self.lock = threading.Condition()
        self.pending = None
        self.running = False
        self.deadline = time.monotonic()

    def status(self):
        with self.lock:
            settings = self.store.settings()
            next_check = None if self.running else utc(time.time() + max(0, self.deadline - time.monotonic()))
            return {**settings, "running": self.running, "queued": bool(self.pending),
                    "next_check": next_check, "site_port": self.site_port,
                    "last_audit": self.store.last_audit(settings["project"])}

    def update(self, value, interval):
        project, interval = validate(value, interval)
        with self.lock:
            self.store.configure(project, interval)
            self.pending = "configuration"
            self.lock.notify()

    def request(self):
        with self.lock:
            self.pending = "manual"
            self.lock.notify()

    def work(self):
        while True:
            with self.lock:
                while not self.pending and self.deadline > time.monotonic():
                    self.lock.wait(self.deadline - time.monotonic())
                kind = self.pending or "scheduled"
                self.pending = None
                self.running = True
                project = Path(self.store.settings()["project"])
            try:
                self.scan(project, kind)
            except Exception:
                LOG.exception("Audit failed")
                try:
                    self.store.save(project, kind, report_for([], error="Проверка не завершилась. Подробности в журнале запуска."))
                except Exception:
                    LOG.exception("Unable to record failed audit")
            finally:
                with self.lock:
                    self.deadline = time.monotonic() + self.store.settings()["interval"]
                    self.running = False

    def scan(self, project, kind):
        if not project.is_dir():
            raise FileNotFoundError("Selected project is no longer available")
        files, findings, hashes = inventory(project)
        previous, cursor = self.store.previous(project)
        baseline = None
        if files["limited"] or files["skipped"]:
            findings.append(finding("static", "incomplete_inventory", "info",
                                    "Некоторые файлы пропущены из-за ограничений или ошибок чтения."))
        else:
            baseline = hashes
        if previous is not None:
            differences = [(name, "Изменилось содержимое файла.") for name, digest in hashes.items()
                           if name in previous and previous[name] != digest]
            if baseline is not None:
                differences += [(name, "Обнаружен новый файл.") for name in sorted(hashes.keys() - previous.keys())]
                differences += [(name, "Файл исчез из инвентаризации.") for name in sorted(previous.keys() - hashes.keys())]
            findings.extend(finding("integrity", "source_changed", "medium", message, name)
                            for name, message in differences)
        status = {"status": "not_applicable"}
        new_cursor = None
        if project in {ROOT, ROOT / "public_html"}:
            status, issues = health(self.site_port)
            findings.extend(issues)
            try:
                events, new_cursor = runtime_events(self.state, cursor)
                findings.extend(events)
            except sqlite3.Error:
                LOG.exception("Runtime log unavailable")
                findings.append(finding("runtime", "unavailable", "medium", "Журнал приложения недоступен."))
        self.store.save(project, kind, report_for(findings, files=files, site=status), baseline, new_cursor)


class Handler(BaseHTTPRequestHandler):
    server_version = "CatalogMonitor/1"
    timeout = 8
    routes = {"/": ("index.html", "text/html"), "/style.css": ("style.css", "text/css"),
              "/app.js": ("app.js", "text/javascript")}

    def reply(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers()
        self.wfile.write(body)

    def json(self, body, status=200):
        self.reply(json.dumps(body).encode(), "application/json", status)

    def local(self):
        allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        if self.headers.get("Host") not in allowed:
            self.json({"error": "Откройте интерфейс на 127.0.0.1."}, 403)
            return False
        return True

    def do_GET(self):
        if not self.local():
            return
        path = urlsplit(self.path)
        if path.path in self.routes:
            name, content_type = self.routes[path.path]
            self.reply((WEB / name).read_bytes(), content_type)
        elif path.path == "/api/status":
            self.json(self.server.monitor.status())
        elif path.path == "/api/history":
            before = parse_qs(path.query).get("before", [None])[0]
            if before is not None and not (before.isascii() and before.isdecimal() and len(before) <= 18):
                self.json({"error": "Неверный номер проверки."}, 400)
                return
            self.json(self.server.monitor.store.history(int(before) if before else None))
        else:
            self.json({"error": "Страница не найдена."}, 404)

    def do_POST(self):
        if not self.local():
            return
        expected = "http://" + self.headers["Host"]
        if (self.headers.get("X-Catalog-Action") != "1"
                or self.headers.get("Origin", expected) != expected):
            self.json({"error": "Запрос не принадлежит интерфейсу."}, 403)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 <= size <= 8192:
                raise ValueError("Слишком большой запрос.")
            if self.path in {"/api/check", "/api/settings", "/api/directories"}:
                data = json.loads(self.rfile.read(size)) if size else {}
                if not isinstance(data, dict):
                    raise ValueError("Ожидается объект JSON.")
                if self.path == "/api/directories":
                    path = data.get("path")
                    if not isinstance(path, str) or not path or len(path) > 4096:
                        raise ValueError("Укажите путь к папке.")
                    self.json(directory_choices(path))
                    return
                if self.path == "/api/check":
                    self.server.monitor.request()
                else:
                    self.server.monitor.update(data.get("project"), data.get("interval"))
                self.json({"accepted": True}, 202)
            else:
                self.json({"error": "Страница не найдена."}, 404)
        except (ValueError, RecursionError) as error:
            self.json({"error": str(error)}, 400)
        except (OSError, RuntimeError):
            self.json({"error": "Папка проекта недоступна."}, 400)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    serve = commands.add_parser("serve")
    serve.add_argument("--site-port", type=int, default=8000)
    serve.add_argument("--port", type=int, default=8081)
    serve.add_argument("--project")
    serve.add_argument("--interval", type=int)
    simulate = commands.add_parser("simulate")
    simulate.add_argument("scenario", choices=["all", *SIMULATIONS], default="all", nargs="?")
    args = parser.parse_args()
    os.umask(0o077)
    logging.basicConfig(level=logging.INFO)
    state = Path(os.environ.get("CATALOG_STATE", DEFAULT_STATE)).expanduser().resolve()
    store = Store(state)
    try:
        settings = store.settings()
        if args.action == "simulate":
            scenarios = SIMULATIONS.values() if args.scenario == "all" else [SIMULATIONS[args.scenario]]
            findings = [finding("simulation", code, "high", message) for code, message in scenarios]
            identifier = store.save(settings["project"], "simulation", report_for(findings))
            print(f"Учебная запись №{identifier}. Событий: {len(findings)}.")
            return
        if args.project is not None or args.interval is not None:
            project = args.project if args.project is not None else settings["project"]
            interval = args.interval if args.interval is not None else settings["interval"]
            store.configure(*validate(project, interval))
        monitor = Monitor(state, args.site_port, store)
        with ThreadingHTTPServer(("127.0.0.1", args.port), Handler) as server:
            server.monitor = monitor
            threading.Thread(target=monitor.work, daemon=True).start()
            print(f"История проверок: http://127.0.0.1:{args.port}/", flush=True)
            server.serve_forever()
    except (OSError, ValueError, sqlite3.Error) as error:
        parser.exit(2, f"{error}\n")
    except KeyboardInterrupt:
        return


if __name__ == "__main__":
    main()
