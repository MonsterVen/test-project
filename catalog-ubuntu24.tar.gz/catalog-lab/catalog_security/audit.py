"""Read-only source inventory and checks for a locally selected project."""

import hashlib
import http.client
import json
import os
import re
import sqlite3
import stat
from contextlib import closing


IGNORED = {".git", ".svn", ".catalog-state", "node_modules", "vendor", "font-awesome",
           "build", "dist", "__pycache__", "practica4"}
EXTENSIONS = {".php", ".phtml", ".js", ".html", ".xml", ".xsl", ".xslt", ".sql", ".ini", ".conf"}
MAX_FILES = 1200
MAX_FILE_BYTES = 1 << 20
MAX_TOTAL_BYTES = 24 << 20
MAX_FINDINGS = 80

EVENTS = {
    "auth_failed": ("info", "Сервер зарегистрировал неудачный вход."),
    "auth_required": ("low", "Доступ к операции администратора без сессии отклонён."),
    "csrf_rejected": ("medium", "Запрос отклонён при проверке CSRF."),
    "unsupported_media": ("low", "Обработчик формы отклонил неподдерживаемый тип данных."),
    "invalid_card": ("info", "Приложение отклонило карточку при проверке полей."),
}

SIGNATURES = (
    ((".js", ".html", ".php"), "dynamic_html", "high",
     r"insertAdjacentHTML\s*\([^,]+,\s*(?:[a-z_$]|\x60)|\.innerHTML\s*=\s*(?:[a-z_$]|\x60)",
     "Динамическая вставка HTML. Проверьте происхождение данных и используйте textContent для текста."),
    ((".php", ".phtml"), "dynamic_sql", "high",
     r'(?i)"\s*(?:SELECT|UPDATE|INSERT|DELETE)\b[^"\n]*\$[a-z_{]|'
     r'''(?i:["']\s*(?:SELECT|UPDATE|INSERT|DELETE)\b[^"'\n]*["']\s*\.\s*\$)''',
     "SQL сформирован с переменной. Проверьте, что пользовательские значения передаются параметрами."),
    ((".php", ".phtml"), "embedded_credential", "high",
     r'''(?im)\$(?:db_?pass(?:word)?|password)\s*=\s*["'][^"'\n]{8,}["']|'''
     r'''(?i:mysqli_connect\s*\(\s*["'][^"']+["']\s*,\s*["'][^"']+["']\s*,\s*["'][^"']+["'])''',
     "В исходнике обнаружен признак встроенного пароля. Проверьте хранение секрета."),
    ((".xml", ".xsl", ".xslt"), "xml_external_definition", "medium",
     r"(?i)<!DOCTYPE\s+[^>]*\b(?:SYSTEM|PUBLIC)\b",
     "XML ссылается на внешнее определение. Проверьте настройки XML-парсера."),
    ((".php", ".phtml"), "xml_external_definition", "medium",
     r"\bLIBXML_(?:DTDLOAD|DTDATTR|NOENT)\b",
     "Обнаружена настройка загрузки DTD или подстановки сущностей. Проверьте доверие к XML."),
)
PATTERNS = [(suffixes, code, severity, re.compile(pattern), message)
            for suffixes, code, severity, pattern, message in SIGNATURES]


def finding(source, code, severity, message, path=None, line=None):
    return {"source": source, "type": code, "severity": severity, "description": message,
            "path": path, "line": line}


def document_root(project):
    for name in ("public_html", "public", "www"):
        candidate = project / name
        if candidate.is_dir() and not candidate.is_symlink():
            return candidate
    for name in ("index.php", "index.html"):
        if (project / name).is_file():
            return project
    return None


def read_source(path, limit):
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode):
            return None
        if info.st_size > limit:
            return None
        data = stream.read(limit + 1)
        return data if len(data) <= limit else None


def check_source(path, suffix, text):
    if suffix == ".sql" and re.search(r"(?im)^INSERT\s+INTO\s+[`\"]?admins\b", text):
        yield finding("static", "legacy_admin_dump", "medium",
                      "Дамп содержит записи администраторов. Храните его отдельно от веб-каталога.", path)
    for suffixes, code, severity, pattern, message in PATTERNS:
        if suffix in suffixes and (match := pattern.search(text)):
            yield finding("static", code, severity, message, path, text.count("\n", 0, match.start()) + 1)
    if path.rsplit("/", 1)[-1] == "add_card.php" and "$_POST" in text and "adminSignedIn" not in text:
        yield finding("static", "review_access_control", "high",
                      "Проверьте серверную авторизацию у обработчика добавления карточек.", path)


def inventory(project):
    docroot = document_root(project)
    counts = {}
    samples, findings = [], []
    skipped = 0
    used = 0
    scanned = 0
    limited = False
    hashes = {}
    unavailable = []
    for folder, dirs, names in os.walk(project, onerror=unavailable.append):
        dirs[:] = sorted(name for name in dirs if name not in IGNORED and not name.startswith("."))
        for name in sorted(names):
            path = project.joinpath(folder, name)
            relative = path.relative_to(project).as_posix()
            suffix = path.suffix.lower()
            secret = name == ".env" or name.startswith(".env.")
            backup = name.lower().endswith((".sql.gz", ".sql.zip", ".bak", ".sqlite", ".sqlite3", ".old"))
            if suffix not in EXTENSIONS and not secret and not backup:
                continue
            if scanned + skipped >= MAX_FILES or used >= MAX_TOTAL_BYTES:
                limited = True
                break
            if path.is_symlink():
                skipped += 1
                continue
            if docroot and path.is_relative_to(docroot) and (secret or backup or suffix == ".sql"):
                findings.append(finding("static", "public_sensitive_file", "critical",
                                        "Файл похож на дамп, конфигурацию или резервную копию внутри веб-каталога.", relative))
            kind = "env" if secret else suffix.lstrip(".") or "backup"
            counts[kind] = counts.get(kind, 0) + 1
            if len(samples) < 70:
                samples.append(relative)
            if secret or backup:
                scanned += 1
                continue
            try:
                data = read_source(path, min(MAX_FILE_BYTES, MAX_TOTAL_BYTES - used))
            except OSError:
                data = None
            if data is None:
                skipped += 1
                continue
            used += len(data)
            scanned += 1
            hashes[relative] = hashlib.sha256(data).hexdigest()
            findings.extend(check_source(relative, suffix, data.decode("utf-8-sig", errors="replace")))
        if limited:
            break
    return ({"counts": counts, "examples": samples, "scanned": scanned, "skipped": skipped + len(unavailable),
             "limited": limited, "web_root": docroot.relative_to(project).as_posix() if docroot else None},
            findings, hashes)


def health(port):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    try:
        connection.request("GET", "/card.php")
        response = connection.getresponse()
        if response.status != 200:
            return {"status": "down", "http": response.status}, [
                finding("health", "catalog_unavailable", "high", "API каталога вернуло ошибку HTTP.")]
        raw = response.read((2 << 20) + 1)
        cards = json.loads(raw) if len(raw) <= 2 << 20 else None
        if not isinstance(cards, list):
            raise ValueError("unexpected catalog response")
        missing = [name for name in ("Content-Security-Policy", "X-Content-Type-Options",
                                     "X-Frame-Options", "Referrer-Policy") if not response.getheader(name)]
        findings = [finding("health", "missing_header", "medium", f"Отсутствует заголовок {name}.")
                    for name in missing]
        return {"status": "ok", "http": 200, "cards": len(cards)}, findings
    except (OSError, ValueError, http.client.HTTPException):
        return {"status": "down", "http": None}, [
            finding("health", "catalog_unavailable", "high", "Локальный API каталога недоступен или вернул неверный JSON.")]
    finally:
        connection.close()


def runtime_events(state, cursor):
    db = (state / "catalog.sqlite3").as_uri() + "?mode=ro"
    with closing(sqlite3.connect(db, uri=True, timeout=3)) as connection:
        last = connection.execute("SELECT COALESCE(MAX(id), 0) FROM events").fetchone()[0]
        if last < cursor:
            cursor = 0
        rows = connection.execute("SELECT id, code FROM events WHERE id > ? ORDER BY id LIMIT 1000",
                                  (cursor,)).fetchall()
    counts = {}
    for _, code in rows:
        if code in EVENTS:
            counts[code] = counts.get(code, 0) + 1
    findings = []
    for code, count in counts.items():
        severity, description = EVENTS[code]
        if code == "auth_failed" and count >= 5:
            severity = "medium"
        findings.append(finding("runtime", code, severity, f"{description} Событий: {count}."))
    return findings, rows[-1][0] if rows else cursor
