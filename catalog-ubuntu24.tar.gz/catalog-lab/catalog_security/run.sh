#!/usr/bin/env bash
set -euo pipefail
umask 077

root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"
export CATALOG_STATE
CATALOG_STATE="$(realpath -m -- "${CATALOG_STATE:-$root/.catalog-state}")"
site_port="${CATALOG_PORT:-8000}"
monitor_port="${MONITOR_PORT:-8081}"
for port in "$site_port" "$monitor_port"; do
    if [[ ! "$port" =~ ^[1-9][0-9]{0,4}$ ]] || (( port > 65535 )); then
        printf 'Некорректный номер порта: %s\n' "$port" >&2
        exit 2
    fi
done
if [[ "$site_port" == "$monitor_port" ]]; then
    printf 'У сайта и ИАС должны быть разные порты.\n' >&2
    exit 2
fi
export CATALOG_PORT="$site_port"

python3 catalog_security/catalog_db.py init
php -d display_errors=0 -d post_max_size=32K -d expose_php=0 \
    -S "127.0.0.1:$site_port" -t "$root/public_html" "$root/catalog_security/site/router.php" &
site_pid=$!
monitor_pid=
cleanup() {
    kill "$site_pid" ${monitor_pid:+"$monitor_pid"} 2>/dev/null || true
    wait "$site_pid" ${monitor_pid:+"$monitor_pid"} 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

ready=no
for _ in {1..30}; do
    kill -0 "$site_pid" 2>/dev/null || { wait "$site_pid"; exit 1; }
    if curl --noproxy '*' -fsS --max-time 1 -o /dev/null "http://127.0.0.1:$site_port/card.php" 2>/dev/null; then
        ready=yes
        break
    fi
    sleep .2
done
if [[ "$ready" != yes ]]; then
    printf 'Локальный каталог не прошёл проверку запуска.\n' >&2
    exit 1
fi
printf 'Каталог: http://127.0.0.1:%s/\n' "$site_port"
python3 catalog_security/monitor.py serve --port "$monitor_port" --site-port "$site_port" "$@" &
monitor_pid=$!
wait "$monitor_pid"
