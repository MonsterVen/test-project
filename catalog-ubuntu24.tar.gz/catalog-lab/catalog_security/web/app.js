"use strict";

const byId = (id) => document.getElementById(id);
const form = byId("settings");
const project = byId("project");
const interval = byId("interval");
const history = byId("history");
const feedback = byId("feedback");
const older = byId("older");
let entries = new Map();
let latestId;
let before;
let edited = false;
let polling = false;

const kinds = {scheduled: "По расписанию", manual: "Вручную", configuration: "После смены настроек",
    simulation: "Учебная симуляция"};
const sources = {static: "Код", integrity: "Целостность", runtime: "Журнал",
    health: "Доступность", simulation: "Симуляция"};
const severity = {critical: "Критично", high: "Высокий", medium: "Средний",
    low: "Низкий", info: "Справочно"};

function append(parent, tag, content) {
    const node = document.createElement(tag);
    if (content !== undefined) node.textContent = content;
    parent.append(node);
    return node;
}

function time(value) {
    return value ? new Date(value).toLocaleString("ru-RU") : "—";
}

async function api(url, data) {
    const options = data === undefined ? {} : {method: "POST",
        headers: {"Content-Type": "application/json", "X-Catalog-Action": "1"},
        body: JSON.stringify(data)};
    const response = await fetch(url, options);
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "HTTP " + response.status);
    return result;
}

function makeEntry(entry) {
    const details = document.createElement("details");
    details.dataset.id = entry.id;
    const summary = append(details, "summary");
    append(summary, "time", time(entry.created_at)).dateTime = entry.created_at;
    const label = append(summary, "span", kinds[entry.kind] || entry.kind);
    if (entry.kind === "simulation") label.className = "simulation";
    if (entry.error) append(summary, "span", " · Ошибка").className = "problem";
    else {
        const status = entry.incident.detected ? "Требуется проверка" : "Риск ниже порога";
        const message = entry.finding_count ? status + " · Находок: " + entry.finding_count : "Сигналов нет";
        append(summary, "span", " · " + message).className = entry.incident.detected ? "problem" : "good";
    }

    const detail = append(details, "div");
    detail.className = "detail";
    append(detail, "p", entry.project);
    if (entry.error) {
        append(detail, "p", entry.error);
        return details;
    }
    append(detail, "p", "Риск " + entry.incident.risk_score + "/10 · Правила " + entry.incident.rules_version);
    if (entry.inventory) {
        const files = entry.inventory;
        const inventory = append(detail, "details");
        append(inventory, "summary", "Найденные файлы · " + files.scanned + " проверено, " + files.skipped + " пропущено");
        const counts = Object.entries(files.counts).map(([type, count]) => type + " (" + count + ")");
        append(inventory, "p", counts.join(", ") || "Подходящих файлов нет.");
        append(inventory, "p", "Веб-каталог: " + (files.web_root ?? "не определён"));
        if (files.examples.length) {
            const list = append(inventory, "ul");
            for (const name of files.examples) append(append(list, "li"), "code", name);
        }
    }
    if (entry.findings.length) {
        append(detail, "h3", "Находки");
        const list = append(detail, "ul");
        for (const item of entry.findings) {
            const row = append(list, "li", sources[item.source] + " · " + severity[item.severity] + " · " + item.description);
            if (item.path) append(row, "code", " " + item.path + (item.line ? ":" + item.line : ""));
        }
        if (entry.finding_count > entry.findings.length) {
            append(detail, "p", "Показаны первые " + entry.findings.length + " находок.");
        }
    }
    if (entry.incident.recommendations.length) {
        append(detail, "h3", "Рекомендации");
        const list = append(detail, "ul");
        for (const recommendation of entry.incident.recommendations) append(list, "li", recommendation);
    }
    return details;
}

function merge(rows) {
    for (const entry of rows) {
        if (!entries.has(entry.id)) entries.set(entry.id, {entry, node: makeEntry(entry)});
    }
    const ordered = [...entries.values()].sort((a, b) => b.entry.id - a.entry.id);
    let pointer = history.firstElementChild;
    for (const {node} of ordered) {
        if (node === pointer) pointer = pointer.nextElementSibling;
        else history.insertBefore(node, pointer);
    }
    byId("empty").hidden = ordered.length > 0;
}

function renderStatus(status) {
    if (!edited) {
        project.value = status.project;
        interval.value = status.interval;
    }
    const site = byId("open-site");
    site.href = "http://127.0.0.1:" + status.site_port + "/";
    site.hidden = false;

    const latest = status.last_audit;
    const health = byId("health");
    const current = latest?.health;
    health.textContent = latest?.error ? "Ошибка проверки" : current?.status === "ok" ? "Работает · " + current.cards + " карточек"
        : current?.status === "down" ? "Недоступен"
        : current?.status === "not_applicable" ? "Для папки аудит файлов" : "Ожидает проверки";
    health.className = current?.status === "ok" ? "good" : current?.status === "down" || latest?.error ? "problem" : "";
    byId("last").textContent = latest ? time(latest.created_at) : "—";
    byId("next").textContent = status.running ? "Выполняется" : status.queued ? "В очереди" : time(status.next_check);
}

async function refresh() {
    if (polling) return;
    polling = true;
    try {
        const [status, rows] = await Promise.all([api("/api/status"), api("/api/history")]);
        if (typeof before === "undefined") {
            before = rows.length === 25 ? rows.at(-1).id : null;
            older.hidden = before === null;
        }
        if (rows[0]?.id !== latestId) {
            latestId = rows[0]?.id;
            merge(rows);
        }
        renderStatus(status);
    } catch (error) {
        byId("health").textContent = "Панель недоступна";
        byId("health").className = "problem";
    } finally {
        polling = false;
    }
}

async function action(button, route, data, message) {
    button.disabled = true;
    feedback.className = "";
    try {
        await api(route, data);
        if (route === "/api/settings") edited = false;
        feedback.textContent = message;
        await refresh();
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        button.disabled = false;
    }
}

form.addEventListener("input", () => { edited = true; });
form.addEventListener("submit", (event) => {
    event.preventDefault();
    action(event.submitter, "/api/settings", {project: project.value, interval: interval.valueAsNumber},
        "Настройки сохранены. Проверка поставлена в очередь.");
});
byId("check").addEventListener("click", (event) => {
    action(event.currentTarget, "/api/check", {}, "Запрошена проверка.");
});
let browsing;
async function openFolder(path) {
    try {
        browsing = await api("/api/directories", {path});
        byId("folder-browser").hidden = false;
        byId("browser-path").textContent = browsing.folder;
        byId("parent-folder").disabled = browsing.parent === null;
        const children = byId("subfolders");
        children.replaceChildren();
        for (const folder of browsing.children) {
            const button = append(append(children, "li"), "button", folder.name);
            button.className = "secondary";
            button.addEventListener("click", () => openFolder(folder.path));
        }
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    }
}
byId("browse").addEventListener("click", () => openFolder(project.value.trim() || "."));
byId("parent-folder").addEventListener("click", () => openFolder(browsing.parent));
byId("close-browser").addEventListener("click", () => { byId("folder-browser").hidden = true; });
byId("use-folder").addEventListener("click", () => {
    project.value = browsing.folder;
    edited = true;
    byId("folder-browser").hidden = true;
    project.focus();
});
older.addEventListener("click", async () => {
    older.disabled = true;
    try {
        const rows = await api("/api/history?before=" + before);
        merge(rows);
        before = rows.length === 25 ? rows.at(-1).id : null;
        older.hidden = before === null;
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        older.disabled = false;
    }
});

refresh();
setInterval(refresh, 3000);
