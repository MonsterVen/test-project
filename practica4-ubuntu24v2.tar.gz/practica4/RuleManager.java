import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;

public class RuleManager {
    public static void main(String[] args) {
        try {
            run(args);
        } catch (IOException | InterruptedException | IllegalArgumentException | JsonParseException error) {
            System.err.println(error.getMessage());
            System.exit(2);
        }
    }

    private static void run(String[] args) throws IOException, InterruptedException {
        if (args.length < 2) {
            throw new IllegalArgumentException("Usage: RuleManager list RULES | find RULES CATEGORY "
                    + "| snapshot RULES DIRECTORY | add RULES RULE_JSON NEW_VERSION DIRECTORY");
        }
        Path source = Path.of(args[1]);
        switch (args[0]) {
            case "list" -> {
                requireLength(args, 2);
                printRules(readValidated(source), null);
            }
            case "find" -> {
                requireLength(args, 3);
                printRules(readValidated(source), args[2]);
            }
            case "snapshot" -> {
                requireLength(args, 3);
                saveSnapshot(Files.readAllBytes(source), Path.of(args[2]));
            }
            case "add" -> {
                requireLength(args, 5);
                var config = readValidated(source);
                String version = args[3];
                if (version.equals(config.get("version").getAsString())) {
                    throw new IllegalArgumentException("Укажите новую версию правил");
                }
                config.getAsJsonArray("rules").add(readObject(Path.of(args[2])));
                config.addProperty("version", version);
                var gson = new GsonBuilder().setPrettyPrinting().create();
                byte[] contents = (gson.toJson(config) + "\n").getBytes(StandardCharsets.UTF_8);
                saveSnapshot(contents, Path.of(args[4]));
            }
            default -> throw new IllegalArgumentException("Unknown command: " + args[0]);
        }
    }

    private static void requireLength(String[] args, int count) {
        if (args.length != count) throw new IllegalArgumentException("Wrong number of arguments");
    }

    private static JsonObject readValidated(Path source) throws IOException, InterruptedException {
        Process validator = new ProcessBuilder("python3", "expert_system.py", source.toString())
                .inheritIO().start();
        if (validator.waitFor() != 0) throw new IllegalArgumentException("Invalid rules file");
        return readObject(source);
    }

    private static JsonObject readObject(Path source) throws IOException {
        try (Reader reader = Files.newBufferedReader(source)) {
            var value = JsonParser.parseReader(reader);
            if (!value.isJsonObject()) throw new IllegalArgumentException("Expected a JSON object: " + source);
            return value.getAsJsonObject();
        }
    }

    private static void printRules(JsonObject config, String category) {
        System.out.printf("Версия %s, порог %s%n", config.get("version").getAsString(), config.get("threshold"));
        for (var item : config.getAsJsonArray("rules")) {
            var rule = item.getAsJsonObject();
            String currentCategory = rule.get("category").getAsString();
            if (category == null || currentCategory.equals(category)) {
                System.out.printf("[%s] %s (%s)%n", currentCategory,
                        rule.get("name").getAsString(), rule.get("risk_score"));
            }
        }
    }

    private static void saveSnapshot(byte[] contents, Path directory) throws IOException, InterruptedException {
        Files.createDirectories(directory);
        Path staging = Files.createTempFile(directory, ".rules-", ".json");
        try {
            Files.write(staging, contents);
            String version = readValidated(staging).get("version").getAsString();
            Path snapshot = directory.resolve("rules-" + version + ".json");
            try {
                Files.createLink(snapshot, staging);
            } catch (FileAlreadyExistsException error) {
                throw new IllegalArgumentException("Версия уже существует: " + snapshot, error);
            }
            System.out.println(snapshot);
        } finally {
            Files.deleteIfExists(staging);
        }
    }
}
