"""Normalize stored reports and return one security assessment per target."""

import argparse
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import parsers
from decision_tree import FEATURES, features, train
from evaluate import dataset, training_rows
from expert_system import RULES_PATH, evaluate, load_rules
from report_io import write_report


ROOT = Path(__file__).resolve().parent


def analyze(paths, rules):
    grouped = {}
    for source, path in paths.items():
        if path is None:
            continue
        try:
            adapter = getattr(parsers, source)
            records = adapter(path, ROOT / "build/nmap_parser") if source == "nmap" else adapter(path)
            for target, findings in records:
                unique = grouped.setdefault(target, {})
                for item in findings:
                    unique.setdefault(json.dumps(item, sort_keys=True), item)
        except (ValueError, KeyError, TypeError, OSError, subprocess.TimeoutExpired) as error:
            raise ValueError(f"{source}: {error}") from error
    model = train(training_rows(dataset()))
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    scan_id = str(uuid4())
    reports = []
    for target, items in sorted(grouped.items()):
        findings = list(items.values())
        sample = features(findings)
        reports.append({"scan_id": scan_id, "timestamp": timestamp, "target": target,
                        "findings": findings, "incident": evaluate(findings, rules),
                        "decision_tree": {"detected": model.predict(sample),
                                          "features": dict(zip(FEATURES, sample))}})
    return {"sources": [source for source, path in paths.items() if path is not None],
            "reports": reports}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for source in ("nmap", "masscan", "nikto"):
        parser.add_argument("--" + source, type=Path)
    parser.add_argument("--rules", type=Path, default=RULES_PATH)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    paths = {source: getattr(args, source) for source in ("nmap", "masscan", "nikto")}
    if not any(paths.values()):
        parser.error("provide at least one scanner report")
    try:
        rules = load_rules(args.rules)
        output = json.dumps(analyze(paths, rules), indent=2, ensure_ascii=False) + "\n"
        if args.output:
            write_report(args.output, output)
        else:
            print(output, end="")
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")


if __name__ == "__main__":
    main()
