"""Publish complete JSON output even when runs write to the same path."""

import os
from tempfile import mkstemp


def write_report(path, text):
    descriptor, temporary = mkstemp(dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
