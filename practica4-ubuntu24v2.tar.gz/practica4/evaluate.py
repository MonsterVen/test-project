"""Evaluate rules and a decision tree on the fixed held-out split."""

import argparse
import csv
import json
from dataclasses import asdict
from pathlib import Path

from decision_tree import FEATURES, features, train
from expert_system import RULES_PATH, evaluate, load_rules
from parsers import PORT_SEVERITY, finding
from report_io import write_report


DATASET = Path(__file__).resolve().with_name("dataset.csv")


def dataset():
    with DATASET.open(encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            findings = [
                finding("masscan", "port", int(port), PORT_SEVERITY.get(int(port), "low"),
                        "", protocol="tcp")
                for port in row["tcp_ports"].split("|") if port
            ]
            findings += [
                finding("nikto", "vulnerability", 80, severity, "")
                for severity in row["web_severity"].split("|") if severity
            ]
            yield row, findings, {"0": False, "1": True}[row["actual"]]


def training_rows(cases):
    return [(features(findings), actual) for row, findings, actual in cases if row["split"] == "train"]


def metrics(results):
    tp = sum(actual and predicted for actual, predicted in results)
    fp = sum(not actual and predicted for actual, predicted in results)
    fn = sum(actual and not predicted for actual, predicted in results)
    tn = len(results) - tp - fp - fn

    def ratio(numerator, denominator):
        return round(numerator / denominator, 4) if denominator else 0

    return {"precision": ratio(tp, tp + fp), "recall": ratio(tp, tp + fn),
            "f1": ratio(2 * tp, 2 * tp + fp + fn), "accuracy": ratio(tp + tn, len(results)),
            "confusion_matrix": {"TP": tp, "FP": fp, "FN": fn, "TN": tn}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--rules", type=Path, default=RULES_PATH)
    args = parser.parse_args()
    cases = list(dataset())
    training = training_rows(cases)
    tree = train(training)
    rules = load_rules(args.rules)
    predictions = [
        {"id": row["id"], "actual": actual, "rules": evaluate(findings, rules)["detected"],
         "tree": tree.predict(features(findings))}
        for row, findings, actual in cases if row["split"] == "test"
    ]
    report = {"train_count": len(training), "test_count": len(predictions),
              "rules_version": rules["version"], "tree_features": FEATURES, "tree_model": asdict(tree),
              "rules": metrics([(row["actual"], row["rules"]) for row in predictions]),
              "tree": metrics([(row["actual"], row["tree"]) for row in predictions]),
              "predictions": predictions}
    output = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        write_report(args.output, output)
    print(output, end="")


if __name__ == "__main__":
    main()
