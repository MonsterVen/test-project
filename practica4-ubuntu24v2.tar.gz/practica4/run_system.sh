#!/usr/bin/env bash
set -euo pipefail

root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if (( $# == 0 )); then
    cd "$root"
    mkdir -p results
    set -- --nmap examples/nmap.xml --masscan examples/masscan.json \
        --nikto examples/nikto.json --output results/reports.json
fi
exec python3 "$root/analyze.py" "$@"
