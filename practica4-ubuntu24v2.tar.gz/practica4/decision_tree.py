"""A small binary CART classifier using Gini impurity."""

from dataclasses import dataclass
from itertools import pairwise


FEATURES = ("telnet", "management", "web_alert", "hardening", "open_ports")


def features(findings):
    tcp = {item["port"] for item in findings
           if item.get("protocol") == "tcp" and item["type"] in ("port", "service")}
    web = {item["severity"] for item in findings if item["source"] == "nikto"}
    return (int(23 in tcp), int(bool(tcp & {445, 3389})),
            int(bool(web & {"critical", "high"})), int("medium" in web), len(tcp))


@dataclass(frozen=True)
class Leaf:
    detected: bool

    def predict(self, sample):
        return self.detected


@dataclass(frozen=True)
class Split:
    feature: int
    threshold: float
    left: object
    right: object

    def predict(self, sample):
        branch = self.left if sample[self.feature] <= self.threshold else self.right
        return branch.predict(sample)


def impurity(rows):
    ratio = sum(label for _, label in rows) / len(rows)
    return 2 * ratio * (1 - ratio)


def train(rows, depth=3):
    if not rows:
        raise ValueError("the training set is empty")
    positive = sum(label for _, label in rows)
    leaf = Leaf(positive * 2 > len(rows))
    if depth == 0 or positive in (0, len(rows)):
        return leaf
    best = None
    best_cost = impurity(rows) * len(rows)
    for column in range(len(FEATURES)):
        values = sorted({sample[column] for sample, _ in rows})
        for lower, upper in pairwise(values):
            threshold = (lower + upper) / 2
            left = [row for row in rows if row[0][column] <= threshold]
            right = [row for row in rows if row[0][column] > threshold]
            if min(len(left), len(right)) < 2:
                continue
            cost = len(left) * impurity(left) + len(right) * impurity(right)
            if cost < best_cost - 1e-12:
                best_cost = cost
                best = (column, threshold, left, right)
    if best is None:
        return leaf
    column, threshold, left, right = best
    return Split(column, threshold, train(left, depth - 1), train(right, depth - 1))
