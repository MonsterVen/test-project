package main

import (
	"context"
	"embed"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

//go:embed web/*
var assets embed.FS

const fileLimit = 8 << 20

func writeError(w http.ResponseWriter, status int, message string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]string{"error": message})
}

func findUploads(w http.ResponseWriter, r *http.Request, dir string) ([]string, error) {
	r.Body = http.MaxBytesReader(w, r.Body, 3*fileLimit+(64<<10))
	parts, err := r.MultipartReader()
	if err != nil {
		return nil, fmt.Errorf("ожидается запрос multipart/form-data")
	}
	names := map[string]string{"nmap": "nmap.xml", "masscan": "masscan.json", "nikto": "nikto.json"}
	seen := map[string]bool{}
	var args []string
	for {
		part, err := parts.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("не удалось прочитать загруженные файлы")
		}
		name := part.FormName()
		filename, allowed := names[name]
		if !allowed || seen[name] || part.FileName() == "" {
			return nil, fmt.Errorf("ожидается по одному файлу для каждого выбранного источника")
		}
		seen[name] = true
		path := filepath.Join(dir, filename)
		file, err := os.Create(path)
		if err != nil {
			return nil, fmt.Errorf("не удалось создать временный файл")
		}
		size, copyErr := io.Copy(file, io.LimitReader(part, fileLimit+1))
		closeErr := file.Close()
		if copyErr != nil || closeErr != nil || size == 0 || size > fileLimit {
			return nil, fmt.Errorf("%s: требуется файл размером от 1 байта до 8 МиБ", name)
		}
		args = append(args, "--"+name, path)
	}
	if len(args) == 0 {
		return nil, fmt.Errorf("добавьте хотя бы один отчёт")
	}
	return args, nil
}

func command(ctx context.Context, root, script string, args ...string) *exec.Cmd {
	return exec.CommandContext(ctx, "python3", append([]string{filepath.Join(root, script)}, args...)...)
}

func runAnalysis(w http.ResponseWriter, r *http.Request, root, rules string, args []string) {
	ctx, cancel := context.WithTimeout(r.Context(), 25*time.Second)
	defer cancel()
	cmd := command(ctx, root, "analyze.py", append([]string{"--rules", rules}, args...)...)
	output, err := cmd.Output()
	if ctx.Err() != nil {
		writeError(w, http.StatusGatewayTimeout, "превышено время анализа")
		return
	}
	if exit, ok := err.(*exec.ExitError); ok {
		writeError(w, http.StatusUnprocessableEntity, strings.TrimSpace(string(exit.Stderr)))
		return
	}
	if err != nil {
		log.Printf("run analysis: %v", err)
		writeError(w, http.StatusInternalServerError, "не удалось запустить анализ")
		return
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Write(output)
}

func main() {
	port := flag.Int("port", 8080, "HTTP port on 127.0.0.1")
	ruleFile := flag.String("rules", "", "path to an alternative JSON rule set")
	flag.Parse()
	executable, err := os.Executable()
	if err != nil {
		log.Fatal(err)
	}
	root := filepath.Dir(filepath.Dir(executable))
	rules := *ruleFile
	if rules == "" {
		rules = filepath.Join(root, "rules.json")
	}
	if output, err := command(context.Background(), root, "expert_system.py", rules).CombinedOutput(); err != nil {
		log.Fatalf("validate rules: %s %v", output, err)
	}
	slots := make(chan struct{}, 2)
	limited := func(handler http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			select {
			case slots <- struct{}{}:
				defer func() { <-slots }()
				handler(w, r)
			default:
				writeError(w, http.StatusServiceUnavailable, "анализатор занят, повторите запрос")
			}
		}
	}

	mux := http.NewServeMux()
	mux.Handle("GET /web/", http.FileServer(http.FS(assets)))
	mux.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/web/", http.StatusTemporaryRedirect)
	})
	mux.HandleFunc("GET /api/demo", limited(func(w http.ResponseWriter, r *http.Request) {
		examples := filepath.Join(root, "examples")
		runAnalysis(w, r, root, rules, []string{
			"--nmap", filepath.Join(examples, "nmap.xml"),
			"--masscan", filepath.Join(examples, "masscan.json"),
			"--nikto", filepath.Join(examples, "nikto.json"),
		})
	}))
	mux.HandleFunc("POST /api/analyze", limited(func(w http.ResponseWriter, r *http.Request) {
		dir, err := os.MkdirTemp("", "ias-reports-")
		if err != nil {
			writeError(w, http.StatusInternalServerError, "не удалось подготовить временную папку")
			return
		}
		defer os.RemoveAll(dir)
		args, err := findUploads(w, r, dir)
		if err != nil {
			writeError(w, http.StatusBadRequest, err.Error())
			return
		}
		runAnalysis(w, r, root, rules, args)
	}))
	server := http.Server{
		Addr: fmt.Sprintf("127.0.0.1:%d", *port), Handler: mux,
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second,
		WriteTimeout: 45 * time.Second, IdleTimeout: 30 * time.Second,
	}
	log.Printf("http://%s", server.Addr)
	log.Fatal(server.ListenAndServe())
}
