#include <charconv>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

#include <libxml/parser.h>
#include <nlohmann/json.hpp>

using Json = nlohmann::json;

bool named(xmlNode* node, const char* name) {
    return node && node->type == XML_ELEMENT_NODE &&
           xmlStrEqual(node->name, BAD_CAST name);
}

xmlNode* child(xmlNode* parent, const char* name) {
    for (auto* node = parent ? parent->children : nullptr; node; node = node->next) {
        if (named(node, name)) return node;
    }
    return nullptr;
}

std::string attr(xmlNode* node, const char* name) {
    if (!node) return {};
    std::unique_ptr<xmlChar, decltype(xmlFree)> value(xmlGetProp(node, BAD_CAST name), xmlFree);
    return value ? reinterpret_cast<const char*>(value.get()) : "";
}

Json parse_host(xmlNode* host) {
    Json addresses = Json::array();
    for (auto* node = host->children; node; node = node->next) {
        if (!named(node, "address")) continue;
        const auto type = attr(node, "addrtype");
        if (type == "ipv4" || type == "ipv6") addresses.push_back(attr(node, "addr"));
    }
    Json ports = Json::array();
    if (auto* section = child(host, "ports")) {
        for (auto* node = section->children; node; node = node->next) {
            if (!named(node, "port")) continue;
            const auto id = attr(node, "portid");
            unsigned number = 0;
            const auto end = id.data() + id.size();
            const auto parsed = std::from_chars(id.data(), end, number);
            if (parsed.ec != std::errc{} || parsed.ptr != end || number > 65535) {
                throw std::runtime_error("invalid portid");
            }
            auto* service = child(node, "service");
            ports.push_back({{"port", number}, {"protocol", attr(node, "protocol")},
                             {"state", attr(child(node, "state"), "state")},
                             {"service", attr(service, "name")},
                             {"product", attr(service, "product")},
                             {"version", attr(service, "version")}});
        }
    }
    return {{"addresses", addresses}, {"ports", ports},
            {"hostname", attr(child(child(host, "hostnames"), "hostname"), "name")}};
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: nmap_parser FILE.xml\n";
        return 2;
    }
    try {
        std::unique_ptr<xmlDoc, decltype(&xmlFreeDoc)> document(
            xmlReadFile(argv[1], nullptr, XML_PARSE_NONET | XML_PARSE_NOERROR | XML_PARSE_NOWARNING),
            xmlFreeDoc);
        auto* root = document ? xmlDocGetRootElement(document.get()) : nullptr;
        if (!named(root, "nmaprun")) throw std::runtime_error("expected Nmap XML");
        // Permit the empty <!DOCTYPE nmaprun> emitted by Nmap.
        auto* dtd = document->intSubset;
        if (dtd && (dtd->children || dtd->SystemID || dtd->ExternalID)) {
            throw std::runtime_error("custom XML document types are unsupported");
        }
        if (attr(child(child(root, "runstats"), "finished"), "exit") == "error") {
            throw std::runtime_error("Nmap report indicates an unsuccessful run");
        }
        Json hosts = Json::array();
        for (auto* node = root->children; node; node = node->next) {
            if (named(node, "host")) hosts.push_back(parse_host(node));
        }
        std::cout << Json({{"hosts", hosts}}).dump() << '\n';
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
