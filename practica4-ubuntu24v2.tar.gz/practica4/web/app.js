"use strict";

const form = document.querySelector("#upload");
const demo = document.querySelector("#demo");
const status = document.querySelector("#status");
const results = document.querySelector("#results");
const reports = document.querySelector("#reports");

const levels = {
  critical: "Критическая", high: "Высокая", medium: "Средняя",
  low: "Низкая", info: "Справочная",
};

function append(parent, tag, value) {
  const element = document.createElement(tag);
  if (value !== undefined) element.textContent = value;
  parent.append(element);
  return element;
}

function renderSeverity(panel, findings) {
  append(panel, "h3", "Серьёзность находок");
  const counts = Object.fromEntries(Object.keys(levels).map((level) => [level, 0]));
  for (const finding of findings) {
    if (Object.hasOwn(counts, finding.severity)) counts[finding.severity]++;
  }
  for (const [level, label] of Object.entries(levels)) {
    const row = append(panel, "div");
    row.className = "severity";
    append(row, "span", label);
    const bar = append(row, "meter");
    bar.min = 0;
    bar.max = Math.max(1, findings.length);
    bar.value = counts[level];
    bar.setAttribute("aria-label", label);
    append(row, "span", counts[level]);
  }
}

function renderFindings(panel, findings) {
  if (!findings.length) return;
  const wrap = append(panel, "div");
  wrap.className = "table-wrap";
  const table = append(wrap, "table");
  const headings = append(append(table, "thead"), "tr");
  for (const title of ["Источник", "Порт", "Серьёзность", "Описание"]) {
    append(headings, "th", title).scope = "col";
  }
  const body = append(table, "tbody");
  for (const item of findings) {
    const row = append(body, "tr");
    const port = item.protocol ? `${item.port}/${item.protocol}` : item.port;
    for (const text of [item.source, port, levels[item.severity] ?? item.severity, item.description]) {
      append(row, "td", text);
    }
  }
}

function renderReport(report) {
  const panel = append(reports, "article");
  panel.className = "panel";
  append(panel, "h3", report.target);
  const incident = report.incident;
  const verdict = incident.detected ? "Требуется проверка" : "Порог риска не достигнут";
  const summary = append(panel, "p", `${verdict} · Риск ${incident.risk_score}/10`);
  summary.className = incident.detected ? "alert" : "clear";
  append(panel, "p", `Версия правил ${incident.rules_version} · Дерево решений: ${report.decision_tree.detected ? "сигнал" : "без сигнала"}`);
  if (incident.triggering_findings.length) {
    append(panel, "p", `Сработали правила — ${incident.triggering_findings.map((item) => item.rule).join(", ")}`);
  }
  if (incident.recommendations.length) {
    append(panel, "h3", "Рекомендации");
    const list = append(panel, "ul");
    for (const advice of incident.recommendations) append(list, "li", advice);
  }
  renderSeverity(panel, report.findings);
  renderFindings(panel, report.findings);
}

async function analyze(url, options) {
  const buttons = form.querySelectorAll("button");
  buttons.forEach((button) => { button.disabled = true; });
  status.className = "";
  status.textContent = "Анализирую отчёты…";
  results.hidden = true;
  reports.replaceChildren();
  try {
    const response = await fetch(url, options);
    const output = await response.json();
    if (!response.ok) throw new Error(output.error || `HTTP ${response.status}`);
    output.reports.forEach(renderReport);
    if (!output.reports.length) append(reports, "p", "Отчёты не содержат записей об узлах.");
    results.hidden = false;
    status.textContent = `Проанализировано узлов — ${output.reports.length}`;
  } catch (error) {
    status.className = "alert";
    status.textContent = error.message;
  } finally {
    buttons.forEach((button) => { button.disabled = false; });
  }
}

demo.addEventListener("click", () => analyze("/api/demo"));
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  for (const [name, value] of Array.from(data)) {
    if (!value.name) data.delete(name);
  }
  analyze("/api/analyze", {method: "POST", body: data});
});
