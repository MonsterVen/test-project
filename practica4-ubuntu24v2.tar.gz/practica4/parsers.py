"""Adapters for stored scanner reports."""

import ipaddress
import json
import re
import subprocess


PORT_SEVERITY = {21: "high", 22: "medium", 23: "high", 445: "high",
                 3306: "high", 3389: "high", 5432: "high", 8080: "medium"}


def objects(value):
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise ValueError("expected an array of objects")
    return value


def report_objects(value):
    return objects([value] if isinstance(value, dict) else value)


def address(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("missing target address")
    value = value.strip()
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        name = value.rstrip(".").lower()
        if not re.fullmatch(r"[a-z0-9_-]+(?:\.[a-z0-9_-]+)*", name) or len(name) > 253:
            raise ValueError("invalid target address") from None
        return name


def port_number(value):
    if type(value) is int or (isinstance(value, str) and re.fullmatch(r"[0-9]{1,5}", value)):
        number = int(value)
        if 0 <= number <= 65535:
            return number
    raise ValueError("invalid port number")


def finding(source, kind, port, severity, description, **extra):
    return dict(source=source, type=kind, port=port, severity=severity,
                description=description, service=None, cwe=None, cve=None) | extra


def nmap(path, executable):
    result = subprocess.run([executable, path], capture_output=True, timeout=15)
    if result.returncode:
        raise ValueError(result.stderr.decode("utf-8", errors="replace").strip())
    for host in json.loads(result.stdout)["hosts"]:
        ports = []
        for item in host["ports"]:
            if item["state"] != "open":
                continue
            number = port_number(item["port"])
            service = item["service"] or None
            description = " ".join(filter(None, (item["product"] or service, item["version"])))
            ports.append(finding("nmap", "service", number, PORT_SEVERITY.get(number, "low"),
                                 description or f"Открыт порт {number}", service=service,
                                 protocol=item["protocol"], state="open", version=item["version"]))
        for target in host["addresses"] or ([host["hostname"]] if host["hostname"] else []):
            yield address(target), ports


def masscan(path):
    content = path.read_text(encoding="utf-8-sig")
    try:
        records = json.loads(content)
    except json.JSONDecodeError:
        records = [json.loads(line) for line in content.splitlines() if line.strip()]
        if not records:
            raise ValueError("expected Masscan JSON or NDJSON") from None
    for record in report_objects(records):
        target = address(record["ip"])
        if "ports" in record:
            entries = objects(record["ports"])
        elif record.get("rec_type") == "status":
            entries = [record["data"] | {"port": record["port"], "proto": record["proto"]}]
        elif record.get("rec_type") == "banner":
            continue
        else:
            raise ValueError("missing Masscan port records")
        findings = []
        for entry in entries:
            if "status" not in entry and isinstance(entry.get("service"), dict):
                continue  # Metadata-only banner record.
            if entry["status"] != "open":
                continue
            number = port_number(entry["port"])
            protocol = entry["proto"]
            if not isinstance(protocol, str) or not protocol:
                raise ValueError("invalid Masscan protocol")
            findings.append(finding("masscan", "port", number, PORT_SEVERITY.get(number, "low"),
                                    f"Открыт порт {number}", protocol=protocol, state="open"))
        yield target, findings


def nikto(path):
    for record in report_objects(json.loads(path.read_text(encoding="utf-8-sig"))):
        target = address(record.get("ip") or record.get("host") or record.get("hostname"))
        port = port_number(record["port"])
        findings = []
        for item in objects(record["vulnerabilities"]):
            message = item.get("msg") or item.get("message") or item.get("description")
            if not isinstance(message, str) or not message:
                raise ValueError("missing Nikto finding message")
            references = " ".join(str(item.get(key, "")) for key in ("refs", "references"))
            cve = re.search(r"\bCVE-\d{4}-\d{4,}\b", references + " " + message, re.I)
            level, cwe = nikto_indicator(message.casefold())
            findings.append(finding("nikto", "vulnerability", port, level, message, service="http",
                                    cwe=cwe, cve=cve.group().upper() if cve else None))
        yield target, findings


def nikto_indicator(message):
    if "sql injection" in message:
        return "critical", "CWE-89"
    if "cross-site scripting" in message or re.search(r"\bxss\b", message):
        return "high", "CWE-79"
    if ".git" in message or "backup" in message:
        return "high", None
    if "x-frame-options" in message:
        return "medium", "CWE-1021"
    if "x-content-type-options" in message:
        return "medium", None
    return "low", None
