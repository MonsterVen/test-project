"use strict";

const feedback = byId("feedback");
const params = new URLSearchParams(location.search);

function message(text, problem = false) {
    feedback.textContent = text;
    feedback.className = problem ? "problem" : "good";
}

async function submit(button, task) {
    button.disabled = true;
    try {
        await task();
    } catch (error) {
        message(error.message, true);
    } finally {
        button.disabled = false;
    }
}

async function findingPage() {
    const result = await api("/api/finding?" + params);
    const item = result.finding;
    byId("title").textContent = levels[item.severity] + " — " + item.title;
    const where = byId("where");
    where.textContent = item.path ? "Местоположение " : "";
    append(where, "code", locationLabel(item));
    byId("root").textContent = result.project;
    byId("what").textContent = item.explanation;
    if (item.cvss) {
        append(byId("what"), "strong", " CVSS 3.1 · " + item.cvss.risk.toFixed(1) + "/10. ");
        append(byId("what"), "code", item.cvss.vector);
        append(byId("what"), "span", " Условия оценки. " + item.cvss.assumption);
    }
    if (item.cwe) {
        const cwe = byId("cwe");
        const reference = append(cwe, "a", item.cwe);
        reference.href = "https://cwe.mitre.org/data/definitions/" + item.cwe.slice(4) + ".html";
        reference.target = "_blank";
        reference.rel = "noopener noreferrer";
        cwe.hidden = false;
    }
    if (item.remediation) {
        byId("fix").textContent = item.remediation;
        byId("fix-panel").hidden = false;
    }
    byId("finding").hidden = false;
    const isolate = byId("isolate");
    isolate.hidden = !item.isolate;
    isolate.addEventListener("click", () => submit(isolate, async () => {
        await api("/api/quarantine/add", {report: result.report, index: result.index});
        isolate.hidden = true;
        message("Файл перемещён в карантин.");
    }));
}

async function quarantinePage() {
    const fresh = await api("/api/quarantine");
    byId("maintenance").hidden = !fresh.maintenance;
    const list = byId("files");
    list.replaceChildren();
    const empty = byId("empty");
    empty.textContent = "В карантине пока нет файлов.";
    empty.hidden = fresh.files.length > 0;
    for (const item of fresh.files) {
        const row = append(list, "article");
        row.className = "panel";
        const link = append(append(row, "h2"), "a");
        link.href = "/quarantine-file?id=" + encodeURIComponent(item.id);
        append(link, "code", item.path);
        append(row, "p", item.project);
        const lines = [...new Set(item.locations.map((location) => location.line).filter(Boolean))];
        if (lines.length) append(row, "p", "Строки: " + lines.join(", "));
        const button = append(row, "button", "Восстановить файл");
        button.type = "button";
        button.addEventListener("click", () => submit(button, async () => {
            await api("/api/quarantine/restore", {id: item.id});
            await quarantinePage();
            message("Файл возвращён на исходное место.");
        }));
    }
}

async function quarantineFilePage() {
    const item = await api("/api/quarantine-file?" + params);
    byId("filename").textContent = item.path;
    byId("root").textContent = item.project;
    byId("size").textContent = "Размер " + item.size + " байт";
    for (const position of item.locations) {
        const row = append(byId("locations"), "li");
        const text = (position.line ? "Строка " + position.line + " — " : "") + position.title;
        if (position.report !== null && position.index !== null) {
            append(row, "a", text).href = "/finding?report=" + position.report + "&index=" + position.index;
        } else {
            row.textContent = text;
        }
    }
    if (!item.locations.length) append(byId("locations"), "li", "В отчёте нет номера строки.");
    if (item.preview) {
        const marked = new Set(item.locations.map((position) => position.line));
        item.preview.forEach((line, index) => {
            const row = append(byId("lines"), "li");
            append(row, "code", line);
            if (marked.has(index + 1)) row.className = "marked";
        });
        byId("preview").hidden = false;
    }
    byId("file").hidden = false;
    const restore = byId("restore");
    restore.addEventListener("click", () => submit(restore, async () => {
        await api("/api/quarantine/restore", {id: item.id});
        restore.hidden = true;
        message("Файл возвращён на исходное место.");
    }));
}

async function scenariosPage() {
    const data = await api("/api/scenarios");
    byId("root").textContent = data.project;
    const choices = byId("choices");
    for (const [value, choice] of Object.entries(data.choices)) {
        const label = append(choices, "label");
        const checkbox = append(label, "input");
        checkbox.type = "checkbox";
        checkbox.name = "selected";
        checkbox.value = value;
        append(label, "span", choice.label + " · " + levels[choice.severity] + " · " + choice.risk.toFixed(1));
        const detail = append(choices, "details");
        append(detail, "summary", "Вектор и условия оценки");
        append(detail, "code", choice.vector);
        append(detail, "p", choice.assumption);
    }
    const form = byId("scenario");
    const create = byId("create");
    const rollback = byId("rollback");
    const credentials = byId("credentials");
    let active = data.active;
    const chosen = () => [...choices.querySelectorAll("input:checked")].map((input) => input.value);
    function render() {
        const selected = chosen();
        const risk = Math.max(0, ...selected.map((name) => data.choices[name].risk));
        byId("risk").textContent = risk ? "Максимум CVSS 3.1 · " + risk.toFixed(1) + "/10" : "Выберите уязвимости для расчёта CVSS";
        choices.disabled = active || !data.catalog;
        credentials.hidden = active || !selected.includes("admin");
        credentials.disabled = credentials.hidden;
        create.disabled = active || !data.catalog || !selected.length;
        rollback.disabled = !active;
    }
    if (!data.catalog) message("Для этого конструктора выберите папку запущенного каталога.", !data.active);
    choices.addEventListener("change", render);
    render();
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        const selected = chosen();
        const request = {selected, project: data.project};
        if (selected.includes("admin")) {
            request.username = byId("username").value.trim();
            request.current_password = byId("current-password").value;
            request.new_password = byId("new-password").value;
        }
        submit(create, async () => {
            const result = await api("/api/scenarios/create", request);
            active = true;
            byId("current-password").value = "";
            byId("new-password").value = "";
            message("Применено изменений: " + result.changes + " · Максимум CVSS 3.1 · " + result.risk + "/10. Аудит по расписанию или вручную.");
        }).then(render);
    });
    rollback.addEventListener("click", () => {
        submit(rollback, async () => {
            const result = await api("/api/scenarios/rollback", {project: data.project});
            active = false;
            form.reset();
            message("Восстановлено изменений: " + result.changes + "." + (result.password_changed_again
                ? " Более поздний пароль сохранён." : ""));
        }).then(render);
    });
}

async function testingPage() {
    let active;
    const table = byId("results");
    function renderRows() {
        table.replaceChildren();
        if (!active) return;
        const showClean = byId("show-tn").checked;
        for (const item of active.rows) {
            if (item.outcome === "TN" && !showClean) continue;
            const row = append(table, "tr");
            for (const value of [item.file, item.rule, item.actual ? "Да" : "Нет", item.predicted ? "Да" : "Нет",
                item.outcome, item.lines || "—", item.case]) append(row, "td", value);
        }
    }
    function render(result) {
        active = result;
        byId("result-heading").textContent = result.label;
        byId("suite").value = result.suite;
        const metrics = byId("metrics");
        metrics.replaceChildren();
        for (const [label, value] of [["Precision", result.precision], ["Recall", result.recall], ["F1", result.f1]]) {
            const group = append(metrics, "div");
            append(group, "dt", label);
            append(group, "dd", value.toLocaleString("ru-RU", {minimumFractionDigits: 4}));
        }
        byId("counts").textContent = "Файлов: " + result.cases + " · "
            + Object.entries(result.counts).map(([key, count]) => key + " " + count).join(" · ");
        byId("dataset").href = "/api/dataset?report=" + result.id;
        byId("result").hidden = false;
        renderRows();
    }
    byId("show-tn").addEventListener("change", renderRows);
    byId("testing").addEventListener("submit", (event) => {
        event.preventDefault();
        submit(event.submitter, async () => {
            message("Выполняется тестирование…");
            const result = await api("/api/testing", {suite: byId("suite").value});
            history.replaceState(null, "", "/testing?report=" + result.id);
            render(result);
            message("Результат сохранён в истории.");
        });
    });
    if (params.has("report")) render(await api("/api/test-result?" + params));
}

const pages = {finding: findingPage, quarantine: quarantinePage, "quarantine-file": quarantineFilePage,
    scenarios: scenariosPage, testing: testingPage};
pages[document.body.dataset.page]().catch((error) => message(error.message, true));
