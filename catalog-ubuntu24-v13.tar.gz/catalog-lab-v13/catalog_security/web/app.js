"use strict";

const form = byId("settings");
const project = byId("project");
const interval = byId("interval");
const history = byId("history");
const feedback = byId("feedback");
const older = byId("older");
let entries = new Map();
let before;
let edited = false;
let polling = false;

const selectedProject = new URLSearchParams(location.search).get("project");
const kinds = {revoked: "Удаление из белого списка", deleted: "Удаление из карантина", replaced: "Замена файла", availability: "Доступность", allowed: "Ложное срабатывание", rules: "Правила изменены", scheduled: "По расписанию", manual: "Вручную", configuration: "После смены настроек",
    file_change: "Изменения на диске", applied: "Применение сценария", rollback: "Возврат сценария", restored: "Восстановление файла",
    simulation: "Контрольная запись", testing: "Тестирование"};
const sources = {static: "Код", integrity: "Целостность", runtime: "Журнал",
    health: "Доступность", simulation: "Контрольная запись", scenario: "Контрольный файл"};

function outcome(entry) {
    if (entry.kind === "allowed") return ["Ложное срабатывание", "neutral"];
    if (entry.kind === "availability" && entry.health?.status === "ok") return ["Доступ восстановлен", "good"];
    if (entry.error) return ["Ошибка проверки", "problem"];
    if (entry.health?.status === "down" && !(entry.findings || []).some(f => ["scenario", "static", "integrity"].includes(f.source))) return ["Ресурс не работает", "problem"];
    if (entry.finding_count) {
        const score = entry.incident.profile_max ?? entry.incident.risk_score;
        return [score >= 9 ? "Критическая уязвимость" : "Обнаружена уязвимость", tone(score)];
    }
    if (entry.health?.status === "maintenance") return ["Ресурс не работает", "problem"];
    if (entry.health?.status === "down") return ["Ресурс не работает", "problem"];
    if (Object.values(entry.file_changes || {}).some(names => names.length)) return ["Изменение файлов", "neutral"];
    return ["Ничего не найдено", "good"];
}

function makeEntry(entry) {
    const details = document.createElement("details");
    details.dataset.id = entry.id;
    details.id = "report-" + entry.id;
    const changes = entry.file_changes;
    const changed = changes && Object.values(changes).some(paths => paths.length);
    let changeText = changes && "Изменение файлов · добавлено " + changes.added.length
        + " · изменено " + changes.changed.length + " · удалено " + changes.removed.length;
    if (changed && Object.values(changes).flat().length === 1) {
        const [key, paths] = Object.entries(changes).find(([, names]) => names.length);
        changeText = "Файл " + filename(paths[0]) + " " + {added: "добавлен", changed: "изменён", removed: "удалён"}[key];
    }
    const down = ["down", "maintenance"].includes(entry.health?.status);
    const summary = append(details, "summary");
    append(summary, "time", time(entry.created_at)).dateTime = entry.created_at;
    append(summary, "span", kinds[entry.kind] || entry.kind);
    if (entry.kind === "allowed") append(summary, "span", " · " + filename(entry.allowed_file));
    else if (entry.testing) append(summary, "span", " · F1 " + entry.testing.f1);
    else if (entry.kind !== "rules") {
        const [label, color] = outcome(entry);
        append(summary, "span", " · " + label).className = color;
    }
    if (changed && entry.kind !== "allowed") append(summary, "span", " · " + changeText);
    else if (entry.finding_count && !entry.allowed_file) {
        const names = [...new Set(entry.findings.map(f => f.path).filter(Boolean))];
        if (names.length === 1) append(summary, "span", " · " + filename(names[0]));
    }
    const detail = append(details, "div");
    detail.className = "detail";
    projectLink(append(detail, "p"), entry.project);
    if (entry.settings_change) {
        const {before, after} = entry.settings_change;
        if (before.interval !== after.interval) append(detail, "p", "Интервал проверки: " + before.interval + " → " + after.interval + " с");
        if (before.project !== after.project) append(detail, "p", "Папка: " + before.project + " → " + after.project);
        return details;
    }
    if (entry.revoked_file) append(detail, "p", "Исключение удалено: " + entry.revoked_file);
    if (entry.allowed_file) append(detail, "p", "Разрешена текущая версия файла " + filename(entry.allowed_file));
    if (entry.testing) {
        append(detail, "p", entry.testing.label + " · Precision " + entry.testing.precision
            + " · Recall " + entry.testing.recall + " · F1 " + entry.testing.f1);
        append(detail, "a", "Открыть результаты и датасет").href = "/testing?report=" + entry.id;
        return details;
    }

    if (entry.error) {
        append(detail, "p", entry.error);
        return details;
    }
    if (entry.health && entry.health.status !== "not_applicable") {
        append(detail, "p", "Статус: " + (down ? "Не работает" : "Работает")
            + (entry.health.http ? " · HTTP " + entry.health.http : ""));
    }
    if (changed) {
        for (const [key, title] of [["added", "Добавлено"], ["changed", "Изменено"], ["removed", "Удалено"]]) {
            if (!changes[key].length) continue;
            const group = append(detail, "details");
            append(group, "summary", title + " · " + changes[key].length);
            const list = append(group, "ul");
            for (const path of changes[key]) append(list, "li", filename(path));
        }
    }

    if (entry.inventory) {
        const files = entry.inventory;
        const inventory = append(detail, "details");
        append(inventory, "summary", "Найденные файлы · " + files.scanned + " проверено, " + files.skipped + " пропущено");
        const counts = Object.entries(files.counts).map(([type, count]) => type + " (" + count + ")");
        append(inventory, "p", counts.join(", ") || "Подходящих файлов нет.");
        append(inventory, "p", "Корневая папка сайта: " + (files.web_root ?? "не определён"));
        if (files.examples.length) {
            const list = append(inventory, "ul");
            for (const name of files.examples) fileLink(append(list, "li"), entry.id, name, filename(name));
        }
    }
    if (entry.findings.length) {
        const detections = append(detail, "details");
        append(detections, "summary", "Обнаружения · " + entry.finding_count);
        const scores = entry.findings.map(f => (f.cvss || f.assessment)?.risk).filter(Number.isFinite);
        append(detections, "p", "Риск по CVSS 3.1: " + (scores.length ? (entry.incident.profile_max ?? Math.max(...scores)).toFixed(1) + "/10" : "оценка отсутствует"));
        const results = append(detections, "ul");
        for (const item of entry.findings) {
            const row = append(results, "li");
            const assessment = item.cvss || item.assessment;
            append(row, "span", item.title);
            if (item.path) append(row, "span", " · " + filename(item.path) + (item.line ? ":" + item.line : ""));
            if (assessment) append(row, "span", " · " + assessment.risk.toFixed(1)).className = tone(assessment.risk);
        }
        const quarantine = append(detections, "a", "Открыть карантин");
        quarantine.className = "button danger-button";
        quarantine.href = "/quarantine?report=" + entry.id;
        if (entry.finding_count > entry.findings.length) {
            append(detail, "p", "Показаны первые " + entry.findings.length + " находок.");
        }
    }
    if (entry.incident.risk_score >= 8 && entry.target_count && !entry.auto_quarantine) {
        const controls = append(detail, "div");
        controls.className = "controls";
        const button = append(controls, "button", "Изолировать все файлы");
        button.className = "danger-button";
        button.type = "button";
        const message = append(controls, "p");
        message.setAttribute("role", "status");
        button.addEventListener("click", async () => {
            if (!window.confirm("Перенести файлы с находками в карантин? Для Web ресурса включится режим обслуживания.")) return;
            button.disabled = true;
            try {
                const result = await api("/api/quarantine/bulk", {report: entry.id});
                message.textContent = "Изолировано файлов: " + result.files + ". ";
                append(message, "a", "Открыть карантин").href = "/quarantine";
                await refresh();
            } catch (error) {
                message.className = "problem";
                message.textContent = error.message;
                button.disabled = false;
            }
        });
    }
    if (entry.incident.recommendations.length) {
        append(detail, "h3", "Рекомендации");
        const list = append(detail, "ul");
        for (const recommendation of entry.incident.recommendations) append(list, "li", recommendation);
    }
    return details;
}

function merge(rows) {
    for (const entry of rows) {
        if (selectedProject && selectedProject !== entry.project) continue;
        const previous = entries.get(entry.id);
        if (!previous || Boolean(previous.entry.auto_quarantine) !== Boolean(entry.auto_quarantine)) {
            const node = makeEntry(entry);
            if (previous) {
                node.open = previous.node.open;
                previous.node.replaceWith(node);
            }
            entries.set(entry.id, {entry, node});
        }
    }
    const ordered = [...entries.values()].sort((a, b) => b.entry.id - a.entry.id);
    let pointer = history.firstElementChild;
    for (const {node} of ordered) {
        if (node === pointer) pointer = pointer.nextElementSibling;
        else history.insertBefore(node, pointer);
    }
    byId("empty").hidden = ordered.length > 0;
    drawAvailability();
}

let graphKey;
function drawAvailability() {
    const samples = [...entries.values()].map(({entry, node}) => ({
        entry, node,
        measured: ["ok", "down", "maintenance"].includes(entry.health?.status),
        changed: Object.values(entry.file_changes || {}).some(paths => paths.length),
        tested: entry.kind === "testing"
    })).filter(sample => sample.measured || sample.changed || sample.tested)
        .sort((a, b) => a.entry.id - b.entry.id);
    const key = samples.map(({entry}) => entry.id + "/" + Boolean(entry.auto_quarantine)).join(",");
    if (key === graphKey) return;
    graphKey = key;
    const box = byId("availability");
    box.replaceChildren();
    if (!samples.length) {
        append(box, "p", "Пока нет проверок или событий.");
        return;
    }
    function svg(parent, tag, attrs, text) {
        const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
        for (const [name, value] of Object.entries(attrs)) el.setAttribute(name, value);
        if (text) el.textContent = text;
        parent.append(el);
        return el;
    }
    const width = Math.max(610, 190 + samples.length * 28);
    const chart = svg(box, "svg", {width, height: 100, "aria-label": "Доступность Web ресурса и события проверок"});
    const left = 113, right = width - 25;
    for (const [label, y] of [["Работает", 30], ["Не работает", 77]]) {
        svg(chart, "text", {x: 4, y: y + 4}, label);
        svg(chart, "line", {x1: left, x2: right, y1: y, y2: y, stroke: "#c9d7d8"});
    }
    let line = "";
    let lastMeasuredY = null;
    const markers = samples.map(({entry, node, measured, tested}, i) => {
        const x = left + i * (right - left) / Math.max(1, samples.length - 1);
        if (measured) lastMeasuredY = entry.health.status === "ok" ? 30 : 77;
        const y = lastMeasuredY ?? (30 + 77) / 2;
        if (lastMeasuredY !== null) line += line ? " H" + x + " V" + y : "M" + x + " " + y;
        const [label, resultColor] = tested ? ["Тестирование", "testing"] : outcome(entry);
        const color = label === "Изменение файлов" && !entry.finding_count ? "change" : resultColor;
        return {entry, node, x, y, label, color};
    });
    svg(chart, "path", {d: line, fill: "none", stroke: "#668781", "stroke-width": 2});
    for (const {entry, node, x, y, label, color} of markers) {
        const stamp = time(entry.created_at);
        const link = svg(chart, "a", {href: "#" + node.id, "aria-label": stamp + " · " + label});
        svg(link, "title", {}, stamp + " · " + label);
        svg(link, "circle", {cx: x, cy: y, r: 12, fill: "transparent"});
        svg(link, "circle", {cx: x, cy: y, r: 6, class: "point-" + color});
        link.addEventListener("click", () => { node.open = true; node.querySelector("summary").focus(); });
    }
    const seconds = Math.max(0, Math.round((Date.parse(samples.at(-1).entry.created_at) - Date.parse(samples[0].entry.created_at)) / 1000));
    byId("graph-interval").textContent = "Период на графике: " + Math.floor(seconds / 3600) + " ч " + Math.floor(seconds % 3600 / 60) + " мин " + seconds % 60 + " с";
    box.scrollLeft = box.scrollWidth;
}

function renderStatus(status) {
    if (!edited) {
        project.value = status.project;
        interval.value = status.interval;
    }
    const site = byId("open-site");
    site.href = "http://127.0.0.1:" + status.site_port + "/";
    site.hidden = false;

    const latest = status.last_audit;
    const health = byId("health");
    const current = latest?.health;
    health.textContent = status.maintenance ? "Не работает" : latest?.error ? "Ошибка проверки" : current?.status === "ok" ? "Работает"
        : ["down", "maintenance"].includes(current?.status) ? "Не работает"
        : current?.status === "not_applicable" ? "Для папки аудит файлов" : "Ожидает проверки";
    health.className = status.maintenance || ["down", "maintenance"].includes(current?.status) || latest?.error ? "problem"
        : latest?.findings ? tone(latest.risk) : current?.status === "ok" ? "good" : "";
    byId("last").textContent = latest ? time(latest.created_at) : "—";
    byId("next").textContent = status.running ? "Выполняется" : status.queued ? "В очереди" : time(status.next_check);
}

async function refresh() {
    if (polling) return;
    polling = true;
    try {
        const [status, rows] = await Promise.all([api("/api/status"), api("/api/history")]);
        if (typeof before === "undefined") {
            before = rows.length === 25 ? rows.at(-1).id : null;
            older.hidden = before === null;
        }
        merge(rows);
        renderStatus(status);
    } catch (error) {
        byId("health").textContent = "Панель недоступна";
        byId("health").className = "problem";
    } finally {
        polling = false;
    }
}

async function action(button, route, data, message) {
    button.disabled = true;
    feedback.className = "";
    try {
        await api(route, data);
        if (route === "/api/settings") edited = false;
        feedback.textContent = message;
        await refresh();
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        button.disabled = false;
    }
}

form.addEventListener("input", () => { edited = true; });
form.addEventListener("submit", (event) => {
    event.preventDefault();
    action(event.submitter, "/api/settings", {project: project.value, interval: interval.valueAsNumber},
        "Правила сохранены.");
});
byId("check").addEventListener("click", (event) => {
    action(event.currentTarget, "/api/check", {}, "Запрошена проверка.");
});
let browsing;
async function openFolder(path) {
    try {
        browsing = await api("/api/directories", {path});
        byId("folder-browser").hidden = false;
        byId("browser-path").textContent = browsing.folder;
        byId("parent-folder").disabled = browsing.parent === null;
        const children = byId("subfolders");
        children.replaceChildren();
        for (const folder of browsing.children) {
            const button = append(append(children, "li"), "button", folder.name);
            button.className = "secondary";
            button.addEventListener("click", () => openFolder(folder.path));
        }
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    }
}
byId("browse").addEventListener("click", () => openFolder(project.value.trim() || "."));
byId("parent-folder").addEventListener("click", () => openFolder(browsing.parent));
byId("close-browser").addEventListener("click", () => { byId("folder-browser").hidden = true; });
byId("use-folder").addEventListener("click", () => {
    project.value = browsing.folder;
    edited = true;
    byId("folder-browser").hidden = true;
    project.focus();
});
older.addEventListener("click", async () => {
    older.disabled = true;
    try {
        const rows = await api("/api/history?before=" + before);
        merge(rows);
        before = rows.length === 25 ? rows.at(-1).id : null;
        older.hidden = before === null;
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        older.disabled = false;
    }
});

if (selectedProject) {
    const context = append(byId("history-heading"), "small", " · " + selectedProject + " ");
    append(context, "a", "Все проекты").href = "/";
}
refresh();
setInterval(refresh, 1000);
