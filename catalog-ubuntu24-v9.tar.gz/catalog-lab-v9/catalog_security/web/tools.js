"use strict";

const feedback = byId("feedback");
const params = new URLSearchParams(location.search);

function message(text, problem = false) {
    feedback.textContent = text;
    feedback.className = problem ? "problem" : "good";
}

async function submit(button, task) {
    button.disabled = true;
    try {
        await task();
    } catch (error) {
        message(error.message, true);
    } finally {
        button.disabled = false;
    }
}

async function projectFilePage() {
    const file = await api("/api/file?" + params);
    byId("filename").textContent = file.path;
    projectLink(byId("root"), file.project);
    byId("status").textContent = file.status;
    const report = params.get("report");
    if (file.quarantine) append(byId("status"), "a", " · Открыть в карантине").href = "/quarantine-file?id=" + file.quarantine;
    for (const item of file.locations) {
        const text = (item.line ? "Строка " + item.line + " · " : "") + item.title;
        append(append(byId("locations"), "li"), "a", text).href = "/finding?report=" + report + "&index=" + item.index;
    }
    const button = byId("download");
    button.hidden = !["В карантине", "В проекте"].includes(file.status);
    button.onclick = () => submit(button, () => downloadFile("/api/file-download", {report, path: file.path}, file.path));
}

async function downloadFile(route, data, name) {
        const response = await fetch(route, {method: "POST",
            headers: {"Content-Type": "application/json", "X-Catalog-Action": "1"},
            body: JSON.stringify(data)});
        if (!response.ok) throw new Error((await response.json()).error);
        const url = URL.createObjectURL(await response.blob());
        const link = document.createElement("a");
        link.href = url;
        link.download = filename(name);
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function findingPage() {
    const result = await api("/api/finding?" + params);
    const item = result.finding;
    byId("title").textContent = levels[item.severity] + " — " + item.title;
    const where = byId("where");
    where.textContent = item.path ? "Местоположение " : "";
    if (item.path) fileLink(where, result.report, item.path, locationLabel(item));
    else append(where, "code", locationLabel(item));
    byId("title").className = tone(item.cvss?.risk ?? item.rule_score ?? 0);
    projectLink(byId("root").parentNode, result.project);
    byId("what").textContent = item.explanation;
    if (item.assessment && !item.cvss) item.cvss = item.assessment;
    if (item.cvss) {
        append(byId("what"), "strong", " CVSS 3.1 · " + item.cvss.risk.toFixed(1) + "/10. ");
        append(byId("what"), "code", item.cvss.vector);
        append(byId("what"), "span", " Условия оценки. " + item.cvss.assumption);
    }
    if (item.cwe) {
        const cwe = byId("cwe");
        const reference = append(cwe, "a", item.cwe);
        reference.href = "https://cwe.mitre.org/data/definitions/" + item.cwe.slice(4) + ".html";
        reference.target = "_blank";
        reference.rel = "noopener noreferrer";
        cwe.hidden = false;
    }
    if (item.remediation) {
        byId("fix").textContent = item.remediation;
        byId("fix-panel").hidden = false;
    }
    byId("finding").hidden = false;
    const isolate = byId("isolate");
    isolate.hidden = !item.isolate;
    isolate.addEventListener("click", () => submit(isolate, async () => {
        await api("/api/quarantine/add", {report: result.report, index: result.index});
        isolate.hidden = true;
        message("Файл перемещён в карантин.");
    }));
}

async function quarantinePage() {
    const fresh = await api("/api/quarantine");
    byId("maintenance").hidden = !fresh.maintenance;
    const list = byId("files");
    const report = params.get("report");
    byId("all-reports").hidden = !report;
    const eligible = fresh.files.filter(f => !report || String(f.report) === report);
    if (report && eligible.length === 1) {
        location.replace("/quarantine-file?id=" + eligible[0].id);
        return;
    }
    function render() {
        list.replaceChildren();
        const groups = new Map();
        for (const file of eligible) {
            if (!(file.project + "/" + file.path).toLowerCase().includes(byId("filter").value.toLowerCase())) continue;
            if (byId("level").value && tone(file.risk) !== byId("level").value) continue;
            const key = file.report ?? file.id;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(file);
        }
        byId("empty").hidden = groups.size > 0;
        byId("empty").textContent = "Нет изолированных файлов для этого выбора.";
        for (const files of [...groups.values()].reverse()) {
            const first = files[0];
            const group = append(list, "details");
            group.open = Boolean(report);
            const heading = append(group, "summary", time(first.date) + " · " + (files.length === 1 ? filename(first.path) : "Файлов: " + files.length));
            append(heading, "span", " · Общий риск " + first.risk + "/10").className = tone(first.risk);
            append(heading, "span", " · " + first.project);
            projectLink(append(group, "p"), first.project);
            const items = append(group, "ul");
            for (const item of files) {
                const row = append(items, "li");
                append(row, "a", filename(item.path)).href = "/quarantine-file?id=" + item.id;
                append(row, "span", " · " + [...new Set(item.locations.map(loc => loc.title))].join(", "));
            }
        }
    }
    byId("filter").oninput = render;
    byId("level").onchange = render;
    render();
}

async function quarantineFilePage() {
    const item = await api("/api/quarantine-file?" + params);
    byId("filename").textContent = filename(item.path);
    byId("relative").textContent = item.path;
    projectLink(byId("root"), item.project);
    byId("size").textContent = "Исходный размер: " + item.size + " байт";
    const download = byId("download");
    download.onclick = () => submit(download, () => downloadFile("/api/quarantine/download", {id: item.id}, item.path));
    const upload = byId("upload");
    byId("staged").textContent = item.patched ? "Исправленная версия загружена." : "";
    upload.onclick = () => submit(upload, async () => {
        const file = byId("patch").files[0];
        if (!file || file.size > 1048576) throw new Error("Выберите файл до 1 МиБ.");
        const response = await fetch("/api/quarantine/patch?id=" + item.id, {method:"POST", headers:{"X-Catalog-Action":"1"}, body:file});
        if (!response.ok) throw new Error((await response.json()).error);
        byId("staged").textContent = "Исправленная версия загружена и готова к восстановлению.";
        byId("patch").value = "";
    });
    for (const position of item.locations) {
        const row = append(byId("locations"), "li");
        const text = (position.line ? "Строка " + position.line + " · " : "") + position.title;
        if (position.report != null && position.index != null) {
            append(row, "a", text).href = "/finding?report=" + position.report + "&index=" + position.index;
        } else row.textContent = text;
        append(row, "span", position.cvss ? " · CVSS 3.1 " + position.cvss.risk.toFixed(1) + "/10" : " · CVSS не оценён");
        if (position.description) append(row, "p", position.description);
    }
    const related = (await api("/api/quarantine")).files.filter(f => f.report === item.report);
    const next = related[related.findIndex(f => f.id === item.id) + 1];
    if (next) {
        byId("next-file").hidden = false;
        byId("next-file").href = "/quarantine-file?id=" + next.id;
    }
    if (item.preview) {
        const marked = new Set(item.locations.map((position) => position.line));
        item.preview.forEach((line, index) => {
            const row = append(byId("lines"), "li");
            append(row, "code", line);
            if (marked.has(index + 1)) row.className = "marked";
        });
        byId("preview").hidden = false;
    }
    byId("file").hidden = false;
    const restore = byId("restore");
    restore.addEventListener("click", () => submit(restore, async () => {
        await api("/api/quarantine/restore", {id: item.id, allow: byId("allow").checked});
        byId("file").hidden = true;
        location.replace(next ? "/quarantine-file?id=" + next.id : "/quarantine");
    }));
}

async function scenariosPage() {
    const data = await api("/api/scenarios");
    projectLink(byId("root").parentNode, data.project);
    const choices = byId("choices");
    for (const [value, choice] of Object.entries(data.choices)) {
        const label = append(choices, "label");
        const checkbox = append(label, "input");
        checkbox.type = "checkbox";
        checkbox.name = "selected";
        checkbox.value = value;
        append(label, "span", choice.label);
        append(choices, "p", choice.assumption).className = "scenario-description";
    }
    const form = byId("scenario");
    const create = byId("create");
    const rollback = byId("rollback");
    const credentials = byId("credentials");
    let active = data.active;
    const chosen = () => [...choices.querySelectorAll("input:checked")].map((input) => input.value);
    function render() {
        const selected = chosen();
        const risk = Math.max(0, ...selected.map((name) => data.choices[name].risk));
        byId("risk").textContent = risk ? "Уровень угрозы · " + risk.toFixed(1) + "/10" : "Выберите уязвимости";
        byId("risk").className = risk ? tone(risk) : "";
        choices.disabled = active || !data.catalog;
        credentials.hidden = active || !selected.includes("admin");
        credentials.disabled = credentials.hidden;
        create.disabled = active || !data.catalog || !selected.length;
        rollback.disabled = !active;
    }
    if (!data.catalog) message("Для этого конструктора выберите папку Web ресурса.", !data.active);
    choices.addEventListener("change", render);
    render();
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        const selected = chosen();
        const request = {selected, project: data.project};
        if (selected.includes("admin")) {
            request.username = byId("username").value.trim();
            request.current_password = byId("current-password").value;
            request.new_password = byId("new-password").value;
        }
        submit(create, async () => {
            const result = await api("/api/scenarios/create", request);
            active = true;
            byId("current-password").value = "";
            byId("new-password").value = "";
            message("Применено изменений: " + result.changes + " · Уровень угрозы · " + result.risk + "/10. Изменения проверены.");
            feedback.className = tone(result.risk);
        }).then(render);
    });
    rollback.addEventListener("click", () => {
        submit(rollback, async () => {
            const result = await api("/api/scenarios/rollback", {project: data.project});
            active = false;
            form.reset();
            message("Восстановлено изменений: " + result.changes + ". Проверка завершена." + (result.password_changed_again
                ? " Более поздний пароль сохранён." : ""));
        }).then(render);
    });
}

async function testingPage() {
    let active;
    const table = byId("results");
    function renderRows() {
        table.replaceChildren();
        if (!active) return;
        const showClean = byId("show-tn").checked;
        for (const item of active.rows) {
            if (item.outcome === "TN" && !showClean) continue;
            const row = append(table, "tr");
            fileLink(append(row, "td"), active.id, item.file);
            for (const value of [item.rule, item.actual ? "Да" : "Нет", item.predicted ? "Да" : "Нет",
                item.outcome, item.lines || "—", item.case]) append(row, "td", value);
        }
    }
    function render(result) {
        active = result;
        byId("result-heading").textContent = result.label;
        byId("suite").value = result.suite;
        const metrics = byId("metrics");
        metrics.replaceChildren();
        for (const [label, value] of [["Precision", result.precision], ["Recall", result.recall], ["F1", result.f1]]) {
            const group = append(metrics, "div");
            append(group, "dt", label);
            append(group, "dd", value.toLocaleString("ru-RU", {minimumFractionDigits: 4}));
        }
        byId("counts").textContent = "Файлов: " + result.cases + " · "
            + Object.entries(result.counts).map(([key, count]) => key + " " + count).join(" · ");
        byId("dataset").href = "/api/dataset?report=" + result.id;
        byId("result").hidden = false;
        renderRows();
    }
    byId("show-tn").addEventListener("change", renderRows);
    byId("testing").addEventListener("submit", (event) => {
        event.preventDefault();
        submit(event.submitter, async () => {
            message("Выполняется тестирование…");
            const result = await api("/api/testing", {suite: byId("suite").value});
            history.replaceState(null, "", "/testing?report=" + result.id);
            render(result);
            message("Результат сохранён в истории.");
        });
    });
    if (params.has("report")) render(await api("/api/test-result?" + params));
}

const pages = {file: projectFilePage, finding: findingPage, quarantine: quarantinePage, "quarantine-file": quarantineFilePage,
    scenarios: scenariosPage, testing: testingPage};
pages[document.body.dataset.page]().catch((error) => message(error.message, true));
