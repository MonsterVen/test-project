"""Reversible changes to the running local catalog."""

import hashlib
import json
import re
import sqlite3
import subprocess
from contextlib import closing
from pathlib import Path

from catalog_db import ROOT, connect
from expert_system import RULES_PATH, evaluate, load_rules
from project_files import safe_path


CARD_NAME = "featured-messaging.json"
CARD = {
    "name": "Discord",
    "disc": "Демонстрационная карточка приложения для общения.",
    "tag": "messaging",
    "place": "https://yandex.ru/games/",
    "img": "discord.svg",
}
CARD_BYTES = (json.dumps(CARD, indent=2, ensure_ascii=False) + "\n").encode()
OPTIONS = {
    "card": ("Подмена ссылки карточки Discord",
             {"source": "static", "type": "card_link_changed", "severity": "high"}),
    "admin": ("Временная смена пароля администратора",
              {"source": "integrity", "type": "admin_password_changed", "severity": "critical"}),
}
ADMIN_SCHEMA = """CREATE TABLE IF NOT EXISTS scenario_admin (
    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
    username TEXT NOT NULL, before_hash TEXT NOT NULL, after_hash TEXT NOT NULL
)"""


def card_relative(project):
    return (ROOT / "public_html" / CARD_NAME).relative_to(project).as_posix()


def local_catalog(project):
    return project in {ROOT, ROOT / "public_html"}


def scenario_options():
    rules = load_rules(RULES_PATH)
    return {key: {"label": label, "risk": evaluate([signal], rules)["risk_score"]}
            for key, (label, signal) in OPTIONS.items()}


def admin_change(connection, data):
    username = data.get("username")
    current = data.get("current_password")
    replacement = data.get("new_password")
    if (not isinstance(username, str) or not re.fullmatch(r"[a-zA-Z0-9_.-]{1,32}", username)
            or not isinstance(current, str) or not 1 <= len(current.encode()) <= 1024
            or not isinstance(replacement, str) or not 12 <= len(replacement.encode()) <= 72
            or "\0" in replacement or replacement == current):
        raise ValueError("Укажите имя, действующий пароль и новый пароль длиной 12–72 байта.")
    row = connection.execute("SELECT password_hash FROM admins WHERE username = ?", (username,)).fetchone()
    if not row:
        raise ValueError("Имя или действующий пароль не совпадают.")
    previous = row[0]
    script = ("$v=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);"
              'if(!password_verify($v["current"],$v["hash"])) {exit(3);}'
              'echo password_hash($v["next"],PASSWORD_DEFAULT);')
    with subprocess.Popen(["php", "-r", script], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, text=True, encoding="utf-8") as process:
        try:
            result, _ = process.communicate(
                json.dumps({"current": current, "hash": previous, "next": replacement}), timeout=8)
        except subprocess.TimeoutExpired as error:
            process.kill()
            process.communicate()
            raise ValueError("PHP не успел проверить пароль.") from error
    if process.returncode == 3:
        raise ValueError("Имя или действующий пароль не совпадают.")
    if process.returncode or not result.startswith("$"):
        raise ValueError("PHP не смог сохранить пароль.")
    connection.execute("INSERT INTO scenario_admin VALUES (1, ?, ?, ?)", (username, previous, result))
    connection.execute("UPDATE admins SET password_hash = ? WHERE username = ?", (result, username))


def active_admin(state):
    with closing(connect(state)) as connection, connection:
        connection.execute(ADMIN_SCHEMA)
        return connection.execute(
            "SELECT 1 FROM scenario_admin s JOIN admins a ON a.username = s.username "
            "WHERE a.password_hash = s.after_hash").fetchone() is not None


def scenario_status(project, state, vault):
    if not local_catalog(project):
        return False
    with closing(connect(state)) as connection, connection:
        connection.execute(ADMIN_SCHEMA)
        pending_admin = connection.execute("SELECT 1 FROM scenario_admin").fetchone() is not None
    return vault.active_card() is not None or pending_admin


def apply(project, state, vault, data):
    selections = data.get("selected")
    if (not local_catalog(project) or not isinstance(selections, list) or not selections
            or len(selections) > len(OPTIONS)
            or any(not isinstance(item, str) or item not in OPTIONS for item in selections)):
        raise ValueError("Выберите сценарии в папке запущенного каталога.")
    if scenario_status(project, state, vault) or vault.scenario_manifest(project):
        raise ValueError("Сначала выполните возврат предыдущего сценария.")
    risk = evaluate([OPTIONS[name][1] for name in set(selections)], load_rules(RULES_PATH))["risk_score"]
    file = None
    with closing(connect(state)) as connection, connection:
        connection.execute(ADMIN_SCHEMA)
        connection.execute("BEGIN IMMEDIATE")
        if "admin" in selections:
            admin_change(connection, data)
        try:
            if "card" in selections:
                relative = card_relative(project)
                candidate = safe_path(project, relative)
                with candidate.open("xb") as stream:
                    file = candidate
                    vault.remember_case(project, relative, CARD_BYTES)
                    stream.write(CARD_BYTES)
            connection.commit()
        except (OSError, sqlite3.Error):
            if file is not None:
                file.unlink(missing_ok=True)
                vault.forget_case(project, relative)
            raise
    return {"changes": len(set(selections)), "risk": risk}


def rollback(project, state, vault):
    if not local_catalog(project):
        raise ValueError("Выберите папку запущенного каталога.")
    removed = 0
    card = vault.active_card()
    if card is not None:
        owner, relative, expected = card
        path = safe_path(owner, relative)
        entry = next((row for row in vault.entries() if local_catalog(Path(row["project"]))
                      and row["path"] == card_relative(Path(row["project"]))
                      and row["digest"] == expected), None)
        if entry:
            source = vault.directory / entry["id"]
        elif path.exists():
            source = path
        else:
            source = None
        if source is not None:
            if source.is_symlink() or source.stat().st_size != len(CARD_BYTES) or source.read_bytes() != CARD_BYTES:
                raise ValueError("Файл карточки изменён после создания. Его содержимое сохранено.")
            source.unlink()
            removed += 1
        if entry:
            vault.forget(entry["id"])
        vault.forget_case(owner, relative)
    with closing(connect(state)) as connection, connection:
        connection.execute(ADMIN_SCHEMA)
        connection.execute("BEGIN IMMEDIATE")
        entry = connection.execute("SELECT username, before_hash, after_hash FROM scenario_admin").fetchone()
        if entry:
            username, previous, applied = entry
            restored = connection.execute(
                "UPDATE admins SET password_hash = ? WHERE username = ? AND password_hash = ?",
                (previous, username, applied)).rowcount
            connection.execute("DELETE FROM scenario_admin")
        else:
            restored = 0
    for candidate in (ROOT, ROOT / "public_html"):
        vault.set_hold(candidate, "admin", False)
    vault.sync_marker()
    return {"changes": removed + restored, "password_changed_again": bool(entry and not restored)}
