"""Local scheduler, persistent audit history and synthetic exercises."""

import argparse
import json
import logging
import os
import sqlite3
import threading
import time
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from audit import MAX_FINDINGS, finding, health, inventory, runtime_events
from catalog_db import DEFAULT_STATE, ROOT
from expert_system import RULES_PATH, evaluate, load_rules
from finding_info import LEVELS, PRESETS, describe
from project_files import Vault, rollback_cases, scenarios


LOG = logging.getLogger("catalog-security")
WEB = Path(__file__).resolve().with_name("web")
AUDITS = {"scheduled", "manual", "configuration"}
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK(id = 1), project TEXT NOT NULL, interval INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
    project TEXT NOT NULL, kind TEXT NOT NULL, report TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS reports_by_project ON reports(project, id DESC) WHERE kind <> 'simulation';
CREATE TABLE IF NOT EXISTS baselines (project TEXT PRIMARY KEY, hashes TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS progress (id INTEGER PRIMARY KEY CHECK(id = 1), event_id INTEGER NOT NULL);
INSERT OR IGNORE INTO progress VALUES (1, 0);
"""


def utc(timestamp=None):
    clock = time.time() if timestamp is None else timestamp
    return datetime.fromtimestamp(clock, timezone.utc).isoformat(timespec="seconds")


class Store:
    def __init__(self, state):
        state.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = state / "monitor.sqlite3"
        with self.open() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(SCHEMA)
            db.execute("INSERT OR IGNORE INTO settings VALUES (1, ?, 60)", (str(ROOT),))

    @contextmanager
    def open(self):
        with closing(sqlite3.connect(self.path, timeout=5)) as db, db:
            db.row_factory = sqlite3.Row
            yield db

    def settings(self):
        with self.open() as db:
            return dict(db.execute("SELECT project, interval FROM settings").fetchone())

    def configure(self, project, interval):
        with self.open() as db:
            db.execute("UPDATE settings SET project = ?, interval = ?", (str(project), interval))

    def previous(self, project):
        with self.open() as db:
            row = db.execute("SELECT hashes FROM baselines WHERE project = ?", (str(project),)).fetchone()
            cursor = db.execute("SELECT event_id FROM progress").fetchone()[0]
            previous = json.loads(row[0]) if row else {}
            return previous.get("files") if previous.get("format") == 2 else None, cursor

    def save(self, project, kind, report, hashes=None, cursor=None):
        with self.open() as db:
            row = db.execute("INSERT INTO reports(created_at, project, kind, report) VALUES (?, ?, ?, ?)",
                             (utc(), str(project), kind, json.dumps(report)))
            if hashes is not None:
                db.execute("INSERT INTO baselines VALUES (?, ?) ON CONFLICT(project) DO UPDATE SET hashes=excluded.hashes",
                           (str(project), json.dumps({"format": 2, "files": hashes})))
            if cursor is not None:
                db.execute("UPDATE progress SET event_id = ? WHERE id = 1", (cursor,))
            return row.lastrowid

    def history(self, before=None):
        query = "SELECT * FROM reports"
        args = ()
        if before is not None:
            query += " WHERE id < ?"
            args = (before,)
        with self.open() as db:
            rows = db.execute(query + " ORDER BY id DESC LIMIT 25", args).fetchall()
        return [public_report(self.decode(row)) for row in rows]

    @staticmethod
    def decode(row):
        return {"id": row["id"], "created_at": row["created_at"], "project": row["project"],
                "kind": row["kind"], **json.loads(row["report"])}

    def report(self, identifier):
        with self.open() as db:
            row = db.execute("SELECT * FROM reports WHERE id = ?", (identifier,)).fetchone()
        if row is None:
            raise ValueError("Проверка не найдена.")
        return self.decode(row)

    def last_audit(self, project):
        with self.open() as db:
            row = db.execute("SELECT created_at, report FROM reports WHERE project = ? "
                             "AND kind IN ('scheduled', 'manual', 'configuration') "
                             "ORDER BY id DESC LIMIT 1", (project,)).fetchone()
        if row is None:
            return None
        report = json.loads(row["report"])
        return {"created_at": row["created_at"], "health": report["health"], "error": report["error"]}


def validate(value, interval):
    if not isinstance(value, str) or not value.strip() or len(value) > 4096:
        raise ValueError("Укажите путь к папке проекта.")
    if type(interval) is not int or not 5 <= interval <= 86400:
        raise ValueError("Интервал должен быть целым числом от 5 до 86400 секунд.")
    try:
        path = Path(value).expanduser().resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise ValueError("Папка проекта недоступна.") from error
    if not path.is_dir() or path == path.parent:
        raise ValueError("Укажите папку проекта.")
    return path, interval


def directory_choices(value):
    base = Path(value).expanduser().resolve(strict=True)
    if not base.is_dir():
        raise ValueError("Укажите папку проекта.")
    folders = []
    with os.scandir(base) as entries:
        for item in entries:
            if not item.name.startswith(".") and item.is_dir(follow_symlinks=False):
                folders.append(item.name)
                if len(folders) == 200:
                    break
    return {"folder": str(base), "parent": str(base.parent) if base != base.parent else None,
            "children": [{"name": name, "path": str(base / name)} for name in sorted(folders)]}


def report_for(findings, *, files=None, site=None, error=None):
    sorted_findings = sorted(findings, key=lambda item: {
        "critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4,
    }[item["severity"]])
    shown = sorted_findings[:MAX_FINDINGS]
    incident = evaluate(sorted_findings, load_rules(RULES_PATH))
    incident["triggering_findings"] = [
        {**entry, "finding_indices": [index for index in entry["finding_indices"] if index < MAX_FINDINGS]}
        for entry in incident["triggering_findings"]
    ]
    candidates = {item["path"]: item["digest"] for item in sorted_findings if actionable(item)}
    return {"inventory": files, "health": site, "findings": shown, "finding_count": len(findings),
            "incident": incident, "error": error, "targets": candidates}


def actionable(item):
    return bool(item.get("digest") and item["path"] and item["source"] in {"static", "scenario"}
                and not item["path"].startswith("catalog_security/"))


def public_report(report):
    result = {key: value for key, value in report.items() if key != "targets"}
    result["target_count"] = len(report.get("targets", {}))
    findings = report["findings"]
    if report["kind"] == "simulation":
        old_codes = {"sql_injection": "dynamic_sql", "xss": "dynamic_html", "xxe": "xml_external_definition",
                     "access_control": "review_access_control"}
        findings = [{**item, "type": old_codes.get(item["type"], item["type"]), "source": "scenario",
                     "description": "Сохранённый контрольный сигнал."} for item in findings]
    result["findings"] = [
        {key: value for key, value in item.items() if key != "digest"}
        | {"isolate": actionable(item), **describe(item)}
        for item in findings
    ]
    if "testing" in report:
        result["testing"] = {key: value for key, value in report["testing"].items() if key != "rows"}
    return result


def record_test(store, suite):
    from evaluate_detection import evaluate_suite

    result = evaluate_suite(suite)
    report = report_for([])
    report["testing"] = result
    return store.save(store.settings()["project"], "testing", report), result


def number(value):
    if isinstance(value, str) and value.isascii() and value.isdecimal() and len(value) <= 18:
        value = int(value)
    if type(value) is not int or not 0 <= value < 10**18:
        raise ValueError("Некорректный номер записи.")
    return value


def selected_finding(report, index):
    if index >= len(report["findings"]):
        raise ValueError("Находка не найдена.")
    return report["findings"][index]


class Monitor:
    def __init__(self, state, port, store):
        self.state = state
        self.site_port = port
        self.store = store
        self.lock = threading.Condition()
        self.files_lock = threading.Lock()
        self.vault = Vault(state, store)
        self.pending = None
        self.running = False
        self.deadline = time.monotonic()

    def status(self):
        with self.lock:
            settings = self.store.settings()
            next_check = None if self.running else utc(time.time() + max(0, self.deadline - time.monotonic()))
            return {**settings, "running": self.running, "queued": bool(self.pending),
                    "next_check": next_check, "site_port": self.site_port,
                    "maintenance": self.vault.marker.is_file(),
                    "last_audit": self.store.last_audit(settings["project"])}

    def update(self, value, interval):
        project, interval = validate(value, interval)
        with self.files_lock, self.lock:
            self.store.configure(project, interval)
            self.pending = "configuration"
            self.lock.notify()

    def request(self):
        with self.lock:
            self.pending = "manual"
            self.lock.notify()

    def work(self):
        while True:
            with self.lock:
                while not self.pending and self.deadline > time.monotonic():
                    self.lock.wait(self.deadline - time.monotonic())
                kind = self.pending or "scheduled"
                self.pending = None
                self.running = True
                project = Path(self.store.settings()["project"])
            try:
                with self.files_lock:
                    self.scan(project, kind)
            except Exception:
                LOG.exception("Audit failed")
                try:
                    self.store.save(project, kind, report_for([], error="Проверка не завершилась. Подробности в журнале запуска."))
                except Exception:
                    LOG.exception("Unable to record failed audit")
            finally:
                with self.lock:
                    self.deadline = time.monotonic() + self.store.settings()["interval"]
                    self.running = False

    def scenarios(self, data, rollback=False):
        with self.files_lock:
            project = Path(self.store.settings()["project"])
            if data.get("project") != str(project):
                raise ValueError("Активная папка изменилась. Откройте страницу заново.")
            if project.resolve(strict=True) != project or not project.is_dir():
                raise ValueError("Папка проекта была перемещена.")
            if rollback:
                return rollback_cases(project, self.vault)
            return scenarios(project, data.get("selected"), data.get("level"), self.vault)

    def isolate(self, data, bulk):
        with self.files_lock:
            report = self.store.report(number(data.get("report")))
            project = Path(self.store.settings()["project"])
            if report["project"] != str(project) or report["kind"] not in AUDITS:
                raise ValueError("Выберите находку из аудита текущей папки.")
            if bulk:
                if report["incident"]["risk_score"] < 8:
                    raise ValueError("Массовая изоляция доступна при риске от 8/10.")
                active = {(row["path"], row["digest"]) for row in self.vault.entries(project)}
                items = [{"path": path, "digest": digest} for path, digest in report.get("targets", {}).items()
                         if (path, digest) not in active]
            else:
                item = selected_finding(report, number(data.get("index")))
                items = [item] if actionable(item) else []
            if not items:
                raise ValueError("В этой проверке нет файлов для изоляции.")
            return self.vault.quarantine(project, items, bulk=bulk)

    def restore(self, identifier):
        with self.files_lock:
            row = next((row for row in self.vault.entries() if row["id"] == identifier), None)
            if row is None:
                raise ValueError("Запись карантина не найдена.")
            self.vault.restore(row)

    def scan(self, project, kind):
        if not project.is_dir():
            raise FileNotFoundError("Selected project is no longer available")
        files, findings, hashes = inventory(project, excluded=self.state)
        previous, cursor = self.store.previous(project)
        baseline = None
        if files["limited"] or files["skipped"]:
            findings.append(finding("static", "incomplete_inventory", "info",
                                    "Некоторые файлы пропущены из-за ограничений или ошибок чтения."))
        if not (files["limited"] or files["inaccessible"]):
            baseline = hashes
        if previous is not None:
            differences = [(name, "source_changed", "Изменилось содержимое или метаданные файла.")
                           for name, digest in hashes.items() if name in previous and previous[name] != digest]
            if baseline is not None:
                differences += [(name, "source_added", "Обнаружен новый файл.") for name in sorted(hashes.keys() - previous.keys())]
                isolated = {row["path"] for row in self.vault.entries(project)}
                differences += [(name, "source_removed", "Файл исчез из инвентаризации.")
                                for name in sorted(previous.keys() - hashes.keys() - isolated)]
            findings.extend(finding("integrity", code, "medium", message, name)
                            for name, code, message in differences)
        status = {"status": "not_applicable"}
        new_cursor = None
        if project in {ROOT, ROOT / "public_html"}:
            status, issues = health(self.site_port)
            findings.extend(issues)
            try:
                events, new_cursor = runtime_events(self.state, cursor)
                findings.extend(events)
            except sqlite3.Error:
                LOG.exception("Runtime log unavailable")
                findings.append(finding("runtime", "unavailable", "medium", "Журнал приложения недоступен."))
        self.store.save(project, kind, report_for(findings, files=files, site=status), baseline, new_cursor)


class Handler(BaseHTTPRequestHandler):
    server_version = "CatalogMonitor/1"
    timeout = 8
    routes = {"/": ("index.html", "text/html"), "/style.css": ("style.css", "text/css"),
              "/app.js": ("app.js", "text/javascript"), "/common.js": ("common.js", "text/javascript"),
              "/finding": ("finding.html", "text/html"), "/quarantine": ("quarantine.html", "text/html"),
              "/scenarios": ("scenarios.html", "text/html"), "/testing": ("testing.html", "text/html"),
              "/tools.js": ("tools.js", "text/javascript")}

    def reply(self, body, content_type, status=200, *, attachment=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers()
        self.wfile.write(body)

    def json(self, body, status=200):
        self.reply(json.dumps(body).encode(), "application/json", status)

    def local(self):
        allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        if self.headers.get("Host") not in allowed:
            self.json({"error": "Откройте интерфейс на 127.0.0.1."}, 403)
            return False
        return True

    def do_GET(self):
        if not self.local():
            return
        try:
            path = urlsplit(self.path)
            monitor = self.server.monitor
            query = {key: values[0] for key, values in parse_qs(path.query).items()}
            if path.path in self.routes:
                name, content_type = self.routes[path.path]
                self.reply((WEB / name).read_bytes(), content_type)
            elif path.path == "/api/status":
                self.json(monitor.status())
            elif path.path == "/api/history":
                self.json(monitor.store.history(number(query["before"]) if "before" in query else None))
            elif path.path == "/api/finding":
                report = monitor.store.report(number(query.get("report")))
                index = number(query.get("index"))
                item = selected_finding(public_report(report), index)
                self.json({"finding": item, "project": report["project"], "report": report["id"],
                           "index": index, "created_at": report["created_at"]})
            elif path.path == "/api/quarantine":
                self.json({"files": [{key: value for key, value in row.items() if key != "digest"}
                                     for row in monitor.vault.entries()],
                           "maintenance": monitor.vault.marker.is_file()})
            elif path.path == "/api/scenarios":
                project = Path(monitor.store.settings()["project"])
                with monitor.files_lock:
                    active = bool(monitor.vault.scenario_manifest(project))
                    self.json({"project": str(project), "active": active,
                               "choices": {key: label for key, (_, label) in PRESETS.items()}, "levels": LEVELS})
            elif path.path in {"/api/test-result", "/api/dataset"}:
                identifier = number(query.get("report"))
                report = monitor.store.report(identifier)
                if "testing" not in report:
                    raise ValueError("Для этой записи нет датасета.")
                if path.path == "/api/test-result":
                    self.json({"id": identifier, **report["testing"]})
                else:
                    from evaluate_detection import dataset_csv
                    body = dataset_csv(report["testing"]).encode("utf-8-sig")
                    self.reply(body, "text/csv", attachment=f"detection-{identifier}.csv")
            else:
                self.json({"error": "Страница не найдена."}, 404)
        except ValueError as error:
            self.json({"error": str(error)}, 400)
        except (OSError, sqlite3.Error):
            LOG.exception("Interface request failed")
            self.json({"error": "Не удалось получить данные."}, 500)

    def do_POST(self):
        if not self.local():
            return
        expected = "http://" + self.headers["Host"]
        if (self.headers.get("X-Catalog-Action") != "1"
                or self.headers.get("Origin", expected) != expected):
            self.json({"error": "Запрос не принадлежит интерфейсу."}, 403)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 <= size <= 8192:
                raise ValueError("Слишком большой запрос.")
            data = json.loads(self.rfile.read(size)) if size else {}
            if not isinstance(data, dict):
                raise ValueError("Ожидается объект JSON.")
            monitor = self.server.monitor
            if self.path == "/api/directories":
                path = data.get("path")
                if not isinstance(path, str) or not path or len(path) > 4096:
                    raise ValueError("Укажите путь к папке.")
                self.json(directory_choices(path))
            elif self.path == "/api/check":
                monitor.request()
                self.json({"accepted": True}, 202)
            elif self.path == "/api/settings":
                monitor.update(data.get("project"), data.get("interval"))
                self.json({"accepted": True}, 202)
            elif self.path in {"/api/scenarios/create", "/api/scenarios/rollback"}:
                self.json({"files": monitor.scenarios(data, self.path.endswith("/rollback"))})
            elif self.path in {"/api/quarantine/add", "/api/quarantine/bulk"}:
                self.json({"files": monitor.isolate(data, self.path.endswith("/bulk"))})
            elif self.path == "/api/quarantine/restore":
                monitor.restore(data.get("id"))
                self.json({"restored": True})
            elif self.path == "/api/testing":
                identifier, result = record_test(monitor.store, data.get("suite"))
                self.json({"id": identifier, **result})
            else:
                self.json({"error": "Страница не найдена."}, 404)
        except (ValueError, RecursionError) as error:
            self.json({"error": str(error)}, 400)
        except (OSError, RuntimeError, sqlite3.Error):
            LOG.exception("Action failed")
            self.json({"error": "Операция с файлом или данными не завершилась. Проверьте права и путь."}, 400)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    serve = commands.add_parser("serve")
    serve.add_argument("--site-port", type=int, default=8000)
    serve.add_argument("--port", type=int, default=8081)
    serve.add_argument("--project")
    serve.add_argument("--interval", type=int)
    args = parser.parse_args()
    os.umask(0o077)
    logging.basicConfig(level=logging.INFO)
    state = Path(os.environ.get("CATALOG_STATE", DEFAULT_STATE)).expanduser().resolve()
    store = Store(state)
    try:
        import fcntl

        with (state / "monitor.lock").open("a") as lockfile:
            try:
                fcntl.flock(lockfile, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise ValueError("Для этого каталога данных монитор уже запущен.") from error
            serve_forever(args, state, store)
    except (OSError, ValueError, sqlite3.Error) as error:
        parser.exit(2, f"{error}\n")
    except KeyboardInterrupt:
        return


def serve_forever(args, state, store):
    settings = store.settings()
    if args.project is not None or args.interval is not None:
        project = args.project if args.project is not None else settings["project"]
        interval = args.interval if args.interval is not None else settings["interval"]
        store.configure(*validate(project, interval))
    monitor = Monitor(state, args.site_port, store)
    with ThreadingHTTPServer(("127.0.0.1", args.port), Handler) as server:
        server.monitor = monitor
        threading.Thread(target=monitor.work, daemon=True).start()
        print(f"История проверок: http://127.0.0.1:{args.port}/", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
