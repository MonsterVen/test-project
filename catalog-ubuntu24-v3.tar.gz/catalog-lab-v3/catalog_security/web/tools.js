"use strict";

const feedback = byId("feedback");
const params = new URLSearchParams(location.search);

function message(text, problem = false) {
    feedback.textContent = text;
    feedback.className = problem ? "problem" : "good";
}

async function submit(button, task) {
    button.disabled = true;
    try {
        await task();
    } catch (error) {
        message(error.message, true);
    } finally {
        button.disabled = false;
    }
}

async function findingPage() {
    const result = await api("/api/finding?" + params);
    const item = result.finding;
    byId("title").textContent = levels[item.severity] + " — " + item.title;
    const where = byId("where");
    where.textContent = item.path ? "Местоположение " : "";
    append(where, "code", locationLabel(item));
    byId("root").textContent = result.project;
    byId("what").textContent = item.explanation;
    if (item.cwe) {
        const cwe = byId("cwe");
        const reference = append(cwe, "a", item.cwe);
        reference.href = "https://cwe.mitre.org/data/definitions/" + item.cwe.slice(4) + ".html";
        reference.target = "_blank";
        reference.rel = "noopener noreferrer";
        cwe.hidden = false;
    }
    if (item.remediation) {
        byId("fix").textContent = item.remediation;
        byId("fix-panel").hidden = false;
    }
    byId("finding").hidden = false;
    const isolate = byId("isolate");
    isolate.hidden = !item.isolate;
    isolate.addEventListener("click", () => submit(isolate, async () => {
        await api("/api/quarantine/add", {report: result.report, index: result.index});
        isolate.hidden = true;
        message("Файл перемещён в карантин.");
    }));
}

async function quarantinePage() {
    const fresh = await api("/api/quarantine");
    byId("maintenance").hidden = !fresh.maintenance;
    const list = byId("files");
    list.replaceChildren();
    const empty = byId("empty");
    empty.textContent = "В карантине пока нет файлов.";
    empty.hidden = fresh.files.length > 0;
    for (const item of fresh.files) {
        const row = append(list, "article");
        row.className = "panel";
        append(append(row, "h2"), "code", item.path);
        append(row, "p", item.project);
        const button = append(row, "button", "Восстановить файл");
        button.type = "button";
        button.addEventListener("click", () => submit(button, async () => {
            await api("/api/quarantine/restore", {id: item.id});
            await quarantinePage();
            message("Файл возвращён на исходное место.");
        }));
    }
}

async function scenariosPage() {
    const data = await api("/api/scenarios");
    byId("root").textContent = data.project;
    const choices = byId("choices");
    for (const [value, title] of Object.entries(data.choices)) {
        const label = append(choices, "label");
        const checkbox = append(label, "input");
        checkbox.type = "checkbox";
        checkbox.name = "selected";
        checkbox.value = value;
        append(label, "span", title);
    }
    const level = byId("level");
    for (const [value, risk] of Object.entries(data.levels)) {
        append(level, "option", levels[value] + " · " + risk + "/10").value = value;
    }
    level.value = "high";
    const form = byId("scenario");
    const create = byId("create");
    const rollback = byId("rollback");
    function showActive(active) {
        choices.disabled = active;
        level.disabled = active;
        create.disabled = active;
        rollback.disabled = !active;
    }
    showActive(data.active);
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        const selected = new FormData(form).getAll("selected");
        if (!selected.length) {
            message("Выберите хотя бы одну категорию.", true);
            return;
        }
        submit(create, async () => {
            const result = await api("/api/scenarios/create", {selected, level: level.value, project: data.project});
            showActive(true);
            message("Создано файлов: " + result.files + ". Проверка не запущена.");
        }).then(() => { create.disabled = choices.disabled; });
    });
    rollback.addEventListener("click", () => {
        submit(rollback, async () => {
            const result = await api("/api/scenarios/rollback", {project: data.project});
            showActive(false);
            message("Убрано контрольных файлов: " + result.files + ".");
        }).then(() => { rollback.disabled = !choices.disabled; });
    });
}

async function testingPage() {
    let active;
    const table = byId("results");
    function renderRows() {
        table.replaceChildren();
        if (!active) return;
        const showClean = byId("show-tn").checked;
        for (const item of active.rows) {
            if (item.outcome === "TN" && !showClean) continue;
            const row = append(table, "tr");
            for (const value of [item.file, item.rule, item.actual ? "Да" : "Нет", item.predicted ? "Да" : "Нет",
                item.outcome, item.lines || "—", item.case]) append(row, "td", value);
        }
    }
    function render(result) {
        active = result;
        byId("result-heading").textContent = result.label;
        byId("suite").value = result.suite;
        const metrics = byId("metrics");
        metrics.replaceChildren();
        for (const [label, value] of [["Precision", result.precision], ["Recall", result.recall], ["F1", result.f1]]) {
            const group = append(metrics, "div");
            append(group, "dt", label);
            append(group, "dd", value.toLocaleString("ru-RU", {minimumFractionDigits: 4}));
        }
        byId("counts").textContent = "Файлов: " + result.cases + " · "
            + Object.entries(result.counts).map(([key, count]) => key + " " + count).join(" · ");
        byId("dataset").href = "/api/dataset?report=" + result.id;
        byId("result").hidden = false;
        renderRows();
    }
    byId("show-tn").addEventListener("change", renderRows);
    byId("testing").addEventListener("submit", (event) => {
        event.preventDefault();
        submit(event.submitter, async () => {
            message("Выполняется тестирование…");
            const result = await api("/api/testing", {suite: byId("suite").value});
            history.replaceState(null, "", "/testing?report=" + result.id);
            render(result);
            message("Результат сохранён в истории.");
        });
    });
    if (params.has("report")) render(await api("/api/test-result?" + params));
}

const pages = {finding: findingPage, quarantine: quarantinePage, scenarios: scenariosPage, testing: testingPage};
pages[document.body.dataset.page]().catch((error) => message(error.message, true));
