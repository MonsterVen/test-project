"use strict";

const form = byId("settings");
const project = byId("project");
const interval = byId("interval");
const history = byId("history");
const feedback = byId("feedback");
const older = byId("older");
let entries = new Map();
let before;
let edited = false;
let polling = false;

const kinds = {scheduled: "По расписанию", manual: "Вручную", configuration: "После смены настроек",
    simulation: "Контрольная запись", testing: "Тестирование"};
const sources = {static: "Код", integrity: "Целостность", runtime: "Журнал",
    health: "Доступность", simulation: "Контрольная запись", scenario: "Контрольный файл"};

function makeEntry(entry) {
    const details = document.createElement("details");
    details.dataset.id = entry.id;
    details.id = "report-" + entry.id;
    const changes = entry.file_changes;
    const changed = changes && Object.values(changes).some(paths => paths.length);
    const changeText = changes && "Изменение файлов · добавлено " + changes.added.length
        + " · изменено " + changes.changed.length + " · удалено " + changes.removed.length;
    const down = entry.auto_quarantine || ["down", "maintenance"].includes(entry.health?.status);
    const summary = append(details, "summary");
    append(summary, "time", time(entry.created_at)).dateTime = entry.created_at;
    append(summary, "span", kinds[entry.kind] || entry.kind);
    if (entry.testing) append(summary, "span", " · F1 " + entry.testing.f1);
    else if (entry.error) append(summary, "span", " · Ошибка").className = "problem";
    else if (entry.monitoring && !entry.finding_count) {
        append(summary, "span", down ? " · Web ресурс не работает" : changed ? "" : " · Проверка состояния");
    } else {
        const status = entry.incident.detected ? "Требуется проверка" : "Риск ниже порога";
        const message = entry.finding_count ? status + " · Находок: " + entry.finding_count : "Сигналов нет";
        append(summary, "span", " · " + message).className = entry.incident.detected ? "problem" : "good";
    }

    if (changed) append(summary, "span", " · " + changeText);
    const detail = append(details, "div");
    detail.className = "detail";
    if (entry.testing) {
        append(detail, "p", entry.testing.label + " · Precision " + entry.testing.precision
            + " · Recall " + entry.testing.recall + " · F1 " + entry.testing.f1);
        append(detail, "a", "Открыть результаты и датасет").href = "/testing?report=" + entry.id;
        return details;
    }
    append(detail, "p", entry.project);
    if (entry.error) {
        append(detail, "p", entry.error);
        return details;
    }
    if (entry.health && entry.health.status !== "not_applicable") {
        append(detail, "p", "Статус: " + (down ? "Не работает" : "Работает")
            + (entry.health.http ? " · HTTP " + entry.health.http : ""));
    }
    if (changed) {
        for (const [key, title] of [["added", "Добавлено"], ["changed", "Изменено"], ["removed", "Удалено"]]) {
            if (!changes[key].length) continue;
            const group = append(detail, "details");
            append(group, "summary", title + " · " + changes[key].length);
            const list = append(group, "ul");
            for (const path of changes[key]) append(list, "li", path);
        }
    }
    if ((entry.monitoring || changed) && !entry.finding_count) return details;
    append(detail, "p", "Риск " + entry.incident.risk_score + "/10 · Правила " + entry.incident.rules_version);
    if (entry.incident.cvss_max != null) {
        append(detail, "p", "Максимум CVSS 3.1 по сценариям · " + entry.incident.cvss_max.toFixed(1) + "/10");
    }
    if (entry.auto_quarantine) {
        const status = append(detail, "p", "Автоматический карантин · Изолировано файлов: " + entry.auto_quarantine.files + ". ");
        append(status, "a", "Открыть карантин").href = "/quarantine";
        if (entry.auto_quarantine.pending) append(detail, "p", "Часть находок требует ручной проверки.");
    }
    if (entry.inventory) {
        const files = entry.inventory;
        const inventory = append(detail, "details");
        append(inventory, "summary", "Найденные файлы · " + files.scanned + " проверено, " + files.skipped + " пропущено");
        const counts = Object.entries(files.counts).map(([type, count]) => type + " (" + count + ")");
        append(inventory, "p", counts.join(", ") || "Подходящих файлов нет.");
        append(inventory, "p", "Корневая папка сайта: " + (files.web_root ?? "не определён"));
        if (files.examples.length) {
            const list = append(inventory, "ul");
            for (const name of files.examples) append(append(list, "li"), "code", name);
        }
    }
    if (entry.findings.length) {
        append(detail, "h3", "Находки");
        const cards = append(detail, "div");
        cards.className = "finding-list";
        for (const [index, item] of entry.findings.entries()) {
            const card = append(cards, "article");
            card.className = "finding-card " + item.severity;
            const row = append(card, "h3");
            append(row, "span", levels[item.severity] + " — ");
            append(row, "a", item.title).href = "/finding?report=" + entry.id + "&index=" + index;
            const meta = append(card, "p", (sources[item.source] || "Аудит") + " · ");
            append(meta, "code", locationLabel(item));
            if (item.cvss) append(meta, "span", " · CVSS 3.1 " + item.cvss.risk.toFixed(1));
        }
        if (entry.finding_count > entry.findings.length) {
            append(detail, "p", "Показаны первые " + entry.findings.length + " находок.");
        }
    }
    if (entry.incident.risk_score >= 8 && entry.target_count && !entry.auto_quarantine) {
        const controls = append(detail, "div");
        controls.className = "controls";
        const button = append(controls, "button", "Изолировать все файлы");
        button.className = "danger-button";
        button.type = "button";
        const message = append(controls, "p");
        message.setAttribute("role", "status");
        button.addEventListener("click", async () => {
            if (!window.confirm("Перенести файлы с находками в карантин? Для Web ресурса включится режим обслуживания.")) return;
            button.disabled = true;
            try {
                const result = await api("/api/quarantine/bulk", {report: entry.id});
                message.textContent = "Изолировано файлов: " + result.files + ". ";
                append(message, "a", "Открыть карантин").href = "/quarantine";
                await refresh();
            } catch (error) {
                message.className = "problem";
                message.textContent = error.message;
                button.disabled = false;
            }
        });
    }
    if (entry.incident.recommendations.length) {
        append(detail, "h3", "Рекомендации");
        const list = append(detail, "ul");
        for (const recommendation of entry.incident.recommendations) append(list, "li", recommendation);
    }
    return details;
}

function merge(rows) {
    for (const entry of rows) {
        const previous = entries.get(entry.id);
        if (!previous || Boolean(previous.entry.auto_quarantine) !== Boolean(entry.auto_quarantine)) {
            const node = makeEntry(entry);
            if (previous) {
                node.open = previous.node.open;
                previous.node.replaceWith(node);
            }
            entries.set(entry.id, {entry, node});
        }
    }
    const ordered = [...entries.values()].sort((a, b) => b.entry.id - a.entry.id);
    let pointer = history.firstElementChild;
    for (const {node} of ordered) {
        if (node === pointer) pointer = pointer.nextElementSibling;
        else history.insertBefore(node, pointer);
    }
    byId("empty").hidden = ordered.length > 0;
    drawAvailability();
}

let graphKey;
function drawAvailability() {
    const samples = [...entries.values()].filter(({entry}) =>
        ["ok", "down", "maintenance"].includes(entry.health?.status))
        .sort((a, b) => a.entry.id - b.entry.id);
    const key = samples.map(({entry}) => entry.id + "/" + Boolean(entry.auto_quarantine)).join(",");
    if (key === graphKey) return;
    graphKey = key;
    const box = byId("availability");
    box.replaceChildren();
    if (!samples.length) {
        append(box, "p", "Пока нет проверок доступности.");
        return;
    }
    function svg(parent, tag, attrs, text) {
        const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
        for (const [name, value] of Object.entries(attrs)) el.setAttribute(name, value);
        if (text) el.textContent = text;
        parent.append(el);
        return el;
    }
    const width = Math.max(610, 190 + samples.length * 28);
    const chart = svg(box, "svg", {width, height: 134, "aria-label": "Доступность Web ресурса по проверкам"});
    const left = 113, right = width - 25;
    for (const [label, y] of [["Работает", 30], ["Не работает", 77]]) {
        svg(chart, "text", {x: 4, y: y + 4}, label);
        svg(chart, "line", {x1: left, x2: right, y1: y, y2: y, stroke: "#c9d7d8"});
    }
    let line = "";
    const points = samples.map(({entry, node}, i) => {
        const down = entry.health.status !== "ok" || Boolean(entry.auto_quarantine);
        const x = left + i * (right - left) / Math.max(1, samples.length - 1);
        const y = down ? 77 : 30;
        line += i ? " H" + x + " V" + y : "M" + x + " " + y;
        return {entry, node, down, x, y};
    });
    svg(chart, "path", {d: line, fill: "none", stroke: "#668781", "stroke-width": 2});
    for (const [i, {entry, node, down, x, y}] of points.entries()) {
        const stamp = time(entry.created_at);
        const label = stamp + " · " + (down ? "Не работает" : "Работает") + " · Отчёт №" + entry.id;
        const link = svg(chart, "a", {href: "#" + node.id, "aria-label": label});
        svg(link, "title", {}, label);
        svg(link, "circle", {cx: x, cy: y, r: 12, fill: "transparent"});
        svg(link, "circle", {cx: x, cy: y, r: 6, fill: down ? "#a5242c" : "#08605b"});
        link.addEventListener("click", () => { node.open = true; node.querySelector("summary").focus(); });
        if (i === 0 || i === points.length - 1 || (i % 6 === 0 && i < points.length - 4)) {
            svg(chart, "text", {x, y: 110, "text-anchor": i === 0 ? "start" : "end"}, stamp);
        }
    }
    box.scrollLeft = box.scrollWidth;
}

function renderStatus(status) {
    if (!edited) {
        project.value = status.project;
        interval.value = status.interval;
    }
    const site = byId("open-site");
    site.href = "http://127.0.0.1:" + status.site_port + "/";
    site.hidden = false;

    const latest = status.last_audit;
    const health = byId("health");
    const current = latest?.health;
    health.textContent = status.maintenance ? "Не работает" : latest?.error ? "Ошибка проверки" : current?.status === "ok" ? "Работает"
        : ["down", "maintenance"].includes(current?.status) ? "Не работает"
        : current?.status === "not_applicable" ? "Для папки аудит файлов" : "Ожидает проверки";
    health.className = status.maintenance || ["down", "maintenance"].includes(current?.status) || latest?.error ? "problem"
        : current?.status === "ok" ? "good" : "";
    byId("last").textContent = latest ? time(latest.created_at) : "—";
    byId("next").textContent = status.running ? "Выполняется" : status.queued ? "В очереди" : time(status.next_check);
}

async function refresh() {
    if (polling) return;
    polling = true;
    try {
        const [status, rows] = await Promise.all([api("/api/status"), api("/api/history")]);
        if (typeof before === "undefined") {
            before = rows.length === 25 ? rows.at(-1).id : null;
            older.hidden = before === null;
        }
        merge(rows);
        renderStatus(status);
    } catch (error) {
        byId("health").textContent = "Панель недоступна";
        byId("health").className = "problem";
    } finally {
        polling = false;
    }
}

async function action(button, route, data, message) {
    button.disabled = true;
    feedback.className = "";
    try {
        await api(route, data);
        if (route === "/api/settings") edited = false;
        feedback.textContent = message;
        await refresh();
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        button.disabled = false;
    }
}

form.addEventListener("input", () => { edited = true; });
form.addEventListener("submit", (event) => {
    event.preventDefault();
    action(event.submitter, "/api/settings", {project: project.value, interval: interval.valueAsNumber},
        "Настройки сохранены. Проверка поставлена в очередь.");
});
byId("check").addEventListener("click", (event) => {
    action(event.currentTarget, "/api/check", {}, "Запрошена проверка.");
});
let browsing;
async function openFolder(path) {
    try {
        browsing = await api("/api/directories", {path});
        byId("folder-browser").hidden = false;
        byId("browser-path").textContent = browsing.folder;
        byId("parent-folder").disabled = browsing.parent === null;
        const children = byId("subfolders");
        children.replaceChildren();
        for (const folder of browsing.children) {
            const button = append(append(children, "li"), "button", folder.name);
            button.className = "secondary";
            button.addEventListener("click", () => openFolder(folder.path));
        }
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    }
}
byId("browse").addEventListener("click", () => openFolder(project.value.trim() || "."));
byId("parent-folder").addEventListener("click", () => openFolder(browsing.parent));
byId("close-browser").addEventListener("click", () => { byId("folder-browser").hidden = true; });
byId("use-folder").addEventListener("click", () => {
    project.value = browsing.folder;
    edited = true;
    byId("folder-browser").hidden = true;
    project.focus();
});
older.addEventListener("click", async () => {
    older.disabled = true;
    try {
        const rows = await api("/api/history?before=" + before);
        merge(rows);
        before = rows.length === 25 ? rows.at(-1).id : null;
        older.hidden = before === null;
    } catch (error) {
        feedback.className = "problem";
        feedback.textContent = error.message;
    } finally {
        older.disabled = false;
    }
});

refresh();
setInterval(refresh, 3000);
