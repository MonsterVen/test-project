"""Read-only source inventory and checks for a locally selected project."""

import hashlib
import http.client
import json
import os
import re
import sqlite3
import stat
from contextlib import closing
from pathlib import Path

from finding_info import PRESETS
from live_scenarios import CARD_NAME
from cvss import OPTIONS
from project_files import CASE_DIR, CASE_EXTENSION, case_origin

IGNORED = {".git", ".svn", ".catalog-state", "node_modules", "vendor", "font-awesome",
           "build", "dist", "__pycache__", "practica4"}
EXTENSIONS = {".php", ".phtml", ".js", ".ts", ".html", ".xml", ".xsl", ".xslt",
              ".sql", ".ini", ".conf", ".cfg", ".env", ".json", ".yaml", ".yml",
              ".toml", ".py", ".sh", ".txt"}
MAX_FILES = 1200
MAX_FILE_BYTES = 1 << 20
MAX_TOTAL_BYTES = 24 << 20
MAX_FINDINGS = 80
BENCHMARK = Path(__file__).resolve().with_name("evaluate_detection.py")

EVENTS = {
    "auth_failed": ("info", "Сервер зарегистрировал неудачный вход."),
    "auth_required": ("low", "Доступ к операции администратора без сессии отклонён."),
    "csrf_rejected": ("medium", "Запрос отклонён при проверке CSRF."),
    "unsupported_media": ("low", "Обработчик формы отклонил неподдерживаемый тип данных."),
    "invalid_card": ("info", "Приложение отклонило карточку при проверке полей."),
}

SIGNATURES = (
    ((".js", ".ts", ".html", ".php"), "dynamic_html", "high",
     r"insertAdjacentHTML\s*\([^,]+,\s*(?:[a-z_$]|\x60)|\.innerHTML\s*=\s*(?:[a-z_$]|\x60)",
     "Динамическая вставка HTML. Проверьте происхождение данных и используйте textContent для текста."),
    ((".php", ".phtml"), "dynamic_sql", "high",
     r'(?i)"\s*(?:SELECT|UPDATE|INSERT|DELETE)\b[^"\n]*\$[a-z_{]|'
     r'''(?i:["']\s*(?:SELECT|UPDATE|INSERT|DELETE)\b[^"'\n]*["']\s*\.\s*\$)''',
     "SQL сформирован с переменной. Проверьте, что пользовательские значения передаются параметрами."),
    ((".php", ".phtml"), "embedded_credential", "high",
     r'''(?i:mysqli_connect\s*\(\s*["'][^"']+["']\s*,\s*["'][^"']+["']\s*,\s*["'][^"']+["'])''',
     "В исходнике обнаружен признак встроенного пароля. Проверьте хранение секрета."),
    ((".xml", ".xsl", ".xslt"), "xml_external_definition", "medium",
     r"(?i)<!DOCTYPE\s+[^>]*\b(?:SYSTEM|PUBLIC)\b",
     "XML ссылается на внешнее определение. Проверьте настройки XML-парсера."),
    ((".php", ".phtml"), "xml_external_definition", "medium",
     r"\bLIBXML_(?:DTDLOAD|DTDATTR|NOENT)\b",
     "Обнаружена настройка загрузки DTD или подстановки сущностей. Проверьте доверие к XML."),
)
PATTERNS = [(suffixes, code, severity, re.compile(pattern), message)
            for suffixes, code, severity, pattern, message in SIGNATURES]
ASSIGNMENT = re.compile(
    r'''(?im)(?<![\w-])["']?((?:[a-z][a-z0-9_-]*[_-])?'''
    r'''(?:password|passwd|dbpass|dbpassword|api[_-]?key|access[_-]?token|auth[_-]?token|'''
    r'''client[_-]?secret|secret[_-]?key|secret[_-]?access[_-]?key|private[_-]?token|token))["']?[^\S\n]*[:=][^\S\n]*'''
    r'''(?:"([^"\r\n]+)"|'([^'\r\n]+)'|([\w./+\-=]{4,})(?=[ \t]*(?:[#;,}]|$)))''')
PLACEHOLDER = re.compile(
    r"(?i)^(?:change[-_]?me|replace[-_]?me|your[-_]|example(?:$|[-_])|sample(?:$|[-_])|"
    r"dummy(?:$|[-_])|<|\$|\*+|null$|undefined$|getenv\b|process\.env\b|os\.environ\b)")


def finding(source, code, severity, message, path=None, line=None):
    item = {"source": source, "type": code, "severity": severity, "description": message,
            "path": path, "line": line}
    if source == "scenario" or code in {"admin_password_changed", "card_link_changed"}:
        profile = next(option for option in OPTIONS.values() if option["code"] == code)
        item.update(cvss=profile, severity=profile["severity"])
    return item


def document_root(project):
    for name in ("public_html", "public", "www"):
        candidate = project / name
        if candidate.is_dir() and not candidate.is_symlink():
            return candidate
    for name in ("index.php", "index.html"):
        if (project / name).is_file():
            return project
    return None


def read_source(path, limit):
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode):
            return None
        if info.st_size > limit:
            return None
        data = stream.read(limit + 1)
        return data if len(data) <= limit else None


def check_source(path, suffix, text):
    if path.rsplit("/", 1)[-1] == CARD_NAME:
        try:
            card = json.loads(text)
        except ValueError:
            card = None
        if (isinstance(card, dict) and card.get("name") == "Discord" and card.get("tag") == "messaging"
                and card.get("place") != "https://discord.com/"
                and (match := re.search(r'"place"\s*:', text))):
            yield finding("static", "card_link_changed", "high",
                          "Ссылка карточки Discord ведёт на другой сервис.", path,
                          text.count("\n", 0, match.start()) + 1)
    if suffix == ".sql" and (match := re.search(r"(?im)^INSERT\s+INTO\s+[`\"]?admins\b", text)):
        yield finding("static", "legacy_admin_dump", "medium",
                      "Дамп содержит записи администраторов. Храните его отдельно от веб-каталога.",
                      path, text.count("\n", 0, match.start()) + 1)
    for suffixes, code, severity, pattern, message in PATTERNS:
        if suffix in suffixes:
            for match in pattern.finditer(text):
                yield finding("static", code, severity, message, path, text.count("\n", 0, match.start()) + 1)
    if suffix in EXTENSIONS:
        for match in ASSIGNMENT.finditer(text):
            name, *values = match.groups()
            value = next(value for value in values if value is not None).strip()
            password = name.lower().endswith(("password", "passwd", "dbpass"))
            if len(value) < (4 if password else 8) or PLACEHOLDER.search(value):
                continue
            yield finding("static", "embedded_credential" if password else "api_key", "high",
                          "Обнаружено заданное напрямую значение. Значение скрыто.",
                          path, text.count("\n", 0, match.start()) + 1)
    if path.rsplit("/", 1)[-1] == "add_card.php" and "$_POST" in text and "adminSignedIn" not in text:
        yield finding("static", "review_access_control", "high",
                      "Проверьте серверную авторизацию у обработчика добавления карточек.",
                      path, text.count("\n", 0, text.index("$_POST")) + 1)


def inventory(project, excluded=None):
    docroot = document_root(project)
    counts = {}
    samples, findings = [], []
    skipped = inaccessible = 0
    used = 0
    scanned = 0
    limited = False
    hashes = {}
    unavailable = []
    for folder, dirs, names in os.walk(project, onerror=unavailable.append):
        dirs[:] = sorted(name for name in dirs if name not in IGNORED
                         and project.joinpath(folder, name) != excluded
                         and (not name.startswith(".") or (folder == str(project) and name == CASE_DIR)))
        for name in sorted(names):
            path = project.joinpath(folder, name)
            relative = path.relative_to(project).as_posix()
            suffix = path.suffix.lower()
            secret = name == ".env" or name.startswith(".env.")
            backup = name.lower().endswith((".sql.gz", ".sql.zip", ".bak", ".sqlite", ".sqlite3", ".old"))
            scenario = path.parent == project / CASE_DIR and suffix == CASE_EXTENSION
            inspect = suffix in EXTENSIONS or secret or scenario or backup
            if scanned + skipped >= MAX_FILES or used >= MAX_TOTAL_BYTES:
                limited = True
                break
            if path.is_symlink():
                skipped += 1
                continue
            try:
                info = path.lstat()
            except OSError:
                inaccessible += 1
                continue
            if not stat.S_ISREG(info.st_mode):
                skipped += 1
                continue
            file_findings = []
            if docroot and path.is_relative_to(docroot) and (secret or backup or suffix == ".sql"):
                file_findings.append(finding("static", "public_sensitive_file", "critical",
                                             "Файл похож на конфигурацию или резервную копию внутри веб-каталога.", relative))
            kind = "env" if secret else suffix.lstrip(".") or "без расширения"
            counts[kind] = counts.get(kind, 0) + 1
            if inspect and len(samples) < 70:
                samples.append(relative)
            scanned += 1
            hashes[relative] = f"metadata:{info.st_size}:{info.st_mtime_ns}"
            size_limit = min(MAX_FILE_BYTES, MAX_TOTAL_BYTES - used)
            if inspect and info.st_size <= size_limit:
                try:
                    data = read_source(path, size_limit)
                except OSError:
                    data = None
                if data is None:
                    inaccessible += 1
                else:
                    used += len(data)
                    digest = hashlib.sha256(data).hexdigest()
                    hashes[relative] = digest
                    if scenario and (origin := case_origin(relative, data)):
                        name, level = origin
                        code, title = PRESETS[name]
                        file_findings.append(finding("scenario", code, level, title, relative, 2))
                    elif not backup and path != BENCHMARK:
                        file_findings.extend(check_source(relative, ".env" if secret else suffix,
                                                          data.decode("utf-8-sig", errors="replace")))
                    for item in file_findings:
                        item["digest"] = digest
            elif inspect:
                skipped += 1
            by_line = {(item["type"], item["line"]): item for item in file_findings}
            findings.extend(by_line.values())
        if limited:
            break
    return ({"counts": counts, "examples": samples, "scanned": scanned, "skipped": skipped + inaccessible + len(unavailable),
             "inaccessible": inaccessible + len(unavailable),
             "limited": limited, "web_root": docroot.relative_to(project).as_posix() if docroot else None},
            findings, hashes)


def health(port):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    try:
        connection.request("GET", "/card.php")
        response = connection.getresponse()
        if response.status == 503 and response.getheader("X-Catalog-Maintenance") == "1":
            return {"status": "maintenance", "http": 503}, []
        if response.status != 200:
            return {"status": "down", "http": response.status}, [
                finding("health", "catalog_unavailable", "high", "API каталога вернуло ошибку HTTP.")]
        raw = response.read((2 << 20) + 1)
        cards = json.loads(raw) if len(raw) <= 2 << 20 else None
        if not isinstance(cards, list):
            raise ValueError("unexpected catalog response")
        missing = [name for name in ("Content-Security-Policy", "X-Content-Type-Options",
                                     "X-Frame-Options", "Referrer-Policy") if not response.getheader(name)]
        findings = [finding("health", "missing_header", "medium", f"Отсутствует заголовок {name}.")
                    for name in missing]
        return {"status": "ok", "http": 200, "cards": len(cards)}, findings
    except (OSError, ValueError, http.client.HTTPException):
        return {"status": "down", "http": None}, [
            finding("health", "catalog_unavailable", "high", "Локальный API каталога недоступен или вернул неверный JSON.")]
    finally:
        connection.close()


def runtime_events(state, cursor):
    db = (state / "catalog.sqlite3").as_uri() + "?mode=ro"
    with closing(sqlite3.connect(db, uri=True, timeout=3)) as connection:
        last = connection.execute("SELECT COALESCE(MAX(id), 0) FROM events").fetchone()[0]
        if last < cursor:
            cursor = 0
        rows = connection.execute("SELECT id, code FROM events WHERE id > ? ORDER BY id LIMIT 1000",
                                  (cursor,)).fetchall()
    counts = {}
    for _, code in rows:
        if code in EVENTS:
            counts[code] = counts.get(code, 0) + 1
    findings = []
    for code, count in counts.items():
        severity, description = EVENTS[code]
        if code == "auth_failed" and count >= 5:
            severity = "medium"
        findings.append(finding("runtime", code, severity, f"{description} Событий: {count}."))
    return findings, rows[-1][0] if rows else cursor
