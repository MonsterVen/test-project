"""Validation and evaluation for versioned rules."""

import json
import math
import re
from pathlib import Path


RULES_PATH = Path(__file__).resolve().with_name("rules.json")
FIELDS = {"source", "type", "severity", "port", "protocol", "service", "cwe", "cve"}


def valid_score(value):
    return type(value) in (int, float) and 0 <= value <= 10 and math.isfinite(value)


def load_rules(path):
    config = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or not valid_score(config.get("threshold")) or config["threshold"] == 0:
        raise ValueError("threshold must be in (0, 10]")
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", str(config.get("version"))):
        raise ValueError("version must use MAJOR.MINOR.PATCH")
    if not isinstance(config.get("rules"), list):
        raise ValueError("rules must be an array")
    names = set()
    for rule in config["rules"]:
        if not isinstance(rule, dict):
            raise ValueError("expected a rule object")
        for field in ("name", "category"):
            if not isinstance(rule.get(field), str) or not rule[field].strip():
                raise ValueError(f"rule {field} must be a non-empty string")
        if rule["name"] in names or not valid_score(rule.get("risk_score")):
            raise ValueError(f"duplicate rule name or invalid score: {rule['name']}")
        names.add(rule["name"])
        conditions = rule.get("conditions")
        if not isinstance(conditions, dict) or not conditions or not conditions.keys() <= FIELDS:
            raise ValueError(f"invalid conditions: {rule['name']}")
        for field, value in conditions.items():
            choices = value if isinstance(value, list) else [value]
            if field == "port":
                valid = all(type(item) is int and 0 <= item <= 65535 for item in choices)
            else:
                valid = all(item is None or isinstance(item, str) for item in choices)
            if not choices or not valid:
                raise ValueError(f"invalid condition value: {field}")
        advice = rule.get("recommendations", [])
        if not isinstance(advice, list) or any(not isinstance(item, str) for item in advice):
            raise ValueError("recommendations must be an array of strings")
    return config


def matches(finding, conditions):
    return all(finding.get(key) in value if isinstance(value, list) else finding.get(key) == value
               for key, value in conditions.items())


def evaluate(findings, config):
    triggered = []
    recommendations = []
    categories = []
    score = 0
    for rule in config["rules"]:
        indices = [index for index, finding in enumerate(findings)
                   if matches(finding, rule["conditions"])]
        if indices:
            score = max(score, rule["risk_score"])
            categories.append(rule["category"])
            recommendations.extend(rule.get("recommendations", []))
            triggered.append({"rule": rule["name"], "finding_indices": indices})
    return {"detected": score >= config["threshold"], "risk_score": score,
            "category": ", ".join(dict.fromkeys(categories)) or "none",
            "recommendations": list(dict.fromkeys(recommendations)),
            "triggering_findings": triggered, "rules_version": config["version"]}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Validate a JSON rule set.")
    parser.add_argument("rules", type=Path)
    args = parser.parse_args()
    try:
        load_rules(args.rules)
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")
