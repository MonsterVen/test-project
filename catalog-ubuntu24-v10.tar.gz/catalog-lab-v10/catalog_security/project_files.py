"""Reversible file isolation and inert scenario files."""

import errno
import hashlib
import json
import os
import sqlite3
import stat
from pathlib import Path, PurePosixPath
from uuid import uuid4

from catalog_db import ROOT
from cvss import OPTIONS
from finding_info import LEVELS, PRESETS


CASE_DIR = ".catalog-scenarios"
CASE_EXTENSION = ".audit-case"
PROTECTED = Path(__file__).resolve().parent
QUARANTINE_SCHEMA = """
CREATE TABLE IF NOT EXISTS quarantine (
    id TEXT PRIMARY KEY, project TEXT NOT NULL, path TEXT NOT NULL,
    digest TEXT NOT NULL, blocks_site INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS scenario_files (
    project TEXT NOT NULL, path TEXT NOT NULL, digest TEXT NOT NULL,
    PRIMARY KEY (project, path)
);
CREATE TABLE IF NOT EXISTS allowed_files (
    project TEXT NOT NULL, path TEXT NOT NULL, digest TEXT NOT NULL, PRIMARY KEY(project,path)
);
CREATE TABLE IF NOT EXISTS maintenance_holds (
    project TEXT NOT NULL, reason TEXT NOT NULL, PRIMARY KEY (project, reason)
);
"""


def safe_path(root, relative):
    part = PurePosixPath(relative)
    if part.is_absolute() or not part.parts or ".." in part.parts or "\\" in relative:
        raise ValueError("Недопустимый путь к файлу.")
    if root.resolve(strict=True) != root:
        raise ValueError("Папка проекта была перемещена или заменена.")
    candidate = root.joinpath(*part.parts)
    if candidate.resolve() != candidate or not candidate.parent.is_dir():
        raise ValueError("Путь к файлу изменился или содержит символическую ссылку.")
    return candidate


def case_bytes(name, level=None):
    if level is None:
        return (json.dumps({"kind": name}, indent=2) + "\n").encode()
    return (json.dumps({"kind": name, "level": level}, indent=2) + "\n").encode()


def case_origin(relative, data):
    path = PurePosixPath(relative)
    if path.parent != PurePosixPath(CASE_DIR) or path.suffix != CASE_EXTENSION:
        return None
    name = path.stem
    if name not in PRESETS:
        return None
    if case_bytes(name) == data:
        return name, OPTIONS[name]["severity"]
    return next(((name, level) for level in LEVELS if case_bytes(name, level) == data), None)


def rollback_cases(project, vault):
    manifest = {path: digest for path, digest in vault.scenario_manifest(project).items()
                if PurePosixPath(path).parent == PurePosixPath(CASE_DIR)}
    if not manifest:
        return 0
    directory = project / CASE_DIR
    if directory.is_symlink():
        raise ValueError("Папка контрольных файлов заменена.")
    files = []
    for relative, digest in manifest.items():
        if not directory.is_dir():
            continue
        file = safe_path(project, relative)
        if not file.exists():
            continue
        if not file.is_file() or file.stat().st_size > 256 or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise ValueError("Контрольный файл изменён. Его содержимое сохранено.")
        files.append(file)
    removed = len(files) + vault.discard_cases(project, manifest)
    for file in files:
        file.unlink()
    for relative in manifest:
        vault.forget_case(project, relative)
    return removed


class Vault:
    def __init__(self, state, store):
        self.store = store
        self.directory = state / "quarantine"
        self.marker = state / "maintenance"
        self.directory.mkdir(mode=0o700, exist_ok=True)
        with store.open() as db:
            db.executescript(QUARANTINE_SCHEMA)
            if "locations" not in {row["name"] for row in db.execute("PRAGMA table_info(quarantine)")}:
                db.execute("ALTER TABLE quarantine ADD COLUMN locations TEXT NOT NULL DEFAULT '[]'")
        self.sync_marker()

    def entries(self, project=None):
        args = (str(project),) if project is not None else ()
        with self.store.open() as db:
            selector = " WHERE project = ?" if args else ""
            rows = db.execute("SELECT * FROM quarantine" + selector, args).fetchall()
        return [{**dict(row), "locations": json.loads(row["locations"])}
                for row in rows if (self.directory / row["id"]).is_file()
                and not (self.directory / row["id"]).is_symlink()]

    def set_hold(self, project, reason, active):
        with self.store.open() as db:
            if active:
                db.execute("INSERT OR IGNORE INTO maintenance_holds VALUES (?, ?)", (str(project), reason))
            else:
                db.execute("DELETE FROM maintenance_holds WHERE project = ? AND reason = ?", (str(project), reason))

    def sync_marker(self):
        with self.store.open() as db:
            hold = db.execute("SELECT 1 FROM maintenance_holds LIMIT 1").fetchone()
        if hold or any(row["blocks_site"] for row in self.entries()):
            self.marker.touch()
        else:
            self.marker.unlink(missing_ok=True)

    def cases(self, project):
        return [row for row in self.entries(project)
                if PurePosixPath(row["path"]).parent == PurePosixPath(CASE_DIR)]

    def remember_case(self, project, relative, data):
        with self.store.open() as db:
            db.execute("INSERT INTO scenario_files VALUES (?, ?, ?)",
                       (str(project), relative, hashlib.sha256(data).hexdigest()))

    def forget_case(self, project, relative):
        with self.store.open() as db:
            db.execute("DELETE FROM scenario_files WHERE project = ? AND path = ?", (str(project), relative))

    def scenario_manifest(self, project):
        with self.store.open() as db:
            return dict(db.execute("SELECT path, digest FROM scenario_files WHERE project = ?", (str(project),)))

    def active_card(self):
        with self.store.open() as db:
            row = db.execute("SELECT project, path, digest FROM scenario_files WHERE path IN (?, ?)",
                             ("public_html/featured-messaging.json", "featured-messaging.json")).fetchone()
        return (Path(row[0]), row[1], row[2]) if row else None

    def discard_cases(self, project, manifest):
        candidates = []
        for row in self.cases(project):
            if row["path"] not in manifest:
                continue
            saved = self.directory / row["id"]
            if saved.stat().st_size > 256 or hashlib.sha256(saved.read_bytes()).hexdigest() != manifest[row["path"]]:
                raise ValueError("Контрольный файл в карантине изменён и сохранён.")
            candidates.append(row)
        for row in candidates:
            (self.directory / row["id"]).unlink()
            self.forget(row["id"])
        self.sync_marker()
        return len(candidates)

    def patch(self, identifier, data):
        temporary = self.directory / uuid4().hex
        try:
            with temporary.open("xb") as output:
                output.write(data)
            os.chmod(temporary, (self.directory / identifier).stat().st_mode & 0o777)
            os.replace(temporary, self.directory / (identifier + ".patch"))
        finally:
            temporary.unlink(missing_ok=True)

    def forget(self, identifier):
        (self.directory / (identifier + ".patch")).unlink(missing_ok=True)
        with self.store.open() as db:
            db.execute("DELETE FROM quarantine WHERE id = ?", (identifier,))

    def prepare(self, project, item):
        source = safe_path(project, item["path"])
        if (source.is_relative_to(PROTECTED) or source.is_relative_to(self.directory.parent)
                or not source.is_file()):
            raise ValueError("Файл недоступен для изоляции.")
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > 1 << 20 or info.st_nlink != 1:
            raise ValueError("Карантин поддерживает обычные файлы без жёстких ссылок размером до 1 МиБ.")
        if info.st_dev != self.directory.stat().st_dev:
            raise ValueError("Для карантина проект и CATALOG_STATE должны быть на одной файловой системе.")
        with source.open("rb") as stream:
            actual = hashlib.sha256(stream.read((1 << 20) + 1)).hexdigest()
        if actual != item["digest"]:
            raise ValueError("Файл изменился после проверки. Запустите аудит заново.")
        return source, info, actual

    def quarantine(self, project, items, *, bulk=False):
        files = {item["path"]: item for item in items}
        prepared = [self.prepare(project, item) for item in files.values()]
        blocks_site = bulk and (project == ROOT or project.is_relative_to(ROOT / "public_html")
                                or any(source.is_relative_to(ROOT / "public_html") for source, _, _ in prepared))
        if blocks_site:
            self.marker.touch()
        moved = []
        try:
            for source, original, digest in prepared:
                current = source.lstat()
                if (current.st_dev, current.st_ino, current.st_ctime_ns) != (
                        original.st_dev, original.st_ino, original.st_ctime_ns):
                    raise ValueError("Один из файлов изменился. Запустите аудит повторно.")
                identifier = uuid4().hex
                relative = source.relative_to(project).as_posix()
                with self.store.open() as db:
                    db.execute("INSERT INTO quarantine(id, project, path, digest, blocks_site, locations) "
                               "VALUES (?, ?, ?, ?, ?, ?)",
                               (identifier, str(project), relative, digest, int(blocks_site),
                                json.dumps(files[relative].get("locations", []))))
                os.rename(source, self.directory / identifier)
                moved.append({"id": identifier, "project": str(project), "path": relative, "digest": digest})
        except (OSError, ValueError, sqlite3.Error):
            for row in reversed(moved):
                self.restore(row)
            raise
        finally:
            self.sync_marker()
        return len(moved)

    def restore(self, row, allow=False):
        source = self.directory / row["id"]
        target = safe_path(Path(row["project"]), row["path"])
        with source.open("rb") as stream:
            data = stream.read((1 << 20) + 1)
        if hashlib.sha256(data).hexdigest() != row["digest"]:
            raise ValueError("Содержимое файла в карантине изменилось.")
        patch = self.directory / (row["id"] + ".patch")
        payload = patch if patch.is_file() else source
        digest = hashlib.sha256(payload.read_bytes()).hexdigest() if allow else None
        try:
            os.link(payload, target, follow_symlinks=False)
        except FileExistsError as error:
            if target.lstat().st_ino != payload.lstat().st_ino or target.lstat().st_dev != payload.lstat().st_dev:
                raise ValueError("По исходному пути уже есть другой файл.") from error
        except OSError as error:
            if error.errno == errno.EXDEV:
                raise ValueError("Исходный путь теперь находится на другой файловой системе.") from error
            raise
        if allow:
            with self.store.open() as db:
                db.execute("INSERT OR REPLACE INTO allowed_files VALUES (?,?,?)",
                           (row["project"], row["path"], digest))
        source.unlink()
        self.forget(row["id"])
        self.sync_marker()
