#!/usr/bin/env bash
set -euo pipefail
printf 'Конструктор сценариев: http://127.0.0.1:%s/scenarios\n' "${MONITOR_PORT:-8081}"
