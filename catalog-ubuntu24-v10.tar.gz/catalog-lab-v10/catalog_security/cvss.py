"""CVSS v3.1 Base metrics for the vulnerability modelled by each scenario."""

from math import prod


def base_score(vector):
    version, *fields = vector.split("/")
    metrics = dict(field.split(":") for field in fields)
    if version != "CVSS:3.1" or len(fields) != 8 or set(metrics) != set("AV AC PR UI S C I A".split()):
        raise ValueError("Expected a CVSS v3.1 Base vector")
    changed = {"U": False, "C": True}[metrics["S"]]
    impact_weights = {"N": 0, "L": .22, "H": .56}
    iss = 1 - prod(1 - impact_weights[metrics[key]] for key in "CIA")
    impact = 7.52 * (iss - .029) - 3.25 * (iss - .02)**15 if changed else 6.42 * iss
    av = {"N": .85, "A": .62, "L": .55, "P": .2}[metrics["AV"]]
    ac = {"L": .77, "H": .44}[metrics["AC"]]
    pr = {"N": .85, "L": .68 if changed else .62, "H": .5 if changed else .27}[metrics["PR"]]
    ui = {"N": .85, "R": .62}[metrics["UI"]]
    if impact <= 0:
        return 0.0
    total = (impact + 8.22 * av * ac * pr * ui) * (1.08 if changed else 1)
    scaled = round(min(10, total) * 100000)
    return ((scaled + 9999) // 10000) / 10


def profile(code, label, metrics, assumption):
    vector = "CVSS:3.1/" + metrics
    risk = base_score(vector)
    severity = "critical" if risk >= 9 else "high" if risk >= 7 else "medium" if risk >= 4 else "low"
    return dict(code=code, label=label, vector=vector, risk=risk, severity=severity, assumption=assumption)


OPTIONS = {
    "sql": profile("dynamic_sql", "SQL-инъекция", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
                   "Открытый обработчик допускает чтение, изменение и удаление данных всей базы."),
    "web": profile("dynamic_html", "Межсайтовый скриптинг (XSS)", "AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N",
                   "Посетитель открывает страницу. Под угрозой часть данных и действий в его браузере."),
    "xml": profile("xml_external_definition", "Обработка внешних сущностей XML (XXE)", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
                   "Общедоступный обработчик XML допускает чтение конфиденциальных файлов сервера."),
    "access": profile("review_access_control", "Отсутствие проверки прав доступа", "AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N",
                      "Обычная учётная запись получает доступ к чтению и изменению закрытых записей."),
    "password": profile("embedded_credential", "Раскрытие пароля в исходном файле", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
                        "Публичный файл содержит действующий пароль с правами чтения и изменения данных."),
    "api": profile("api_key", "Раскрытие ключа API", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
                   "Публичный ключ даёт доступ к чтению конфиденциальных данных API."),
    "card": profile("card_link_changed", "Нарушение контроля целостности ссылки на скачивание",
                    "AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N", "Посторонний может изменить доверенный адрес загрузки на Web ресурсе."),
    "admin": profile("admin_password_changed", "Недостаточная авторизация при смене пароля администратора",
                     "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
                     "Смена пароля посторонним даёт полный контроль над данными и доступностью Web ресурса."),
}
