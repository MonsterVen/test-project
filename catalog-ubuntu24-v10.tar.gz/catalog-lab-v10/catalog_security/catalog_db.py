"""Create a local catalog from the card rows of a MySQL export."""

import argparse
import getpass
import json
import os
import re
import sqlite3
import subprocess
from contextlib import closing
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_STATE = ROOT / ".catalog-state"
INSERT = re.compile(r"^INSERT\s+INTO\s+`card`\s+VALUES\s*", re.I | re.M)
TOKEN = re.compile(r"\s*(?:(?:_binary\s+)?'((?:[^'\\]|\\.|'')*)'|([0-9]+)|([(),;]))", re.S)
ESCAPES = {"0": "\0", "b": "\b", "n": "\n", "r": "\r", "t": "\t", "Z": "\x1a"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS card (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL, disc TEXT NOT NULL, tag TEXT NOT NULL,
  place TEXT NOT NULL, img TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admins (
  username TEXT PRIMARY KEY, password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS initialized (id INTEGER PRIMARY KEY CHECK(id = 1));
"""


def parse_rows(sql, start):
    def token():
        nonlocal start
        match = TOKEN.match(sql, start)
        if match is None:
            raise ValueError(f"Неподдерживаемый формат строки card, позиция {start}.")
        start = match.end()
        string, number, punctuation = match.groups()
        if string is not None:
            return re.sub(r"''|\\(.)", lambda m: "'" if m[1] is None else ESCAPES.get(m[1], m[1]),
                          string, flags=re.S)
        return int(number) if number is not None else punctuation

    while True:
        if token() != "(":
            raise ValueError("Ожидалась строка таблицы card.")
        values = [token()]
        for _ in range(5):
            if token() != ",":
                raise ValueError("Ожидалось шесть столбцов в таблице card.")
            values.append(token())
        if token() != ")" or type(values[0]) is not int or any(type(v) is not str for v in values[1:]):
            raise ValueError("Типы полей таблицы card не совпадают со схемой.")
        yield values
        separator = token()
        if separator == ";":
            return
        if separator != ",":
            raise ValueError("Не найден конец INSERT таблицы card.")


def extract_cards(dump):
    with dump.open("rb") as stream:
        raw = stream.read((16 << 20) + 1)
    if len(raw) > 16 << 20:
        raise ValueError("Размер исходного дампа превышает 16 МиБ.")
    sql = raw.decode("utf-8-sig")
    rows = [row for match in INSERT.finditer(sql) for row in parse_rows(sql, match.end())]
    if not rows or len({row[0] for row in rows}) != len(rows):
        raise ValueError("В дампе нет строк карточек или ID повторяются.")
    return rows


def connect(state):
    state.mkdir(mode=0o700, parents=True, exist_ok=True)
    (state / "sessions").mkdir(mode=0o700, exist_ok=True)
    return sqlite3.connect(state / "catalog.sqlite3", timeout=5)


def initialize(state, dump=None):
    with closing(connect(state)) as connection, connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.executescript(SCHEMA)
        connection.execute("BEGIN IMMEDIATE")
        if not connection.execute("SELECT id FROM initialized WHERE id = 1").fetchone():
            rows = extract_cards(dump) if dump else json.loads((HERE / "cards.json").read_text(encoding="utf-8"))
            connection.executemany("INSERT INTO card VALUES (?, ?, ?, ?, ?, ?)", rows)
            connection.execute("INSERT INTO initialized(id) VALUES (1)")
        return connection.execute("SELECT COUNT(*) FROM card").fetchone()[0]


def set_admin(state, username):
    if not re.fullmatch(r"[a-zA-Z0-9_.-]{1,32}", username):
        raise ValueError("Имя администратора должно содержать 1–32 буквы латиницы, цифры или ._-")
    if not os.isatty(0):
        raise ValueError("Для ввода пароля запустите команду в терминале.")
    password = getpass.getpass("Новый пароль: ")
    if not 12 <= len(password.encode("utf-8")) <= 72 or "\0" in password:
        raise ValueError("Укажите пароль длиной от 12 до 72 байт.")
    if password != getpass.getpass("Повторите пароль: "):
        raise ValueError("Пароли не совпадают.")
    hashed = subprocess.run(
        ["php", "-r", "echo password_hash(stream_get_contents(STDIN), PASSWORD_DEFAULT);"],
        input=password, text=True, capture_output=True, check=True,
    ).stdout
    if not hashed.startswith("$"):
        raise ValueError("PHP не смог сохранить хеш пароля.")
    with closing(connect(state)) as connection, connection:
        connection.execute(
            "INSERT INTO admins VALUES (?, ?) ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash",
            (username, hashed),
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init")
    init.add_argument("--dump", type=Path)
    seed = commands.add_parser("seed")
    seed.add_argument("dump", type=Path)
    seed.add_argument("output", type=Path)
    admin = commands.add_parser("admin")
    admin.add_argument("username")
    args = parser.parse_args()
    state = Path(os.environ.get("CATALOG_STATE", DEFAULT_STATE)).expanduser().resolve()
    os.umask(0o077)
    try:
        if args.command == "seed":
            rows = extract_cards(args.dump)
            args.output.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(f"Экспортировано карточек: {len(rows)}")
        elif args.command == "init":
            print(f"Карточек в локальной базе: {initialize(state, args.dump)}")
        else:
            initialize(state)
            set_admin(state, args.username)
            print(f"Администратор сохранён: {args.username}")
    except (OSError, ValueError, sqlite3.Error, subprocess.SubprocessError) as error:
        parser.exit(2, f"{error}\n")


if __name__ == "__main__":
    main()
