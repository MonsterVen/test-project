#!/usr/bin/env python3
"""Evaluate source-audit rules on a labeled, isolated corpus."""

import argparse
import csv
import io
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory

from audit import inventory
from catalog_db import DEFAULT_STATE
from finding_info import PRESETS


SUITES = {"basic": "Базовый набор", "extended": "Расширенный набор"}
CODES = (*[code for code, _ in PRESETS.values()], "public_sensitive_file")

# These are text excerpts. The evaluator writes them outside the site and never executes them.
BASIC = (
    ("query.php", 'query fragment: "SELECT name FROM card WHERE id = $value"\n', ("dynamic_sql",),
     "SQL-фрагмент с интерполяцией"),
    ("dom.js", "DOM excerpt: card.innerHTML = suppliedText\n", ("dynamic_html",),
     "Вставка непроверенного текста"),
    ("layout.xml", '<!DOCTYPE layout SYSTEM "catalog.dtd"><layout/>\n', ("xml_external_definition",),
     "XML с внешним определением"),
    ("credentials.ini", 'DB_PASSWORD = "CatalogLab123!"\n', ("embedded_credential",), "Искусственный пароль"),
    ("settings.json", '{"billing_api_key":"CatalogLabToken402"}\n', ("api_key",), "Искусственный токен"),
    ("add_card.php", 'form source: $_POST\n', ("review_access_control",), "В примере отсутствует проверка роли"),
    ("safe_query.php", '$statement = $db->prepare("SELECT name FROM card WHERE id = ?");\n', (),
     "Подготовленный запрос"),
    ("safe_dom.js", "card.textContent = suppliedText\n", (), "Текстовый DOM-вывод"),
    ("template.env", "DB_PASSWORD=change-me\nAUTH_TOKEN=${AUTH_TOKEN}\n", (), "Шаблон и ссылка на окружение"),
    ("public_html/.env", "# Empty local settings\n", ("public_sensitive_file",), "Файл конфигурации в веб-каталоге"),
)

EXTENDED = (
    ("nested/database.toml", '[database]\n\tpassword = "Catalog Lab 17!"\n', ("embedded_credential",),
     "Секция и пробелы в значении"),
    ("mixed.yaml", "services:\n  db-password: CatalogLab247\n  api_key: 'CatalogService058'\n",
     ("embedded_credential", "api_key"), "Две категории находок в одном файле"),
    ("config/app.conf", "rate_limit=60\nAUTH_TOKEN=CatalogLab401  # test value\n", ("api_key",),
     "Непустое значение с комментарием"),
    ("nested/view.ts", "view.insertAdjacentHTML('beforeend', displayValue)\n", ("dynamic_html",),
     "Другой метод DOM и расширение TypeScript"),
    ("nested/main.phtml", "options excerpt: LIBXML_DTDLOAD\n", ("xml_external_definition",),
     "Флаг парсера в шаблоне"),
    ("catalog.xsl", '<!DOCTYPE catalog\n SYSTEM "catalog.dtd">\n<catalog/>\n', ("xml_external_definition",),
     "Объявление XML занимает две строки"),
    ("authorized/add_card.php", "checks: adminSignedIn()\nform source: $_POST\n", (),
     "Проверка роли рядом с обработкой формы"),
    ("scope.php", 'trusted enum fragment: "SELECT id FROM card ORDER BY $fixedSort"\n', (),
     "Сортировка из доверенного внутреннего списка"),
    ("preview.js", "fixed preview excerpt: const caption = 'fixed'; preview.innerHTML = caption\n", (),
     "Переменная хранит фиксированный текст"),
    ("legacy.conf", "shared_value=CatalogLab441\n", ("embedded_credential",),
     "Пароль известен по спецификации старого формата"),
    ("logging.txt", "Event record: authenticated request rejected\n", (), "Обычная диагностическая строка"),
    ("safe.yaml", 'api_key: "replace-me"\npassword: "${DB_PASSWORD}"\n', (), "Настройки-шаблоны без секретов"),
    ("private/catalog.sql", "CREATE TABLE card (id INTEGER);\n", (), "SQL вне веб-каталога"),
    ("public_html/schema.sql", "CREATE TABLE card (id INTEGER);\n", ("public_sensitive_file",),
     "SQL внутри веб-каталога"),
    ("structure.xml", "<?xml version='1.0'?>\n<catalog><title>demo</title></catalog>\n", (),
     "Обычная структура XML"),
    ("long.env", "API_KEY=CatalogLabToken111\nDB_PASSWORD=CatalogLab402\nSERVICE_TOKEN=CatalogLabToken222\n",
     ("api_key", "embedded_credential"), "Несколько строк с ключами и паролем"),
)


def evaluate_suite(suite):
    if not isinstance(suite, str) or suite not in SUITES:
        raise ValueError("Выберите один из доступных наборов.")
    cases = BASIC if suite == "basic" else BASIC + EXTENDED
    with TemporaryDirectory(prefix="catalog-detection-") as directory:
        root = Path(directory)
        for name, content, _, _ in cases:
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        _, findings, _ = inventory(root)
    observed = {}
    for item in findings:
        observed.setdefault((item["path"], item["type"]), []).append(item["line"])
    rows = []
    counts = dict(TP=0, FP=0, FN=0, TN=0)
    for name, _, expected, description in cases:
        for code in CODES:
            key = name, code
            actual, predicted = code in expected, key in observed
            outcome = {(True, True): "TP", (False, True): "FP",
                       (True, False): "FN", (False, False): "TN"}[actual, predicted]
            counts[outcome] += 1
            rows.append({"file": name, "rule": code, "actual": int(actual), "predicted": int(predicted),
                         "outcome": outcome, "lines": "|".join(str(line) for line in observed.get(key, [])
                                                              if line is not None), "case": description})
    tp, fp, fn = (counts[key] for key in ("TP", "FP", "FN"))

    def ratio(a, b):
        return round(a / b, 4) if b else 0

    return {"suite": suite, "label": SUITES[suite], "cases": len(cases), "counts": counts, "rows": rows,
            "precision": ratio(tp, tp + fp), "recall": ratio(tp, tp + fn),
            "f1": ratio(2 * tp, 2 * tp + fp + fn)}


def dataset_csv(result):
    stream = io.StringIO(newline="")
    columns = ("file", "rule", "actual", "predicted", "outcome", "lines", "case")
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    writer.writerows(result["rows"])
    return stream.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", choices=SUITES, default="extended")
    parser.add_argument("--output", type=Path, help="Сохранить датасет CSV дополнительно к записи в истории")
    args = parser.parse_args()
    from monitor import Store, record_test

    os.umask(0o077)
    try:
        state = Path(os.environ.get("CATALOG_STATE", DEFAULT_STATE)).expanduser().resolve()
        identifier, result = record_test(Store(state), args.suite)
        if args.output:
            with args.output.open("x", encoding="utf-8-sig", newline="") as stream:
                stream.write(dataset_csv(result))
        print(json.dumps({"history_id": identifier, **{k: v for k, v in result.items() if k != "rows"}},
                         ensure_ascii=False, indent=2))
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")


if __name__ == "__main__":
    main()
