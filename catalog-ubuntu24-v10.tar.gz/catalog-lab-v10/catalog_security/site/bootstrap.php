<?php
declare(strict_types=1);

function db(): PDO
{
    static $connection;
    if ($connection === null) {
        $state = getenv('CATALOG_STATE');
        if ($state === false || !is_file($state . '/catalog.sqlite3')) {
            throw new RuntimeException('Каталог не инициализирован');
        }
        $connection = new PDO('sqlite:' . $state . '/catalog.sqlite3');
        $connection->exec('PRAGMA busy_timeout = 3000');
    }
    return $connection;
}

function jsonResponse(array $value, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($value, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
    exit;
}

function event(string $code): void
{
    try {
        $statement = db()->prepare("INSERT INTO events(code) VALUES (?)");
        $statement->execute([$code]);
    } catch (Throwable $error) {
        error_log('Could not write catalog event: ' . $code);
    }
}

function sessionOpen(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('catalog_session');
    session_save_path(getenv('CATALOG_STATE') . '/sessions');
    session_start(['use_strict_mode' => 1, 'use_only_cookies' => 1,
        'cookie_httponly' => true, 'cookie_samesite' => 'Strict']);
}

function adminSignedIn(): bool
{
    sessionOpen();
    if (!isset($_SESSION['admin'], $_SESSION['credential_version'])) {
        return false;
    }
    $statement = db()->prepare('SELECT password_hash FROM admins WHERE username = ?');
    $statement->execute([$_SESSION['admin']]);
    $currentHash = $statement->fetchColumn();
    return is_string($currentHash) && hash_equals($_SESSION['credential_version'], hash('sha256', $currentHash));
}

function csrfToken(): string
{
    sessionOpen();
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
}

function csrfValid(): bool
{
    sessionOpen();
    $submitted = $_POST['csrf'] ?? null;
    return is_string($submitted) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $submitted);
}

function formText(string $name): string
{
    $value = $_POST[$name] ?? '';
    return is_string($value) ? trim($value) : '';
}

function postOnly(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Allow: POST');
        jsonResponse(['message' => 'Используйте POST.'], 405);
    }
}

function formContent(): void
{
    $type = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '', 2)[0]));
    if (!in_array($type, ['application/x-www-form-urlencoded', 'multipart/form-data'], true)) {
        event('unsupported_media');
        jsonResponse(['message' => 'Ожидаются данные HTML-формы.'], 415);
    }
}
