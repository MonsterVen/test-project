<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    . "img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");

$root = dirname(__DIR__, 2) . '/public_html';
$path = rawurldecode(explode('?', $_SERVER['REQUEST_URI'], 2)[0]);
$endpoints = ['/card.php', '/check_login.php', '/add_card.php'];
$pages = ['/' => 'index.html', '/index.html' => 'index.html',
    '/profile.html' => 'profile.html', '/adminpage.html' => 'adminpage.html'];

function unavailable(bool $maintenance): bool
{
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    if ($maintenance) {
        header('X-Catalog-Maintenance: 1');
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'HEAD') {
        echo '<!doctype html><html lang="ru"><meta charset="utf-8"><title>Каталог</title>'
            . '<h1>Сайт временно недоступен.</h1></html>';
    }
    return true;
}

try {
    $port = getenv('CATALOG_PORT') ?: '8000';
    if (!in_array($_SERVER['HTTP_HOST'] ?? '', ['127.0.0.1:' . $port, 'localhost:' . $port], true)) {
        jsonResponse(['message' => 'Откройте каталог на 127.0.0.1.'], 403);
    }
    $state = getenv('CATALOG_STATE');
    if ($state !== false && is_file($state . '/maintenance')) {
        return unavailable(true);
    }
    if (in_array($path, $endpoints, true)) {
        if (!is_file($root . $path)) {
            return unavailable(false);
        }
        require $root . $path;
        return true;
    }
    if ($path === '/logout.php') {
        postOnly();
        formContent();
        if (!csrfValid()) {
            event('csrf_rejected');
            jsonResponse(['message' => 'Обновите страницу.'], 403);
        }
        $_SESSION = [];
        session_destroy();
        setcookie(session_name(), '', ['expires' => 1, 'path' => '/', 'samesite' => 'Strict', 'httponly' => true]);
        header('Location: /profile.html', true, 303);
        return true;
    }
    if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'], true)) {
        header('Allow: GET, HEAD');
        jsonResponse(['message' => 'Метод не поддерживается.'], 405);
    }
    if (isset($pages[$path])) {
        if (!is_file($root . '/' . $pages[$path])) {
            return unavailable(false);
        }
        if ($path === '/adminpage.html' && !adminSignedIn()) {
            event('auth_required');
            header('Location: /profile.html', true, 303);
            return true;
        }
        $template = file_get_contents($root . '/' . $pages[$path]);
        if ($path === '/profile.html' || $path === '/adminpage.html') {
            header('Cache-Control: no-store');
            $token = csrfToken();
            $error = $_SESSION['login_error'] ?? '';
            unset($_SESSION['login_error']);
            $template = strtr($template, ['{{CSRF}}' => $token, '{{LOGIN_ERROR}}' => $error]);
        }
        header('Content-Type: text/html; charset=utf-8');
        echo $template;
        return true;
    }

    $asset = preg_match('~^/(?:[a-z0-9_-]+\.(?:css|js)|images/[a-z0-9_+.-]+\.(?:svg|png)|'
        . 'font-awesome/font-awesome-4\.7\.0/(?:css/[a-z0-9.-]+\.css|fonts/[a-z0-9.-]+\.(?:woff2?|ttf|svg|eot|otf)))$~iD', $path);
    $resolved = $asset ? realpath($root . $path) : false;
    if ($resolved && str_starts_with($resolved, realpath($root) . DIRECTORY_SEPARATOR) && is_file($resolved)) {
        $types = ['css' => 'text/css', 'js' => 'text/javascript', 'svg' => 'image/svg+xml',
            'png' => 'image/png', 'woff' => 'font/woff', 'woff2' => 'font/woff2',
            'ttf' => 'font/ttf', 'otf' => 'font/otf', 'eot' => 'application/vnd.ms-fontobject'];
        header('Content-Type: ' . $types[strtolower(pathinfo($resolved, PATHINFO_EXTENSION))]);
        header('Content-Length: ' . filesize($resolved));
        if ($_SERVER['REQUEST_METHOD'] !== 'HEAD') {
            readfile($resolved);
        }
        return true;
    }
    jsonResponse(['message' => 'Страница не найдена.'], 404);
} catch (Throwable $error) {
    error_log((string) $error);
    jsonResponse(['message' => 'Ошибка приложения.'], 500);
}
