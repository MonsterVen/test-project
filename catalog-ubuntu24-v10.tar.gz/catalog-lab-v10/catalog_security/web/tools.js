"use strict";

const feedback = byId("feedback");
const params = new URLSearchParams(location.search);

function message(text, problem = false) {
    feedback.textContent = text;
    feedback.className = problem ? "problem" : "good";
}

async function submit(button, task) {
    button.disabled = true;
    try {
        await task();
    } catch (error) {
        message(error.message, true);
    } finally {
        button.disabled = false;
    }
}

async function projectFilePage() {
    const file = await api("/api/file?" + params);
    byId("filename").textContent = file.path;
    projectLink(byId("root"), file.project);
    byId("status").textContent = file.status;
    const report = params.get("report");
    if (file.quarantine) append(byId("status"), "a", " · Открыть в карантине").href = "/quarantine-file?id=" + file.quarantine;
    for (const item of file.locations) {
        const text = (item.line ? "Строка " + item.line + " · " : "") + item.title;
        append(append(byId("locations"), "li"), "a", text).href = "/finding?report=" + report + "&index=" + item.index;
    }
    const button = byId("download");
    button.hidden = !["В карантине", "В проекте"].includes(file.status);
    button.onclick = () => submit(button, () => downloadFile("/api/file-download", {report, path: file.path}, file.path));
}

async function downloadFile(route, data, name) {
        const response = await fetch(route, {method: "POST",
            headers: {"Content-Type": "application/json", "X-Catalog-Action": "1"},
            body: JSON.stringify(data)});
        if (!response.ok) throw new Error((await response.json()).error);
        const url = URL.createObjectURL(await response.blob());
        const link = document.createElement("a");
        link.href = url;
        link.download = filename(name);
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function findingPage() {
    const result = await api("/api/finding?" + params);
    const item = result.finding;
    byId("title").textContent = levels[item.severity] + " — " + item.title;
    const where = byId("where");
    where.textContent = item.path ? "Местоположение " : "";
    if (item.path) fileLink(where, result.report, item.path, locationLabel(item));
    else append(where, "code", locationLabel(item));
    byId("title").className = tone(item.cvss?.risk ?? item.rule_score ?? 0);
    projectLink(byId("root").parentNode, result.project);
    byId("what").textContent = item.explanation;
    if (item.assessment && !item.cvss) item.cvss = item.assessment;
    if (item.cvss) {
        append(byId("what"), "strong", " CVSS 3.1 · " + item.cvss.risk.toFixed(1) + "/10. ");
        append(byId("what"), "code", item.cvss.vector);
        append(byId("what"), "span", " Условия оценки. " + item.cvss.assumption);
    }
    if (item.cwe) {
        const cwe = byId("cwe");
        const reference = append(cwe, "a", item.cwe);
        reference.href = "https://cwe.mitre.org/data/definitions/" + item.cwe.slice(4) + ".html";
        reference.target = "_blank";
        reference.rel = "noopener noreferrer";
        cwe.hidden = false;
    }
    if (item.remediation) {
        byId("fix").textContent = item.remediation;
        byId("fix-panel").hidden = false;
    }
    byId("finding").hidden = false;
    const isolate = byId("isolate");
    isolate.hidden = !item.isolate;
    isolate.addEventListener("click", () => submit(isolate, async () => {
        await api("/api/quarantine/add", {report: result.report, index: result.index});
        isolate.hidden = true;
        message("Файл перемещён в карантин.");
    }));
}

function isolatedFile(group, item, open) {
    const file = append(group, "details");
    file.open = open;
    file.id = "isolated-" + item.id;
    append(file, "summary", filename(item.path));
    const detail = append(file, "div");
    detail.className = "detail";
    append(detail, "h3", "Местоположение");
    append(append(detail, "p"), "code", item.path);
    append(detail, "h3", "Подробная информация");
    for (const loc of item.locations) {
        const heading = append(detail, "p");
        append(heading, "strong", loc.title);
        if (loc.line) append(heading, "span", " · Строка " + loc.line);
        if (loc.cvss) append(heading, "span", " · CVSS 3.1 " + loc.cvss.risk.toFixed(1) + "/10").className = tone(loc.cvss.risk);
        if (loc.description) append(detail, "p", loc.description);
    }
    if (!item.locations.length) append(detail, "p", "Подробности отсутствуют в исходном отчёте.");
    const controls = append(detail, "div");
    controls.className = "controls";
    const local = append(detail, "p");
    local.setAttribute("role", "status");
    async function run(task) {
        controls.inert = true;
        local.textContent = "";
        try { await task(); }
        catch (error) { local.textContent = error.message; local.className = "problem"; }
        finally { controls.inert = false; }
    }
    const restore = append(controls, "button", "Восстановить");
    restore.title = "Вернуть на исходное место и разрешить эту версию файла";
    restore.onclick = () => run(async () => {
        await api("/api/quarantine/restore", {id:item.id});
        await refreshAfter("Файл восстановлен. Эта версия добавлена в исключения.");
    });
    const remove = append(controls, "button", "Удалить");
    remove.className = "danger-button";
    remove.onclick = () => {
        if (confirm("Удалить из карантина " + item.path + " без возможности восстановления?")) run(async () => {
            await api("/api/quarantine/delete", {id:item.id});
            await refreshAfter("Файл удалён из карантина.");
        });
    };
    const download = append(controls, "button", "Скачать");
    download.className = "secondary";
    download.onclick = () => run(() => downloadFile("/api/quarantine/download", {id:item.id}, item.path));
    const picker = append(controls, "input");
    picker.type = "file";
    picker.hidden = true;
    const replace = append(controls, "button", "Заменить");
    replace.className = "secondary";
    replace.onclick = () => picker.click();
    picker.onchange = () => run(async () => {
        const upload = picker.files[0];
        picker.value = "";
        if (!upload) return;
        if (upload.size > 1048576) throw new Error("Выберите файл до 1 МиБ.");
        const response = await fetch("/api/quarantine/replace?id=" + item.id, {
            method: "POST", headers: {"X-Catalog-Action":"1"}, body: upload
        });
        if (!response.ok) throw new Error((await response.json()).error);
        await refreshAfter("Новая версия проверена и размещена по исходному пути.");
    });
    async function refreshAfter(text) {
        await quarantinePage();
        message(text);
    }
}

async function quarantinePage() {
    const list = byId("files");
    const open = new Set([...list.querySelectorAll("details[open]")].map(node => node.id));
    const fresh = await api("/api/quarantine");
    byId("maintenance").hidden = !fresh.maintenance;
    list.replaceChildren();
    byId("empty").hidden = fresh.files.length > 0;
    byId("empty").textContent = "В карантине нет файлов.";
    const groups = new Map();
    for (const file of fresh.files) {
        const key = file.report ?? file.id;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(file);
    }
    for (const [key, files] of [...groups].reverse()) {
        const first = files[0];
        const group = append(list, "details");
        group.id = "incident-" + key;
        const requested = String(key) === params.get("report") || files.some(f => f.id === params.get("id"));
        group.open = requested || open.has(group.id);
        const summary = append(group, "summary");
        append(summary, "time", time(first.date)).dateTime = first.date || "";
        append(summary, "span", "Карантин · Файлов: " + files.length);
        append(summary, "span", " · Общий риск " + first.risk + "/10").className = tone(first.risk);
        const detail = append(group, "div");
        detail.className = "detail";
        projectLink(append(detail, "p"), first.project);
        for (const item of files) isolatedFile(detail, item, open.has("isolated-" + item.id) || item.id === params.get("id"));
        if (requested) group.scrollIntoView({block:"nearest"});
    }
}

async function scenariosPage() {
    const data = await api("/api/scenarios");
    projectLink(byId("root").parentNode, data.project);
    const choices = byId("choices");
    for (const [value, choice] of Object.entries(data.choices)) {
        const label = append(choices, "label");
        const checkbox = append(label, "input");
        checkbox.type = "checkbox";
        checkbox.name = "selected";
        checkbox.value = value;
        append(label, "span", choice.label);
        append(choices, "p", choice.assumption).className = "scenario-description";
    }
    const form = byId("scenario");
    const create = byId("create");
    const rollback = byId("rollback");
    const credentials = byId("credentials");
    let active = data.active;
    const chosen = () => [...choices.querySelectorAll("input:checked")].map((input) => input.value);
    function render() {
        const selected = chosen();
        const risk = Math.max(0, ...selected.map((name) => data.choices[name].risk));
        byId("risk").textContent = risk ? "Уровень угрозы · " + risk.toFixed(1) + "/10" : "Выберите уязвимости";
        byId("risk").className = risk ? tone(risk) : "";
        choices.disabled = active || !data.catalog;
        credentials.hidden = active || !selected.includes("admin");
        credentials.disabled = credentials.hidden;
        create.disabled = active || !data.catalog || !selected.length;
        rollback.disabled = !active;
    }
    if (!data.catalog) message("Для этого конструктора выберите папку Web ресурса.", !data.active);
    choices.addEventListener("change", render);
    render();
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        const selected = chosen();
        const request = {selected, project: data.project};
        if (selected.includes("admin")) {
            request.username = byId("username").value.trim();
            request.current_password = byId("current-password").value;
            request.new_password = byId("new-password").value;
        }
        submit(create, async () => {
            const result = await api("/api/scenarios/create", request);
            active = true;
            byId("current-password").value = "";
            byId("new-password").value = "";
            message("Применено изменений: " + result.changes + " · Уровень угрозы · " + result.risk + "/10. Изменения проверены.");
            feedback.className = tone(result.risk);
        }).then(render);
    });
    rollback.addEventListener("click", () => {
        submit(rollback, async () => {
            const result = await api("/api/scenarios/rollback", {project: data.project});
            active = false;
            form.reset();
            message("Восстановлено изменений: " + result.changes + ". Проверка завершена." + (result.password_changed_again
                ? " Более поздний пароль сохранён." : ""));
        }).then(render);
    });
}

async function testingPage() {
    let active;
    const table = byId("results");
    function renderRows() {
        table.replaceChildren();
        if (!active) return;
        const showClean = byId("show-tn").checked;
        for (const item of active.rows) {
            if (item.outcome === "TN" && !showClean) continue;
            const row = append(table, "tr");
            fileLink(append(row, "td"), active.id, item.file);
            for (const value of [item.rule, item.actual ? "Да" : "Нет", item.predicted ? "Да" : "Нет",
                item.outcome, item.lines || "—", item.case]) append(row, "td", value);
        }
    }
    function render(result) {
        active = result;
        byId("result-heading").textContent = result.label;
        byId("suite").value = result.suite;
        const metrics = byId("metrics");
        metrics.replaceChildren();
        for (const [label, value] of [["Precision", result.precision], ["Recall", result.recall], ["F1", result.f1]]) {
            const group = append(metrics, "div");
            append(group, "dt", label);
            append(group, "dd", value.toLocaleString("ru-RU", {minimumFractionDigits: 4}));
        }
        byId("counts").textContent = "Файлов: " + result.cases + " · "
            + Object.entries(result.counts).map(([key, count]) => key + " " + count).join(" · ");
        byId("dataset").href = "/api/dataset?report=" + result.id;
        byId("result").hidden = false;
        renderRows();
    }
    byId("show-tn").addEventListener("change", renderRows);
    byId("testing").addEventListener("submit", (event) => {
        event.preventDefault();
        submit(event.submitter, async () => {
            message("Выполняется тестирование…");
            const result = await api("/api/testing", {suite: byId("suite").value});
            history.replaceState(null, "", "/testing?report=" + result.id);
            render(result);
            message("Результат сохранён в истории.");
        });
    });
    if (params.has("report")) render(await api("/api/test-result?" + params));
}

const pages = {file: projectFilePage, finding: findingPage, quarantine: quarantinePage,
    scenarios: scenariosPage, testing: testingPage};
pages[document.body.dataset.page]().catch((error) => message(error.message, true));
