"use strict";

const byId = (id) => document.getElementById(id);
const levels = {critical: "Критический", high: "Высокий", medium: "Средний",
    low: "Низкий", info: "Справочно"};

function append(parent, tag, content) {
    const node = document.createElement(tag);
    if (content !== undefined) node.textContent = content;
    parent.append(node);
    return node;
}

function time(value) {
    return value ? new Date(value).toLocaleString("ru-RU") : "—";
}

function locationLabel(item) {
    if (!item.path) return "Событие без привязки к файлу";
    return item.path + (item.line ? ":" + item.line : item.record ? " · " + item.record : "");
}

async function api(url, data) {
    const options = data === undefined ? {} : {method: "POST",
        headers: {"Content-Type": "application/json", "X-Catalog-Action": "1"},
        body: JSON.stringify(data)};
    const response = await fetch(url, options);
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "HTTP " + response.status);
    return result;
}

function fileLink(parent, report, path, label = path) {
    const link = append(parent, "a", label);
    link.href = "/file?" + new URLSearchParams({report, path});
    return link;
}
function tone(score) {
    return score >= 8 ? "problem" : "warning";
}

const filename = path => path.split("/").pop();
function projectLink(parent, path) {
    parent.replaceChildren("Проверяемый каталог: ");
    const link = append(parent, "a", path);
    link.href = "/?" + new URLSearchParams({project: path}) + "#history-heading";
}
