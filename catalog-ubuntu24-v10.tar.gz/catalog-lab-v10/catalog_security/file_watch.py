"""Linux notifications for completed writes, renames and deletions."""

import ctypes
import logging
import os
import select
import struct
import time
from pathlib import Path

from audit import CASE_DIR, IGNORED


LOG = logging.getLogger("catalog-security")
EVENT = struct.Struct("iIII")
CLOSE_WRITE, MOVED_FROM, MOVED_TO = 0x8, 0x40, 0x80
CREATE, DELETE, DELETE_SELF, MOVE_SELF = 0x100, 0x200, 0x400, 0x800
OVERFLOW, DIRECTORY = 0x4000, 0x40000000
MASK = CLOSE_WRITE | MOVED_FROM | MOVED_TO | CREATE | DELETE | DELETE_SELF | MOVE_SELF


def watch_project(project, monitor, libc):
    fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
    if fd < 0:
        raise OSError(ctypes.get_errno(), "inotify_init1")
    try:
        folders = {}
        for folder, dirs, _ in os.walk(project):
            path = Path(folder)
            wd = libc.inotify_add_watch(fd, os.fsencode(path), MASK)
            if wd < 0:
                if not path.exists():
                    continue
                raise OSError(ctypes.get_errno(), "inotify_add_watch", folder)
            folders[wd] = path
            dirs[:] = [name for name in dirs if name not in IGNORED and path / name != monitor.state
                       and (not name.startswith(".") or (path == project and name == CASE_DIR))]
        # Reconcile the registration window, including newly moved directory trees.
        monitor.scan_changes(project)
        while monitor.store.settings()["project"] == str(project):
            if not select.select([fd], [], [], 1)[0]:
                continue
            data = os.read(fd, 65536)
            offset = 0
            changed = set()
            while offset < len(data):
                wd, mask, _, size = EVENT.unpack_from(data, offset)
                offset += EVENT.size
                name = os.fsdecode(data[offset:offset + size].rstrip(b"\0"))
                offset += size
                if mask & OVERFLOW:
                    return
                if wd not in folders:
                    continue
                if mask & DIRECTORY:
                    if name in IGNORED or folders[wd] / name == monitor.state:
                        continue
                    return
                if mask & (DELETE_SELF | MOVE_SELF):
                    return
                if mask & (CLOSE_WRITE | MOVED_FROM | MOVED_TO | DELETE):
                    changed.add((folders[wd] / name).relative_to(project).as_posix())
            if changed:
                monitor.scan_changes(project, changed)
    finally:
        os.close(fd)


def watch(monitor):
    libc = ctypes.CDLL(None, use_errno=True)
    while True:
        try:
            project = Path(monitor.store.settings()["project"])
            watch_project(project, monitor, libc)
        except (OSError, ValueError, RuntimeError) as error:
            LOG.warning("File watcher will retry: %s", error)
            time.sleep(2)
