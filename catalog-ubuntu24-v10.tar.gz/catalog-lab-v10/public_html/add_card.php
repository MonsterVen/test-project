<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/catalog_security/site/bootstrap.php';

postOnly();
if (!adminSignedIn()) {
    event('auth_required');
    jsonResponse(['message' => 'Войдите как администратор.'], 401);
}
formContent();
if (!csrfValid()) {
    event('csrf_rejected');
    jsonResponse(['message' => 'Обновите страницу и повторите.'], 403);
}

$name = formText('name');
$description = formText('disc');
$tag = formText('tag');
$url = formText('place');
$image = formText('img');
$categories = ['browsers', 'game', 'messaging', 'utility', 'development', 'media', 'design'];
$scheme = strtolower(parse_url($url, PHP_URL_SCHEME) ?: '');
if ($name === '' || mb_strlen($name) > 30 || $description === '' || mb_strlen($description) > 2048
    || !in_array($tag, $categories, true)
    || strlen($url) > 2048 || filter_var($url, FILTER_VALIDATE_URL) === false
    || !in_array($scheme, ['http', 'https'], true) || parse_url($url, PHP_URL_USER) !== null
    || !preg_match('/\A[a-z0-9_][a-z0-9_+.-]{0,54}\.(?:svg|png)\z/i', $image)
    || !is_file(__DIR__ . '/images/' . $image)) {
    event('invalid_card');
    jsonResponse(['message' => 'Проверьте поля, HTTP(S)-ссылку и имя существующей иконки.'], 422);
}

$statement = db()->prepare('INSERT INTO card(name, disc, tag, place, img) VALUES (?, ?, ?, ?, ?)');
$statement->execute([$name, $description, $tag, $url, $image]);
jsonResponse(['success' => true, 'id' => (int) db()->lastInsertId()], 201);
