"use strict";

const form = document.querySelector("#add-card-form");
const message = document.querySelector("#response-message");

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const response = await fetch("./add_card.php", {method: "POST", body: new FormData(form)});
        const result = await response.json();
        if (!response.ok) throw new Error(result.message || "Не удалось добавить карточку.");
        form.reset();
        message.style.color = "green";
        message.textContent = "Карточка добавлена.";
    } catch (error) {
        message.style.color = "red";
        message.textContent = error.message;
    } finally {
        button.disabled = false;
    }
});
