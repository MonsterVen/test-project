"use strict";

document.querySelector(".toggle-password").addEventListener("click", () => {
    const field = document.querySelector("#password");
    const icon = document.querySelector("#toggle-password-icon");
    const show = field.type === "password";
    field.type = show ? "text" : "password";
    icon.classList.toggle("fa-eye", !show);
    icon.classList.toggle("fa-eye-slash", show);
});

document.querySelector("#home-button").addEventListener("click", () => {
    window.location.assign("/");
});
