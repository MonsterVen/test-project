<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/catalog_security/site/bootstrap.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD');
    jsonResponse(['message' => 'Используйте GET.'], 405);
}
$cards = db()->query('SELECT id, name, disc, tag, place, img FROM card ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$featured = __DIR__ . '/featured-messaging.json';
if (is_file($featured) && !is_link($featured) && filesize($featured) <= 8192) {
    $data = json_decode(file_get_contents($featured), true);
    if (is_array($data) && ($data['tag'] ?? null) === 'messaging' && ($data['img'] ?? null) === 'discord.svg'
        && is_string($data['name'] ?? null) && is_string($data['disc'] ?? null) && is_string($data['place'] ?? null)
        && in_array($data['place'], ['https://discord.com/', 'https://yandex.ru/games/'], true)) {
        array_unshift($cards, ['id' => -1, 'name' => $data['name'], 'disc' => $data['disc'],
            'tag' => 'messaging', 'place' => $data['place'], 'img' => 'discord.svg']);
    }
}
jsonResponse($cards);
