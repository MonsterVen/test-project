<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/catalog_security/site/bootstrap.php';

postOnly();
formContent();
if (!csrfValid()) {
    event('csrf_rejected');
    jsonResponse(['message' => 'Обновите страницу входа.'], 403);
}

$username = formText('username');
$password = $_POST['password'] ?? '';
$statement = db()->prepare('SELECT password_hash FROM admins WHERE username = ?');
$statement->execute([$username]);
$storedHash = $statement->fetchColumn();
if (is_string($password) && strlen($password) <= 1024 && is_string($storedHash)
    && password_verify($password, $storedHash)) {
    session_regenerate_id(true);
    $_SESSION = ['admin' => $username, 'credential_version' => hash('sha256', $storedHash)];
    header('Location: /adminpage.html', true, 303);
    exit;
}

event('auth_failed');
$_SESSION['login_error'] = 'Неверное имя пользователя или пароль.';
header('Location: /profile.html', true, 303);
