
"use strict";

const dashboard = document.querySelector(".dashboard-main");
const search = document.querySelector("#search");
let category = "all";
let ascending = true;

function makeCard(record) {
    let url;
    try {
        url = new URL(record.place);
        if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) url = null;
    } catch {
        url = null;
    }
    const card = document.createElement(url ? "a" : "article");
    card.className = "card";
    card.dataset.category = record.tag;
    if (url) card.href = url.href;

    const image = document.createElement("img");
    image.className = "left-image";
    image.alt = "";
    image.loading = "lazy";
    image.src = /^[a-z0-9_][a-z0-9_+.-]*\.(svg|png)$/i.test(record.img)
        ? "images/" + encodeURIComponent(record.img) : "images/smalllogo.png";
    image.addEventListener("error", () => { image.src = "images/smalllogo.png"; }, {once: true});

    const title = document.createElement("h3");
    title.className = "title";
    title.textContent = record.name;
    const description = document.createElement("p");
    description.className = "content";
    description.textContent = record.disc;
    card.append(image, title, description);
    return card;
}

function applyFilters() {
    const term = search.value.trim().toLocaleLowerCase();
    for (const card of dashboard.querySelectorAll(".card")) {
        const matchesCategory = category === "all" || card.dataset.category === category;
        card.hidden = !matchesCategory || !card.textContent.toLocaleLowerCase().includes(term);
    }
    syncSidebarHeight();
}

search.addEventListener("input", applyFilters);
document.querySelector("#sort-cards").addEventListener("click", () => {
    const cards = [...dashboard.querySelectorAll(".card")];
    const direction = ascending ? 1 : -1;
    cards.sort((left, right) => direction * left.querySelector(".title").textContent
        .localeCompare(right.querySelector(".title").textContent, "ru"));
    dashboard.append(...cards);
    ascending = !ascending;
});

for (const item of document.querySelectorAll(".nav-item[data-filter]")) {
    item.addEventListener("click", (event) => {
        event.preventDefault();
        document.querySelector(".nav-item.active")?.classList.remove("active");
        item.classList.add("active");
        category = item.dataset.filter;
        applyFilters();
    });
}

async function loadCards() {
    const status = document.querySelector("#card-status");
    try {
        const response = await fetch("./card.php");
        if (!response.ok) throw new Error("HTTP " + response.status);
        const cards = await response.json();
        dashboard.append(...cards.map(makeCard));
        status.textContent = cards.length ? "" : "Каталог пока пуст.";
        status.hidden = Boolean(cards.length);
        applyFilters();
    } catch {
        status.textContent = "Не удалось загрузить каталог. Обновите страницу.";
    }
}

loadCards();


//анимация сайдбара
const resizeBtn = document.getElementById('resize');
            resizeBtn.addEventListener('click', function(e) {
                e.preventDefault();
                document.body.classList.toggle('sb-expand');
            });

// курсор
// Проверяем, является ли устройство мобильным
function isMobileDevice() {
    return /Mobi|Android|iPhone|iPad|iPod|BlackBerry|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);
}

if (!isMobileDevice()) {
    // курсор
    const coords = { x: 0, y: 0 };
    const circles = document.querySelectorAll(".circle");

    const colors = [
        "#ffb56b", "#fdaf69", "#f89d63", "#f59761", "#ef865e", "#ec805d",
        "#e36e5c", "#df685c", "#d5585c", "#d1525c", "#c5415d", "#c03b5d",
        "#b22c5e", "#ac265e", "#9c155f", "#950f5f", "#830060", "#7c0060",
        "#680060", "#60005f", "#48005f", "#3d005e"
    ];

    circles.forEach(function (circle, index) {
        circle.x = 0;
        circle.y = 0;
        circle.style.backgroundColor = colors[index % colors.length];
    });

    window.addEventListener("mousemove", function (e) {
        coords.x = e.clientX;
        coords.y = e.clientY;
    });

    function animateCircles() {
        let x = coords.x;
        let y = coords.y;

        circles.forEach(function (circle, index) {
            circle.style.left = x - 12 + "px";
            circle.style.top = y - 12 + "px";
            circle.style.scale = (circles.length - index) / circles.length;

            circle.x = x;
            circle.y = y;

            const nextCircle = circles[index + 1] || circles[0];
            x += (nextCircle.x - x) * 0.3;
            y += (nextCircle.y - y) * 0.3;
        });

        requestAnimationFrame(animateCircles);
    }

    animateCircles();
}



// Функция для синхронизации высоты сайдбара и кнопки
function syncSidebarHeight() {
    const main = document.querySelector('.dashboard-main');
    const sidebar = document.querySelector('.dashboard-sidebar');
    const scrollLink = document.querySelector('#scrollToTopLink');

    // Параметры для высоты
    const additionalHeight = 220; // Дополнительная высота для сайдбара
    const minSidebarHeight = 650; // Минимальная высота сайдбара
    const triggerHeight = 1800; // Высота страницы, при которой показывается кнопка

    // Рассчитываем высоту main и прибавляем дополнительный отступ
    const computedMainHeight = main.scrollHeight;
    const newSidebarHeight = Math.max(computedMainHeight + additionalHeight, minSidebarHeight);

    // Применяем высоту сайдбару
    sidebar.style.height = `${newSidebarHeight}px`;

    // Проверяем текущую высоту сайдбара и страницы
    if (newSidebarHeight >= triggerHeight) {
        scrollLink.classList.add('show'); // Показываем кнопку
    } else {
        scrollLink.classList.remove('show'); // Скрываем кнопку
    }
}

// Функция плавного скролла наверх
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Добавляем обработчики событий
document.addEventListener('DOMContentLoaded', () => {
    const scrollLink = document.querySelector('#scrollToTopLink');

    // Синхронизируем высоту при загрузке и изменении контента
    syncSidebarHeight();

    // Наблюдаем за изменениями внутри .dashboard-main
    const main = document.querySelector('.dashboard-main');
    const observer = new MutationObserver(syncSidebarHeight);
    observer.observe(main, { childList: true, subtree: true });

    // Обновляем высоту при изменении размера окна
    window.addEventListener('resize', syncSidebarHeight);

    // Обработчик клика для кнопки
    scrollLink.addEventListener('click', (e) => {
        e.preventDefault();
        scrollToTop();
    });
});
